# RUMI - PDF EDITOR (PWA)

Editor PDF minimalis yang berjalan **sepenuhnya di browser**: berkas tidak pernah diunggah ke server.
Situs statis murni (tanpa build step), siap di-deploy ke Vercel, dan bisa dipasang & dipakai offline.

## Fitur

| Fitur | Cara |
|---|---|
| **Gabung** | *Tambah PDF* (bisa banyak berkas sekaligus) atau seret berkas ke jendela |
| **Hapus halaman** | Pilih halaman → ikon tempat sampah / tombol `Delete` (ada *Urungkan*) |
| **Putar** | Pilih halaman → putar kiri/kanan (`Shift+R` / `R`); menu ⋯ → *Putar semua* |
| **Atur halaman** | Seret & lepas (satu atau banyak halaman sekaligus; di layar sentuh: tahan lalu seret), tombol geser/ke awal/ke akhir, balik urutan, sisipkan halaman kosong |
| **Pisah** | Per rentang (`1-3, 5, 8-`), setiap N halaman, satu halaman per berkas, atau halaman terpilih. Hasil >1 berkas dikemas ZIP |
| **Pratinjau** | Klik dua kali / `Enter` pada halaman; `←` `→` untuk berpindah |
| **Potong** | Seret kotak potong (tepi/sudut) atau *Otomatis* untuk memangkas margin kosong; terapkan ke halaman terpilih atau semua. Hasilnya mengubah CropBox & MediaBox |
| **Edit isi** | Tambah teks (Helvetica), kotak penutup, sorotan, dan gambar (PNG/JPEG) di atas halaman; seret untuk memindahkan, pegangan sudut untuk mengubah ukuran |
| **OCR** | Mengenali teks pada halaman scan (Indonesia/Inggris) dengan Tesseract.js yang berjalan di perangkat. Hasilnya lapisan teks tak terlihat: PDF bisa dicari dan disalin; tersedia ekspor `.txt` |
| **Watermark** | Teks atau gambar/logo di atas halaman: satu di tengah atau berulang (ubin), atur ukuran, warna, opasitas, dan sudut; pratinjau langsung; untuk halaman terpilih atau semua. Mengikuti potongan & rotasi halaman |
| **Proteksi** | Kunci PDF dengan kata sandi buka (enkripsi AES-256, PDF 2.0), kata sandi pemilik opsional, dan izin: cetak, salin, ubah, anotasi |
| **Konversi** | PDF → gambar (PNG/JPG, 72–300 dpi; banyak halaman jadi ZIP), → Word (.docx), → Excel (.xlsx). Modul `convert.js` dimuat hanya saat dipakai |
| **Kompres** | Ringan/Sedang/Kuat: gambar di dalam PDF disusun ulang sebagai JPEG (teks tetap). Maksimal: tiap halaman jadi gambar (teks hilang) |
| **Simpan** | Menyimpan susunan saat ini sebagai satu PDF (`Ctrl+S`) |

Pilihan: klik (toggle), `Shift`+klik (rentang), `Ctrl/Cmd+A`, menu ⋯ → ganjil/genap. Undo/redo: `Ctrl+Z` / `Ctrl+Shift+Z` (100 langkah).

## Antarmuka

- **Halaman awal**: lima kartu fitur (Gabung, Pisah, Putar, Hapus, Atur). Mengeklik kartu membuka pemilih berkas, lalu mengarahkan ke fitur terkait (Pisah langsung membuka dialog pemisahan; lainnya menampilkan petunjuk singkat).
- **Editor**: baris alat di bawah header (Gabung, Pisah, Putar, Hapus, Atur) dengan petunjuk singkat yang berubah menurut kondisi (belum ada pilihan / ada halaman terpilih; sentuh vs. mouse). Putar dan Hapus nonaktif sampai ada halaman terpilih. Di layar sempit label tombol disembunyikan, ikon tetap tampil.

## Deploy ke Vercel

Tidak perlu build. `vercel.json` sudah mengatur folder output (`public`), header keamanan (CSP), dan cache.

**Lewat GitHub:** push repo ini → *Add New Project* di Vercel → impor repo → *Deploy*. Biarkan Framework Preset = *Other*; pengaturan lain otomatis dari `vercel.json`.

**Lewat CLI:**
```bash
npm i -g vercel
vercel          # pratinjau
vercel --prod   # produksi
```

## Pengembangan lokal

```bash
npm run dev     # http://localhost:5173 (menerapkan header & CSP dari vercel.json)
npm test        # uji logika PDF/ZIP (Node ≥ 20, tanpa npm install)
```

Service worker hanya aktif di `localhost` atau HTTPS. Setelah memperbarui kode di `public/`, kunjungan berikutnya otomatis mengambil versi baru saat online; pengguna yang sedang membuka aplikasi akan melihat toast *Muat ulang* (tidak pernah memuat ulang sendiri, supaya pekerjaan tidak hilang).

## Struktur

```
public/
  index.html  styles.css  app.js      UI & interaksi
  ops.js                              gabung/pisah/putar/hapus (pdf-lib), rencana pemisahan
  zip.js                              penulis ZIP kecil (tanpa dependensi)
  marks.js tools.js                   anotasi & watermark ke kanvas; dialog Potong, Edit isi, Kompres, OCR, Watermark, Proteksi
  crypt.js                            enkripsi AES-256 (WebCrypto) untuk Proteksi
  sw.js  manifest.webmanifest  icons/ PWA
  vendor/                             pdf-lib, pdf.js (build legacy), cmaps, font, wasm — di-bundel lokal
scripts/serve.mjs                     server lokal
test/ops.test.mjs                     uji unit
vercel.json
```

Semua pustaka disalin ke `public/vendor/` (tidak ada CDN), jadi aplikasi tetap jalan offline dan CSP bisa ketat.
Jika Anda mengganti berkas di `vendor/`, naikkan `CACHE_VERSION` di `public/sw.js`.

## Batasan yang perlu diketahui

- **Konversi Word/Excel bersifat heuristik**: PDF tidak menyimpan paragraf atau tabel, jadi keduanya disusun dari posisi teks. Baik untuk dokumen satu kolom dan tabel dengan jarak antarkolom jelas; kolom ganda bisa tertukar, tabel tanpa jarak bisa menyatu, gambar/garis/grafik tidak ikut ke Word. Halaman scan perlu OCR dulu (di Word, halaman scan tanpa OCR disisipkan sebagai gambar). Di Excel, angka dibaca konservatif: nomor panjang (NPWP, rekening), angka berawalan nol, dan tanggal tetap teks. Periksa hasil sebelum dipakai untuk angka penting.

- **OCR**: model bahasa dan mesin WASM (±16 MB di `public/vendor/tesseract/`) dimuat hanya saat OCR dipakai, lalu di-cache service worker untuk offline. Akurasi turun pada scan miring/buram atau tulisan tangan; hasil perlu dicek. Kompres → *Maksimal* membuang lapisan teks OCR, jadi lakukan OCR setelah kompres jika keduanya dipakai.

- **Edit isi tidak mengubah teks asli** di dalam PDF (tidak ada reflow/ketik ulang). Fitur ini menambah objek di atas halaman.
- **Kotak penutup bukan redaksi**: teks di bawahnya tetap ada di berkas dan bisa disalin. Untuk benar-benar menghapus, jalankan *Kompres → Maksimal* setelahnya.
- **Potong tidak membuang data**: konten di luar area potong masih ada di berkas; hanya tidak ditampilkan.
- Teks tambahan memakai font standar PDF (WinAnsi): huruf Latin dan aksen aman, aksara non-Latin diganti `?`.
- Kompres hanya mengecilkan gambar JPEG/Flate RGB/Gray 8-bit; gambar CMYK, JPX, CCITT, JBIG2 dibiarkan. Berkas tanpa gambar hampir tidak mengecil.

- **Watermark bukan pengaman**: ia hanya digambar di atas halaman dan bisa dihapus oleh siapa pun yang mengedit PDF. Untuk menyulitkan penghapusan, jadikan halaman gambar dulu (*Kompres → Maksimal*).
- **Proteksi**: kata sandi buka benar-benar mengenkripsi isi (AES-256) dan tidak bisa dipulihkan bila lupa. Izin (cetak/salin/ubah) hanya dihormati pembaca yang patuh. AES-256 dibaca Acrobat X+, Chrome, Edge, Firefox, Preview, dan poppler/qpdf; pembaca yang sangat lama mungkin tidak mendukungnya. Berkas hasil Proteksi tidak bisa dibuka kembali di aplikasi ini (lihat di bawah).
- PDF yang dienkripsi/dilindungi kata sandi ditolak dengan pesan jelas (pdf-lib tidak bisa mendekripsi).
- Menggabungkan PDF membawa halaman apa adanya; formulir interaktif/bookmark/tag aksesibilitas dari dokumen sumber tidak dipertahankan di hasil gabungan.
- Berkas sangat besar (ratusan MB) dibatasi memori browser, karena semua diproses di perangkat.
- File Handler (membuka PDF dari OS lewat aplikasi terpasang) didukung di Chrome/Edge desktop.

## Lisensi pihak ketiga

pdf-lib (MIT) dan pdf.js (Apache-2.0) — lihat `public/vendor/LICENSE-*`.
