import * as pdfjsLib from './vendor/pdf.min.mjs';
import { createOps, planSplit, normalizeCrop } from './ops.js';
import { paintMarks, paintWatermark } from './marks.js';
import { initTools } from './tools.js';
import { makeZip } from './zip.js';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdf.worker.min.mjs', import.meta.url).href;
const VENDOR = new URL('./vendor/', import.meta.url).href;
const PDFJS_OPTS = {
  cMapUrl: VENDOR + 'cmaps/',
  cMapPacked: true,
  standardFontDataUrl: VENDOR + 'standard_fonts/',
  wasmUrl: VENDOR + 'wasm/',
  isEvalSupported: false,
};
const ops = createOps(window.PDFLib);

/* ------------------------------------------------------------------ util */
const $ = (s, r = document) => r.querySelector(s);
const el = {
  main: $('#main'), empty: $('#empty'), wrap: $('#gridwrap'), grid: $('#grid'), indicator: $('#indicator'),
  stats: $('#stats'), file: $('#file'), selbar: $('#selbar'), selCount: $('#sel-count'), toasts: $('#toasts'),
  veil: $('#veil'), dropzone: $('#dropzone'), menu: $('#menu'), toolrow: $('#toolrow'), toolhint: $('#toolhint'),
  btn: Object.fromEntries(['home', 'add', 'open', 'undo', 'redo', 'menu', 'split', 'save'].map((k) => [k, $('#btn-' + k)])),
};
const A4 = [595.28, 841.89];
const HUES = [250, 28, 168, 330, 205, 85, 290, 0]; // penanda warna per berkas sumber
const plural = (n, one) => `${n} ${one}`;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const raf = () => new Promise((r) => requestAnimationFrame(r));
const sanitize = (s) => s.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').replace(/^\.+/, '').trim().slice(0, 120) || 'dokumen';

/* ----------------------------------------------------------------- state */
let uid = 0;
const state = {
  files: new Map(), // fid -> { id, name, size, pdf, lib, n, hue }
  pages: [], // { id, fid, idx, rot, vis, blank? }
  selected: new Set(),
  undo: [],
  redo: [],
  dirty: false,
  anchor: null,
  focusId: null,
};
const dims = new Map(); // pageId -> { w, h } ukuran tampilan (pt) sebelum rotasi tambahan
const cards = new Map(); // pageId -> elemen kartu
const pageById = (id) => state.pages.find((p) => p.id === id);
const indexOfId = (id) => state.pages.findIndex((p) => p.id === id);

const snapshot = () => state.pages.map((p) => ({ ...p }));

function mutate(fn) {
  state.undo.push(snapshot());
  if (state.undo.length > 100) state.undo.shift();
  state.redo.length = 0;
  fn();
  state.dirty = true;
  render();
}
function undo() {
  if (!state.undo.length) return;
  state.redo.push(snapshot());
  state.pages = state.undo.pop();
  state.dirty = true;
  pruneSelection();
  render();
}
function redo() {
  if (!state.redo.length) return;
  state.undo.push(snapshot());
  state.pages = state.redo.pop();
  state.dirty = true;
  pruneSelection();
  render();
}
function pruneSelection() {
  const ids = new Set(state.pages.map((p) => p.id));
  for (const id of state.selected) if (!ids.has(id)) state.selected.delete(id);
  if (state.anchor && !ids.has(state.anchor)) state.anchor = null;
}

/* ----------------------------------------------------------------- toast */
function toast(msg, { action, onAction, error = false, ms = 5000 } = {}) {
  const t = document.createElement('div');
  t.className = 'toast' + (error ? ' err' : '');
  t.setAttribute('role', error ? 'alert' : 'status');
  const span = document.createElement('span');
  span.textContent = msg;
  t.append(span);
  const close = () => t.remove();
  if (action) {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = action;
    b.onclick = () => { onAction?.(); close(); };
    t.append(b);
  }
  el.toasts.append(t);
  while (el.toasts.children.length > 3) el.toasts.firstChild.remove();
  setTimeout(close, error ? Math.max(ms, 8000) : ms);
}

/* ------------------------------------------------------------- dialog util */
for (const d of document.querySelectorAll('dialog')) {
  d.addEventListener('click', (e) => { if (e.target === d && d.id !== 'dlg-busy' && !d.classList.contains('editor')) d.close(); });
  d.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => d.close()));
}
const busyDlg = $('#dlg-busy');
busyDlg.addEventListener('cancel', (e) => e.preventDefault());
let abortCtl = null;
function busy(msg, p, onCancel) {
  $('#busy-msg').textContent = msg;
  const cb = $('#busy-cancel');
  cb.hidden = !onCancel;
  cb.onclick = onCancel ? () => { cb.disabled = true; onCancel(); } : null;
  if (onCancel) cb.disabled = cb.disabled && busyDlg.open; else cb.disabled = false;
  const bar = $('#busy-bar');
  bar.classList.toggle('indeterminate', p == null);
  if (p != null) bar.style.setProperty('--p', Math.round(p * 100) + '%');
  if (!busyDlg.open) busyDlg.showModal();
}
const unbusy = () => { $('#busy-cancel').hidden = true; $('#busy-cancel').disabled = false; return busyDlg.open && busyDlg.close(); };

function ask(title, text, okLabel = 'Lanjut') {
  const d = $('#dlg-confirm');
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  $('#confirm-ok').textContent = okLabel;
  return new Promise((resolve) => {
    const done = () => { d.removeEventListener('close', done); resolve(d.returnValue === 'ok'); };
    d.returnValue = '';
    d.addEventListener('close', done);
    $('#confirm-ok').value = 'ok';
    d.showModal();
  });
}

/* ------------------------------------------------------------ kartu fitur */
// Kartu di halaman awal membuka pemilih berkas, lalu mengarahkan ke fitur yang dipilih.
let pendingIntent = null;
const INTRO = {
  merge: (files) => (files > 1
    ? 'Berkas tergabung. Atur urutannya, lalu Simpan.'
    : 'Klik "Gabung" di baris alat atau seret PDF lain ke jendela untuk menggabungkan.'),
  rotate: () => 'Pilih halaman, lalu putar dengan R (kanan) atau Shift+R (kiri).',
  delete: () => 'Pilih halaman, lalu tekan Delete. Bisa diurungkan.',
  order: () => 'Seret halaman untuk mengubah urutan. Di layar sentuh: tahan lalu seret.',
};
function runIntent(intent, files) {
  if (intent === 'split') { openSplit(); return; }
  if (intent === 'crop') { tools.openCrop(); return; }
  if (intent === 'edit') { tools.openEdit(); return; }
  if (intent === 'compress') { tools.openCompress(); return; }
  if (intent === 'ocr') { tools.openOcr(); return; }
  if (intent === 'watermark') { tools.openWatermark(); return; }
  if (intent === 'protect') { tools.openProtect(); return; }
  if (intent === 'convert') { tools.openConvert(); return; }
  const msg = INTRO[intent]?.(files);
  if (msg) toast(msg, { ms: 7000 });
}

/* ------------------------------------------------------------ buka berkas */
async function addFiles(list) {
  const files = [...list].filter((f) => f.type === 'application/pdf' || /\.pdf$/i.test(f.name));
  if (!files.length) { toast('Pilih berkas dengan format PDF.', { error: true }); return; }

  const newPages = [];
  const problems = [];
  for (const [i, f] of files.entries()) {
    busy(files.length > 1 ? `Membuka ${i + 1} dari ${files.length}…` : 'Membuka berkas…');
    await raf();
    try {
      const bytes = new Uint8Array(await f.arrayBuffer());
      const lib = await ops.load(bytes); // gagal cepat bila terenkripsi / rusak
      const pdf = await pdfjsLib.getDocument({ data: bytes.slice(), ...PDFJS_OPTS }).promise;
      const fid = ++uid;
      state.files.set(fid, { id: fid, name: f.name, size: f.size, pdf, lib, n: pdf.numPages, hue: HUES[state.files.size % HUES.length] });
      for (let k = 0; k < pdf.numPages; k++) newPages.push({ id: ++uid, fid, idx: k, rot: 0, vis: 0 });
    } catch (e) {
      console.error(e);
      const reason = e?.name === 'PasswordException' || e?.code === 'encrypted'
        ? 'dilindungi kata sandi atau enkripsi'
        : 'tidak dapat dibaca (rusak atau bukan PDF)';
      problems.push(`${f.name}: ${reason}`);
    }
  }
  unbusy();
  const intent = pendingIntent;
  pendingIntent = null;
  if (newPages.length) {
    mutate(() => state.pages.push(...newPages));
    const added = new Set(newPages.map((p) => p.fid)).size;
    if (state.files.size > 1 || added > 1) toast(`${plural(newPages.length, 'halaman')} ditambahkan.`);
  }
  if (problems.length) toast(problems.join('\n'), { error: true });
  if (newPages.length && intent) runIntent(intent, files.length);
}

/* ------------------------------------------------------------------ render */
function visualSwap(p) {
  return (((Math.round(p.vis / 90) % 2) + 2) % 2) === 1;
}

function createCard(p) {
  const c = document.createElement('div');
  c.className = 'card';
  c.setAttribute('role', 'option');
  c.dataset.id = p.id;
  c.innerHTML = `
    <div class="thumb"><canvas></canvas><span class="check"><svg class="ic"><use href="#i-check"/></svg></span></div>
    <div class="meta"><span class="dot"></span><span class="num"></span><span class="src"></span><span class="tags"></span></div>`;
  c._crop = p.crop; c._marks = p.marks; c._wm = p.wm; c._rot = p.rot;
  if (p.blank) c.classList.add('blank');
  cards.set(p.id, c);
  io.observe(c);
  return c;
}

function render() {
  const n = state.pages.length;
  const has = n > 0;
  el.empty.hidden = has;
  el.wrap.hidden = !has;
  el.toolrow.hidden = !has;
  el.btn.undo.disabled = !state.undo.length;
  el.btn.redo.disabled = !state.redo.length;
  for (const k of ['split', 'save', 'menu', 'home']) el.btn[k].disabled = !has;

  const fileIds = new Set(state.pages.filter((p) => !p.blank).map((p) => p.fid));
  el.stats.hidden = !has;
  el.stats.textContent = has ? `${n} halaman${fileIds.size > 1 ? ` · ${fileIds.size} berkas` : ''}` : '';
  el.grid.classList.toggle('multi-file', fileIds.size > 1);

  const live = new Set();
  let focusOk = false;
  state.pages.forEach((p, i) => {
    live.add(p.id);
    const c = cards.get(p.id) || createCard(p);
    if (el.grid.children[i] !== c) el.grid.insertBefore(c, el.grid.children[i] || null);
    $('.num', c).textContent = i + 1;
    // Watermark mengikuti rotasi halaman (sudutnya dihitung dari tampilan akhir), jadi rotasi ikut memicu gambar ulang.
    if (c._crop !== p.crop || c._marks !== p.marks || c._wm !== p.wm || (p.wm && c._rot !== p.rot)) { c._crop = p.crop; c._marks = p.marks; c._wm = p.wm; c._rot = p.rot; refreshThumb(c); }
    const tags = [p.crop ? '✂' : '', p.marks?.length ? '✎' : '', p.wm ? 'WM' : '', p.ocr ? 'OCR' : ''].filter(Boolean);
    $('.tags', c).textContent = tags.join(' ');
    $('.tags', c).title = [p.crop ? 'Dipotong' : '', p.marks?.length ? `${p.marks.length} objek ditambahkan` : '', p.wm ? 'Watermark' : '', p.ocr ? 'Teks OCR' : ''].filter(Boolean).join(' · ');
    const sel = state.selected.has(p.id);
    c.setAttribute('aria-selected', sel);
    c.classList.toggle('swap', visualSwap(p));
    $('.thumb', c).style.setProperty('--r', p.vis + 'deg');
    if (p.blank) {
      $('.src', c).textContent = 'kosong';
    } else {
      const f = state.files.get(p.fid);
      c.style.setProperty('--dot', `hsl(${f.hue} 62% 52%)`);
      $('.src', c).textContent = f.name.replace(/\.pdf$/i, '');
      c.title = `${f.name} — hlm. ${p.idx + 1}`;
    }
    c.setAttribute('aria-label', `Halaman ${i + 1}${sel ? ', dipilih' : ''}`);
    const isFocus = state.focusId === p.id;
    c.tabIndex = isFocus ? 0 : -1;
    focusOk ||= isFocus;
  });
  for (const [id, c] of cards) {
    if (!live.has(id)) { io.unobserve(c); cancelRender(c); c.remove(); cards.delete(id); }
  }
  if (!focusOk && state.pages.length) {
    state.focusId = state.pages[0].id;
    cards.get(state.focusId).tabIndex = 0;
  }
  updateSelbar();
  updateToolrow();
}

const COARSE = matchMedia('(pointer: coarse)');
function updateToolrow() {
  const k = state.selected.size;
  for (const id of ['tool-rot-ccw', 'tool-rot-cw', 'tool-delete']) $('#' + id).disabled = k === 0;
  const hint = el.toolhint;
  hint.replaceChildren();
  const add = (...parts) => hint.append(...parts.map((p) => (p instanceof Node ? p : document.createTextNode(p))));
  const key = (t) => { const e = document.createElement('kbd'); e.textContent = t; return e; };
  if (k === 0) {
    if (COARSE.matches) add('Ketuk halaman untuk memilih. Tahan lalu seret untuk mengubah urutan.');
    else add('Klik halaman untuk memilih · ', key('Shift'), '+klik untuk rentang · seret untuk mengatur urutan · klik dua kali untuk pratinjau');
  } else if (COARSE.matches) {
    add(`${k} dipilih. Putar, hapus, atau geser lewat bilah di bawah.`);
  } else {
    add(`${k} dipilih · `, key('R'), ' putar · ', key('Delete'), ' hapus · ', key('Esc'), ' batal · seret untuk memindahkan');
  }
}

function updateSelbar() {
  const k = state.selected.size;
  el.selbar.hidden = k === 0;
  document.body.classList.toggle('has-selbar', k > 0);
  if (!k) return;
  el.selCount.textContent = `${k} dipilih`;
  const idxs = state.pages.map((p, i) => (state.selected.has(p.id) ? i : -1)).filter((i) => i >= 0);
  const n = state.pages.length;
  // Tombol geser dinonaktifkan bila seluruh pilihan sudah mentok di tepi.
  const atStart = idxs.every((v, i) => v === i);
  const atEnd = idxs.every((v, i) => v === n - idxs.length + i);
  $('#act-left').disabled = atStart;
  $('#act-start').disabled = atStart;
  $('#act-right').disabled = atEnd;
  $('#act-end').disabled = atEnd;
}

/* ------------------------------------------------------ render miniatur */
const queue = [];
let active = 0;
const MAX_ACTIVE = 2;

const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    e.target._vis = e.isIntersecting;
    if (e.isIntersecting) enqueue(e.target);
    else release(e.target);
  }
}, { rootMargin: '900px 0px' });

function enqueue(c) {
  if (c.dataset.state === 'ready' || c.dataset.state === 'queued' || c.dataset.state === 'busy') return;
  c.dataset.state = 'queued';
  queue.push(c);
  pump();
}
function pump() {
  while (active < MAX_ACTIVE && queue.length) {
    const c = queue.shift();
    if (c.dataset.state !== 'queued' || !c.isConnected) continue;
    active++;
    renderThumb(c).finally(() => { active--; pump(); });
  }
}
function cancelRender(c) {
  c._task?.cancel();
  c._task = null;
  const i = queue.indexOf(c);
  if (i >= 0) queue.splice(i, 1);
}
function release(c) {
  cancelRender(c);
  if (c.dataset.state === 'ready' || c.dataset.state === 'queued' || c.dataset.state === 'busy') {
    delete c.dataset.state;
    const cv = $('canvas', c);
    cv.width = cv.height = 0;
  }
}
/** Potong/anotasi berubah → gambar ulang miniatur kartu yang sedang terlihat. */
function refreshThumb(c) {
  cancelRender(c);
  delete c.dataset.state;
  if (c._vis) enqueue(c);
}

/**
 * Menggambar halaman (sudah termasuk anotasi & potongan) ke kanvas, dalam orientasi asli halaman
 * (rotasi dari pengguna diterapkan terpisah). scaleFn(wPt, hPt) → piksel per pt, berdasarkan ukuran yang terlihat.
 */
async function composite(p, scaleFn, { target, onTask, alive } = {}) {
  const d = await pageSize(p);
  const page = p.blank ? null : await state.files.get(p.fid).pdf.getPage(p.idx + 1);
  const crop = normalizeCrop(p.crop);
  const marks = p.marks || [];
  const vw = crop ? d.w * (1 - crop.l - crop.r) : d.w;
  const vh = crop ? d.h * (1 - crop.t - crop.b) : d.h;
  const scale = scaleFn(vw, vh);
  const direct = !crop && !marks.length && !p.wm && !!target;
  const cv = direct ? target : document.createElement('canvas');
  if (page) {
    const vp = page.getViewport({ scale });
    cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
    const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height);
    const task = page.render({ canvas: cv, viewport: vp });
    onTask?.(task);
    await task.promise;
    page.cleanup();
  } else {
    cv.width = Math.max(1, Math.floor(d.w * scale)); cv.height = Math.max(1, Math.floor(d.h * scale));
    const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height);
  }
  if (alive && !alive()) return null;
  if (direct) return { canvas: cv };
  if (marks.length) await paintMarks(cv.getContext('2d'), marks, cv.width, cv.height, cv.width / d.w);
  if (p.wm) await paintWatermark(cv.getContext('2d'), p.wm, cv.width, cv.height, cv.width / d.w, { crop, extraRot: p.rot || 0 });
  if (alive && !alive()) return null;
  const out = target || document.createElement('canvas');
  if (crop) {
    const sx = Math.round(crop.l * cv.width); const sy = Math.round(crop.t * cv.height);
    const sw = Math.max(1, Math.round(cv.width * (1 - crop.l - crop.r))); const sh = Math.max(1, Math.round(cv.height * (1 - crop.t - crop.b)));
    out.width = sw; out.height = sh;
    out.getContext('2d').drawImage(cv, sx, sy, sw, sh, 0, 0, sw, sh);
  } else {
    out.width = cv.width; out.height = cv.height;
    out.getContext('2d').drawImage(cv, 0, 0);
  }
  cv.width = cv.height = 0;
  return { canvas: out };
}

/** Halaman sumber sudah punya teks asli (bukan scan)? */
async function pageHasText(p) {
  if (p.blank) return false;
  const page = await state.files.get(p.fid).pdf.getPage(p.idx + 1);
  const tc = await page.getTextContent();
  const n = tc.items.reduce((a, it) => a + (it.str || '').trim().length, 0);
  page.cleanup();
  return n >= 20;
}

async function pageSize(p) {
  if (p.blank) return dims.get(p.id);
  let d = dims.get(p.id);
  if (!d) {
    const page = await state.files.get(p.fid).pdf.getPage(p.idx + 1);
    const v = page.getViewport({ scale: 1 });
    d = { w: v.width, h: v.height };
    dims.set(p.id, d);
  }
  return d;
}
/** Halaman apa adanya (tanpa potongan/anotasi) pada orientasi asli, scale = px per pt. */
async function drawRaw(p, cv, scale, onTask) {
  const d = await pageSize(p);
  const g = () => cv.getContext('2d');
  if (p.blank) {
    cv.width = Math.max(1, Math.round(d.w * scale)); cv.height = Math.max(1, Math.round(d.h * scale));
    g().fillStyle = '#fff'; g().fillRect(0, 0, cv.width, cv.height);
    return;
  }
  const page = await state.files.get(p.fid).pdf.getPage(p.idx + 1);
  const vp = page.getViewport({ scale });
  cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
  g().fillStyle = '#fff'; g().fillRect(0, 0, cv.width, cv.height);
  const task = page.render({ canvas: cv, viewport: vp });
  onTask?.(task);
  await task.promise;
  page.cleanup();
}

async function renderThumb(c) {
  const p = pageById(Number(c.dataset.id));
  if (!p) return;
  c.dataset.state = 'busy';
  const tok = (c._tok = (c._tok || 0) + 1);
  const alive = () => c._tok === tok && c.dataset.state === 'busy';
  const cv = $('canvas', c);
  try {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const res = await composite(p, (w, h) => (300 * dpr) / Math.max(w, h), { target: cv, onTask: (t) => { c._task = t; }, alive });
    c._task = null;
    if (!res || !alive()) return; // sudah keluar layar / diganti selagi menunggu
    $('.thumb', c).style.setProperty('--a', cv.width / cv.height);
    c.dataset.state = 'ready';
  } catch (e) {
    if (e?.name !== 'RenderingCancelledException') console.warn('Gagal merender miniatur', e);
    if (c._tok === tok && c.dataset.state === 'busy') delete c.dataset.state;
  }
}

/* --------------------------------------------------------------- seleksi */
function setSelected(ids) {
  state.selected = new Set(ids);
  render();
}
function clearSelection() { if (state.selected.size) setSelected([]); }

function clickCard(id, e) {
  state.focusId = id;
  const i = indexOfId(id);
  if (e.shiftKey && state.anchor && pageById(state.anchor)) {
    const a = indexOfId(state.anchor);
    const [lo, hi] = a < i ? [a, i] : [i, a];
    const next = new Set(state.selected);
    for (let k = lo; k <= hi; k++) next.add(state.pages[k].id);
    state.selected = next;
  } else {
    const next = new Set(state.selected);
    next.has(id) ? next.delete(id) : next.add(id);
    state.selected = next;
    state.anchor = id;
  }
  render();
}

/* ---------------------------------------------------------------- aksi */
const targets = () => (state.selected.size ? state.pages.filter((p) => state.selected.has(p.id)) : state.pages);

function rotate(delta, all = false) {
  const list = all ? state.pages : targets();
  if (!list.length) return;
  mutate(() => list.forEach((p) => { p.rot = (((p.rot + delta) % 360) + 360) % 360; p.vis += delta; }));
}

function deleteSelected() {
  const k = state.selected.size;
  if (!k) return;
  const ids = new Set(state.selected);
  mutate(() => { state.pages = state.pages.filter((p) => !ids.has(p.id)); state.selected.clear(); });
  toast(k === 1 ? '1 halaman dihapus.' : `${k} halaman dihapus.`, { action: 'Urungkan', onAction: undo });
}

function stepMove(dir) {
  const sel = state.selected;
  if (!sel.size) return;
  mutate(() => {
    const a = state.pages;
    if (dir < 0) {
      for (let i = 1; i < a.length; i++) if (sel.has(a[i].id) && !sel.has(a[i - 1].id)) [a[i - 1], a[i]] = [a[i], a[i - 1]];
    } else {
      for (let i = a.length - 2; i >= 0; i--) if (sel.has(a[i].id) && !sel.has(a[i + 1].id)) [a[i + 1], a[i]] = [a[i], a[i + 1]];
    }
  });
  scrollToFocus();
}
function moveEdge(toEnd) {
  const sel = state.selected;
  if (!sel.size) return;
  mutate(() => {
    const moved = state.pages.filter((p) => sel.has(p.id));
    const rest = state.pages.filter((p) => !sel.has(p.id));
    state.pages = toEnd ? [...rest, ...moved] : [...moved, ...rest];
  });
  scrollToFocus();
}
function scrollToFocus() {
  const first = [...state.selected][0];
  cards.get(first)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

/** Memindahkan sekelompok halaman ke posisi sisip (indeks pada daftar tanpa halaman yang dipindah). */
function moveTo(ids, insertAt) {
  const set = new Set(ids);
  mutate(() => {
    const moved = state.pages.filter((p) => set.has(p.id));
    const rest = state.pages.filter((p) => !set.has(p.id));
    rest.splice(insertAt, 0, ...moved);
    state.pages = rest;
  });
}

function insertBlank() {
  const idxs = state.pages.map((p, i) => (state.selected.has(p.id) ? i : -1)).filter((i) => i >= 0);
  const at = idxs.length ? Math.max(...idxs) + 1 : state.pages.length;
  const ref = state.pages[Math.max(0, at - 1)];
  const d = (ref && dims.get(ref.id)) || { w: A4[0], h: A4[1] };
  const page = { id: ++uid, blank: true, rot: 0, vis: 0 };
  dims.set(page.id, { w: d.w, h: d.h });
  mutate(() => state.pages.splice(at, 0, page));
  state.focusId = page.id;
  cards.get(page.id)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

async function resetAll(home = false) {
  const ok = await ask(home ? 'Kembali ke beranda?' : 'Tutup dokumen?', state.dirty ? 'Perubahan yang belum disimpan akan hilang.' : 'Dokumen akan ditutup dan semua halaman dihapus dari layar.', home ? 'Ke beranda' : 'Tutup');
  if (!ok) return;
  for (const f of state.files.values()) f.pdf.destroy?.();
  state.files.clear(); state.pages = []; state.selected.clear(); state.undo = []; state.redo = [];
  state.dirty = false; state.anchor = null; state.focusId = null;
  dims.clear();
  render();
}

/* ---------------------------------------------------------------- ekspor */
const itemOf = (p) => (p.blank
  ? { blank: true, w: dims.get(p.id).w, h: dims.get(p.id).h, rot: p.rot, crop: p.crop || null, marks: p.marks || [], wm: p.wm || null, ocr: p.ocr || null }
  : { fid: p.fid, idx: p.idx, rot: p.rot, crop: p.crop || null, marks: p.marks || [], wm: p.wm || null, ocr: p.ocr || null });
const getLib = (fid) => state.files.get(fid).lib;

function baseName() {
  const names = [...new Set(state.pages.filter((p) => !p.blank).map((p) => state.files.get(p.fid).name))];
  if (names.length === 1) return sanitize(names[0].replace(/\.pdf$/i, ''));
  return 'gabungan';
}

function download(blob, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 60_000);
}

function openSave() {
  const n = state.pages.length;
  $('#save-info').textContent = `${plural(n, 'halaman')} akan disimpan dalam satu berkas PDF.`;
  const base = baseName();
  const single = new Set(state.pages.filter((p) => !p.blank).map((p) => p.fid)).size === 1;
  $('#in-name').value = single && state.dirty ? `${base}-edit` : base;
  $('#dlg-save').showModal();
  $('#in-name').select();
}

$('#form-save').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = sanitize($('#in-name').value.replace(/\.pdf$/i, '')) + '.pdf';
  $('#dlg-save').close();
  try {
    busy('Menyimpan…', 0);
    await raf();
    const bytes = await ops.build(state.pages.map(itemOf), getLib, { onProgress: (p) => busy('Menyimpan…', p) });
    download(new Blob([bytes], { type: 'application/pdf' }), name);
    state.dirty = false;
    toast(`${name} tersimpan.`);
  } catch (err) {
    console.error(err);
    toast('Gagal menyimpan PDF: ' + (err?.message || err), { error: true });
  } finally { unbusy(); }
});

/* ------------------------------------------------------------- pisah PDF */
const splitForm = $('#form-split');
const splitMode = () => splitForm.elements.mode.value;

function splitOptions() {
  const positions = state.pages.map((p, i) => (state.selected.has(p.id) ? i : -1)).filter((i) => i >= 0);
  return { text: $('#in-ranges').value, every: $('#in-every').value, positions };
}
function refreshSplit() {
  const mode = splitMode();
  $('#f-ranges').hidden = mode !== 'ranges';
  $('#f-every').hidden = mode !== 'every';
  const plan = planSplit(mode, state.pages.length, splitOptions());
  const box = $('#split-plan');
  box.classList.toggle('err', !plan.ok);
  $('#split-go').disabled = !plan.ok;
  if (!plan.ok) { box.textContent = plan.error; return plan; }
  const k = plan.parts.length;
  const shown = plan.parts.slice(0, 6).map((p) => `${p.label} (${p.positions.length})`).join(' · ');
  box.innerHTML = '';
  const b = document.createElement('b');
  b.textContent = k === 1 ? '1 berkas PDF' : `${k} berkas, dikemas dalam ZIP`;
  box.append(b, document.createTextNode(` — ${shown}${k > 6 ? ' …' : ''}`));
  return plan;
}

function openSplit() {
  const n = state.pages.length;
  const sel = state.selected.size;
  $('#split-info').textContent = `Dokumen saat ini: ${plural(n, 'halaman')}. Nomor halaman mengikuti urutan di layar.`;
  const radios = [...splitForm.elements.mode];
  radios.find((r) => r.value === 'selected').disabled = sel === 0;
  $('#sel-hint').textContent = sel ? `Ekstrak ${sel} halaman ke satu berkas` : 'Pilih halaman di layar utama dahulu';
  radios.find((r) => r.value === (sel ? 'selected' : 'ranges')).checked = true;
  $('#in-every').max = n;
  refreshSplit();
  $('#dlg-split').showModal();
  if (!sel) $('#in-ranges').focus();
}
splitForm.addEventListener('input', refreshSplit);
splitForm.addEventListener('change', () => { refreshSplit(); if (splitMode() === 'ranges') $('#in-ranges').focus(); if (splitMode() === 'every') $('#in-every').select(); });
splitForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const plan = refreshSplit();
  if (!plan.ok) return;
  $('#dlg-split').close();
  const base = baseName();
  const items = state.pages.map(itemOf);
  try {
    const out = [];
    for (const [i, part] of plan.parts.entries()) {
      busy(plan.parts.length > 1 ? `Membuat berkas ${i + 1} dari ${plan.parts.length}…` : 'Membuat berkas…', i / plan.parts.length);
      await raf();
      const bytes = await ops.build(part.positions.map((k) => items[k]), getLib);
      out.push({ name: `${base}-${part.label}.pdf`, data: bytes });
    }
    if (out.length === 1) {
      download(new Blob([out[0].data], { type: 'application/pdf' }), out[0].name);
      toast(`${out[0].name} diunduh.`);
    } else {
      busy('Mengemas ZIP…', 0.98);
      await raf();
      download(new Blob([makeZip(out)], { type: 'application/zip' }), `${base}-pisah.zip`);
      toast(`${out.length} berkas diunduh dalam ZIP.`);
    }
  } catch (err) {
    console.error(err);
    toast('Gagal memisah PDF: ' + (err?.message || err), { error: true });
  } finally { unbusy(); }
});

/* ------------------------------------------------------------ pratinjau */
const pv = { dlg: $('#dlg-preview'), cv: $('#pv-canvas'), i: 0, task: null, token: 0 };
async function showPreview(i) {
  i = clamp(i, 0, state.pages.length - 1);
  pv.i = i;
  const p = state.pages[i];
  const token = ++pv.token;
  $('#pv-title').textContent = `Halaman ${i + 1} dari ${state.pages.length}`;
  $('#pv-prev').disabled = i === 0;
  $('#pv-next').disabled = i === state.pages.length - 1;
  state.focusId = p.id;
  pv.task?.cancel();
  const body = $('#pv-body');
  const maxW = Math.max(200, body.clientWidth - 24);
  const maxH = Math.max(200, body.clientHeight - 24);
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const rot = (((p.rot % 360) + 360) % 360);
  const swap = rot % 180 !== 0;
  try {
    const res = await composite(p, (w, h) => Math.min(maxW / (swap ? h : w), maxH / (swap ? w : h)) * dpr, {
      onTask: (t) => { pv.task = t; }, alive: () => token === pv.token,
    });
    if (!res || token !== pv.token) return;
    const src = res.canvas;
    const cw = swap ? src.height : src.width; const ch = swap ? src.width : src.height;
    const cv = pv.cv;
    cv.width = cw; cv.height = ch;
    cv.style.width = Math.round(cw / dpr) + 'px'; cv.style.height = Math.round(ch / dpr) + 'px';
    const g = cv.getContext('2d');
    g.save(); g.translate(cw / 2, ch / 2); g.rotate((rot * Math.PI) / 180); g.drawImage(src, -src.width / 2, -src.height / 2); g.restore();
    src.width = src.height = 0;
  } catch (e) {
    if (e?.name !== 'RenderingCancelledException') console.warn(e);
  }
}
function openPreview(id) {
  const i = indexOfId(id);
  if (i < 0) return;
  pv.dlg.showModal();
  requestAnimationFrame(() => showPreview(i));
}
$('#pv-prev').onclick = () => showPreview(pv.i - 1);
$('#pv-next').onclick = () => showPreview(pv.i + 1);
$('#pv-close').onclick = () => pv.dlg.close();
pv.dlg.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') { e.preventDefault(); showPreview(pv.i - 1); }
  if (e.key === 'ArrowRight') { e.preventDefault(); showPreview(pv.i + 1); }
});
pv.dlg.addEventListener('close', () => {
  pv.task?.cancel(); pv.token++;
  pv.cv.width = pv.cv.height = 0;
  cards.get(state.focusId)?.focus({ preventScroll: true });
});
window.addEventListener('resize', () => { if (pv.dlg.open) showPreview(pv.i); });

/* ------------------------------------------------------------ seret & urut */
const drag = { active: false, pending: null, ids: [], ghost: null, insertAt: 0, x: 0, y: 0, raf: 0, suppressClick: false };

el.grid.addEventListener('pointerdown', (e) => {
  if (e.button !== 0 && e.pointerType === 'mouse') return;
  const c = e.target.closest('.card');
  if (!c || drag.active) return;
  const id = Number(c.dataset.id);
  const touch = e.pointerType !== 'mouse';
  drag.pending = { id, x: e.clientX, y: e.clientY, pid: e.pointerId, touch, timer: 0, ready: !touch };
  if (touch) drag.pending.timer = setTimeout(() => { if (drag.pending) { drag.pending.ready = true; startDrag(); navigator.vibrate?.(10); } }, 380);
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointercancel', onCancel);
});

function onMove(e) {
  const pend = drag.pending;
  if (!pend || e.pointerId !== pend.pid) return;
  drag.x = e.clientX; drag.y = e.clientY;
  if (!drag.active) {
    const moved = Math.hypot(e.clientX - pend.x, e.clientY - pend.y);
    if (pend.touch && !pend.ready) { if (moved > 10) cleanupPending(); return; }
    if (moved > 5) startDrag();
    return;
  }
  e.preventDefault();
  updateDrag();
}
function cleanupPending() {
  clearTimeout(drag.pending?.timer);
  drag.pending = null;
  window.removeEventListener('pointermove', onMove);
  window.removeEventListener('pointerup', onUp);
  window.removeEventListener('pointercancel', onCancel);
}
function startDrag() {
  const pend = drag.pending;
  if (!pend || drag.active) return;
  drag.active = true;
  drag.x = pend.x; drag.y = pend.y;
  const grabbed = pend.id;
  drag.ids = state.selected.has(grabbed) && state.selected.size > 1
    ? state.pages.filter((p) => state.selected.has(p.id)).map((p) => p.id)
    : [grabbed];
  drag.suppressClick = true;
  document.body.classList.add('dragging');
  for (const id of drag.ids) cards.get(id)?.classList.add('dragging-src');

  const src = cards.get(grabbed);
  const g = document.createElement('div');
  g.className = 'ghost' + (drag.ids.length > 1 ? ' stack' : '');
  const gc = document.createElement('canvas');
  const sc = $('canvas', src);
  gc.width = sc.width || 100; gc.height = sc.height || 140;
  if (sc.width) gc.getContext('2d').drawImage(sc, 0, 0);
  else { gc.getContext('2d').fillStyle = '#fff'; gc.getContext('2d').fillRect(0, 0, gc.width, gc.height); }
  g.append(gc);
  if (drag.ids.length > 1) { const n = document.createElement('span'); n.className = 'n'; n.textContent = drag.ids.length; g.append(n); }
  document.body.append(g);
  drag.ghost = g;
  const r = $('.thumb', src).getBoundingClientRect();
  drag.grab = { dx: clamp((pend.x - r.left) / r.width, 0, 1), dy: clamp((pend.y - r.top) / r.height, 0, 1) };
  // Cegah halaman ikut bergulir saat menyeret di layar sentuh.
  window.addEventListener('touchmove', blockTouch, { passive: false });
  updateDrag();
  drag.raf = requestAnimationFrame(autoScroll);
}
const blockTouch = (e) => e.cancelable && e.preventDefault();

function updateDrag() {
  const g = drag.ghost;
  const w = g.offsetWidth; const h = g.offsetHeight;
  g.style.transform = `translate(${drag.x - drag.grab.dx * w}px, ${drag.y - drag.grab.dy * h}px) rotate(2deg)`;

  // Cari kartu di bawah penunjuk (abaikan kartu yang sedang dipindahkan).
  const moving = new Set(drag.ids);
  let target = null;
  const hit = document.elementFromPoint(drag.x, drag.y)?.closest?.('.card');
  if (hit && !moving.has(Number(hit.dataset.id))) target = hit;
  if (!target) target = nearestCard(moving);

  const rest = state.pages.filter((p) => !moving.has(p.id));
  const ind = el.indicator;
  if (!target) { // tidak ada kartu lain (semua dipindahkan)
    drag.insertAt = 0; ind.hidden = true; return;
  }
  const r = target.getBoundingClientRect();
  const after = drag.x > r.left + r.width / 2;
  const tIdx = rest.findIndex((p) => p.id === Number(target.dataset.id));
  drag.insertAt = tIdx + (after ? 1 : 0);

  const wr = el.wrap.getBoundingClientRect();
  const tr = $('.thumb', target).getBoundingClientRect();
  ind.hidden = false;
  ind.style.left = (after ? r.right : r.left) - wr.left - 1.5 + 'px';
  ind.style.top = tr.top - wr.top + 'px';
  ind.style.height = tr.height + 'px';
}
function nearestCard(moving) {
  let best = null; let bd = Infinity;
  for (const [id, c] of cards) {
    if (moving.has(id)) continue;
    const r = c.getBoundingClientRect();
    if (r.bottom < -200 || r.top > innerHeight + 200) continue;
    const dx = clamp(drag.x, r.left, r.right) - drag.x;
    const dy = clamp(drag.y, r.top, r.bottom) - drag.y;
    const d = dx * dx + dy * dy;
    if (d < bd) { bd = d; best = c; }
  }
  return best;
}
function autoScroll() {
  if (!drag.active) return;
  const edge = 90;
  let dy = 0;
  if (drag.y < edge + 56) dy = -Math.ceil(((edge + 56 - drag.y) / edge) * 16);
  else if (drag.y > innerHeight - edge) dy = Math.ceil(((drag.y - (innerHeight - edge)) / edge) * 16);
  if (dy) { window.scrollBy(0, dy); updateDrag(); }
  drag.raf = requestAnimationFrame(autoScroll);
}
function endDrag(commit) {
  const ids = drag.ids; const at = drag.insertAt;
  cancelAnimationFrame(drag.raf);
  window.removeEventListener('touchmove', blockTouch);
  drag.ghost?.remove(); drag.ghost = null;
  el.indicator.hidden = true;
  document.body.classList.remove('dragging');
  for (const id of ids) cards.get(id)?.classList.remove('dragging-src');
  drag.active = false; drag.ids = [];
  cleanupPending();
  setTimeout(() => { drag.suppressClick = false; }, 0);
  if (commit) {
    // Abaikan jika posisi tidak berubah.
    const set = new Set(ids);
    const rest = state.pages.filter((p) => !set.has(p.id));
    const result = [...rest.slice(0, at), ...state.pages.filter((p) => set.has(p.id)), ...rest.slice(at)];
    if (result.some((p, i) => p.id !== state.pages[i].id)) moveTo(ids, at);
  }
}
function onUp(e) {
  if (!drag.pending || e.pointerId !== drag.pending.pid) return;
  if (drag.active) endDrag(true); else cleanupPending();
}
function onCancel() { if (drag.active) endDrag(false); else cleanupPending(); }

el.grid.addEventListener('contextmenu', (e) => { if (drag.active || drag.pending?.touch) e.preventDefault(); });
el.grid.addEventListener('click', (e) => {
  if (drag.suppressClick) return;
  const c = e.target.closest('.card');
  if (!c) { clearSelection(); return; }
  clickCard(Number(c.dataset.id), e);
});
el.grid.addEventListener('dblclick', (e) => {
  const c = e.target.closest('.card');
  if (c) openPreview(Number(c.dataset.id));
});

/* ------------------------------------------------------------- keyboard */
function focusCard(id, { select = false } = {}) {
  state.focusId = id;
  for (const [pid, c] of cards) c.tabIndex = pid === id ? 0 : -1;
  const c = cards.get(id);
  c?.focus();
  c?.scrollIntoView({ block: 'nearest' });
}
function columns() {
  const cols = getComputedStyle(el.grid).gridTemplateColumns.split(' ').length;
  return Math.max(1, cols);
}

document.addEventListener('keydown', (e) => {
  const t = e.target;
  if (t.closest?.('input, textarea, select, [contenteditable]')) return;
  if (document.querySelector('dialog[open]') || el.menu.matches(':popover-open')) return;
  const mod = e.ctrlKey || e.metaKey;
  const key = e.key.toLowerCase();

  if (mod && key === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
  if (mod && key === 'y') { e.preventDefault(); redo(); return; }
  if (mod && key === 's') { e.preventDefault(); if (state.pages.length) openSave(); return; }
  if (mod && key === 'o') { e.preventDefault(); el.file.click(); return; }
  if (!state.pages.length) return;
  if (mod && key === 'a') { e.preventDefault(); setSelected(state.pages.map((p) => p.id)); return; }
  if (mod || e.altKey) return;

  if (key === 'escape') { clearSelection(); return; }
  if ((key === 'delete' || key === 'backspace') && state.selected.size) { e.preventDefault(); deleteSelected(); return; }
  if (key === 'r' && state.selected.size) { e.preventDefault(); rotate(e.shiftKey ? -90 : 90); return; }

  const fi = indexOfId(state.focusId);
  const inGrid = t.closest?.('.card');
  if (!inGrid || fi < 0) return;
  const cols = columns();
  const move = { arrowleft: -1, arrowright: 1, arrowup: -cols, arrowdown: cols, home: -Infinity, end: Infinity }[key];
  if (move !== undefined) {
    e.preventDefault();
    const ni = clamp(move === -Infinity ? 0 : move === Infinity ? state.pages.length - 1 : fi + move, 0, state.pages.length - 1);
    focusCard(state.pages[ni].id);
    if (e.shiftKey) {
      const a = indexOfId(state.anchor ?? state.focusId);
      const [lo, hi] = a < ni ? [a, ni] : [ni, a];
      setSelected(state.pages.slice(lo, hi + 1).map((p) => p.id));
      focusCard(state.pages[ni].id);
    }
  } else if (key === ' ') {
    e.preventDefault();
    clickCard(state.focusId, { shiftKey: false });
    cards.get(state.focusId)?.focus();
  } else if (key === 'enter') {
    e.preventDefault();
    openPreview(state.focusId);
  }
});

/* ------------------------------------------------------------ tombol UI */
el.btn.add.onclick = el.btn.open.onclick = () => { pendingIntent = null; el.file.click(); };
el.file.addEventListener('change', () => { const f = [...el.file.files]; el.file.value = ''; if (f.length) addFiles(f); });
el.btn.home.onclick = () => { if (state.pages.length) resetAll(true); };
el.btn.undo.onclick = undo;
el.btn.redo.onclick = redo;
el.btn.save.onclick = openSave;
el.btn.split.onclick = openSplit;
$('#tool-merge').onclick = () => el.file.click();
$('#tool-split').onclick = openSplit;
$('#tool-rot-ccw').onclick = () => rotate(-90);
$('#tool-rot-cw').onclick = () => rotate(90);
$('#tool-delete').onclick = deleteSelected;
$('#tool-crop').onclick = () => tools.openCrop();
$('#tool-edit').onclick = () => tools.openEdit();
$('#tool-compress').onclick = () => tools.openCompress();
$('#tool-convert').onclick = () => tools.openConvert();
$('#tool-ocr').onclick = () => tools.openOcr();
$('#tool-watermark').onclick = () => tools.openWatermark();
$('#tool-protect').onclick = () => tools.openProtect();
for (const b of document.querySelectorAll('.feature')) {
  b.addEventListener('click', () => { pendingIntent = b.dataset.feature; el.file.click(); });
}
$('#act-rot-cw').onclick = () => rotate(90);
$('#act-rot-ccw').onclick = () => rotate(-90);
$('#act-left').onclick = () => stepMove(-1);
$('#act-right').onclick = () => stepMove(1);
$('#act-start').onclick = () => moveEdge(false);
$('#act-end').onclick = () => moveEdge(true);
$('#act-delete').onclick = deleteSelected;
$('#act-clear').onclick = clearSelection;

el.menu.addEventListener('click', (e) => {
  const b = e.target.closest('button[data-act]');
  if (!b) return;
  el.menu.hidePopover();
  const odd = (v) => state.pages.filter((_, i) => (i % 2 === 0) === v).map((p) => p.id);
  ({
    'select-all': () => setSelected(state.pages.map((p) => p.id)),
    'select-odd': () => setSelected(odd(true)),
    'select-even': () => setSelected(odd(false)),
    'rotate-all': () => rotate(90, true),
    reverse: () => mutate(() => state.pages.reverse()),
    blank: insertBlank,
    reset: () => resetAll(),
  })[b.dataset.act]?.();
});

/* ------------------------------------------------------- seret berkas PDF */
let dragDepth = 0;
const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
window.addEventListener('dragenter', (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragDepth++; el.veil.hidden = false; });
window.addEventListener('dragover', (e) => { if (hasFiles(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
window.addEventListener('dragleave', (e) => { if (!hasFiles(e)) return; dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) el.veil.hidden = true; });
window.addEventListener('drop', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth = 0; el.veil.hidden = true;
  pendingIntent = null;
  addFiles(e.dataTransfer.files);
});

/* ------------------------------------------------------------------ PWA */
window.addEventListener('beforeunload', (e) => {
  if (state.dirty && state.pages.length) { e.preventDefault(); e.returnValue = ''; }
});

if ('launchQueue' in window) {
  window.launchQueue.setConsumer(async (params) => {
    if (!params.files?.length) return;
    const files = await Promise.all(params.files.map((h) => h.getFile()));
    addFiles(files);
  });
}

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', async () => {
    try {
      const reg = await navigator.serviceWorker.register('./sw.js');
      if (!reg) return;
      // Muat ulang hanya atas permintaan pengguna (tombol di toast) — tidak pernah otomatis,
      // agar pekerjaan yang sedang berjalan tidak hilang. Instalasi pertama tidak memicu apa pun.
      let reloadRequested = false;
      const announce = (w) => toast('Versi baru tersedia.', {
        action: 'Muat ulang',
        ms: 60_000,
        onAction: () => { reloadRequested = true; w.postMessage('SKIP_WAITING'); },
      });
      if (reg.waiting && navigator.serviceWorker.controller) announce(reg.waiting);
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        w?.addEventListener('statechange', () => {
          if (w.state === 'installed' && navigator.serviceWorker.controller) announce(w);
        });
      });
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (!reloadRequested) return;
        reloadRequested = false;
        location.reload(); // bila ada perubahan belum tersimpan, browser akan meminta konfirmasi
      });
    } catch (e) { console.warn('Service worker gagal didaftarkan', e); }
  });
}

const tools = initTools({
  $, state, mutate, toast, busy, unbusy, raf, dims, pageById, indexOfId, clamp, plural, sanitize,
  ops, itemOf, getLib, baseName, download, pageSize, drawRaw, pageHasText, pdfjsLib, PDFJS_OPTS, PDFLib: window.PDFLib, composite,
});

// Tes & debugging: hanya baca.
window.__rumi = { state, addFiles };
render();
