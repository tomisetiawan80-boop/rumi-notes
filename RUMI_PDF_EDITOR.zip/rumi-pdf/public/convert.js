// Konversi PDF → gambar (PNG/JPG), Word (.docx), dan Excel (.xlsx).
// Dimuat hanya saat dipakai (import dinamis dari tools.js). Seluruh proses berjalan di browser.
//
// Catatan jujur tentang mutu: Word & Excel dibangun dari POSISI teks (pdf.js), bukan dari struktur dokumen asli
// (PDF memang tidak menyimpan paragraf/tabel). Hasilnya heuristik: bagus untuk dokumen satu kolom dan tabel
// berkolom rapi; kurang tepat untuk tata letak kolom ganda, tabel bergaris tanpa jarak, dan gambar/grafik.
import { makeZip } from './zip.js';

/* =================================================================== util */
const enc = new TextEncoder();
// eslint-disable-next-line no-control-regex
const BAD_XML = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g;
export const xmlEsc = (s) => String(s ?? '').replace(BAD_XML, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const r05 = (n) => Math.round(n * 2) / 2;
const mostCommon = (pairs) => { // [[nilai, bobot], ...] → nilai berbobot terbesar
  const m = new Map();
  for (const [k, w] of pairs) m.set(k, (m.get(k) || 0) + w);
  let best = null; let bw = -1;
  for (const [k, w] of m) if (w > bw) { best = k; bw = w; }
  return best;
};

/* ============================================================ angka (Excel) */
const ID_RE = /^(\d{1,3}(\.\d{3})+|\d+)(,\d+)?$/;
const EN_RE = /^(\d{1,3}(,\d{3})+|\d+)(\.\d+)?$/;

/**
 * Teks → angka. mode: 'id' (1.234,56) atau 'en' (1,234.56). Mengembalikan {v, fmt} atau null (tetap teks).
 * Sengaja konservatif: nomor panjang (NPWP, rekening, telepon), angka berawalan nol, tanggal, dan pola ambigu tetap teks.
 */
export function parseNumber(raw, mode) {
  let s = String(raw ?? '').trim();
  if (!s || s.length > 28) return null;
  let neg = false; let pct = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1).trim(); }
  const lead = /^[-−–]\s*/.exec(s);
  if (lead) { neg = true; s = s.slice(lead[0].length); }
  s = s.replace(/^(Rp\.?|IDR|USD|US\$|\$|€|£)\s*/i, '');
  if (s.endsWith('%')) { pct = true; s = s.slice(0, -1).trim(); }
  const re = mode === 'en' ? EN_RE : ID_RE;
  if (!re.test(s)) return null;
  const thou = mode === 'en' ? ',' : '.'; const dec = mode === 'en' ? '.' : ',';
  const [intPart, frac = ''] = s.split(dec);
  const hasSep = intPart.includes(thou);
  const digits = intPart.split(thou).join('');
  if (!hasSep && digits.length > 1 && digits.startsWith('0')) return null; // 00123 → teks
  if (!hasSep && digits.length >= 10) return null; // nomor panjang tanpa pemisah → teks
  if (digits.length > 15) return null;
  let v = Number(`${digits}${frac ? '.' + frac : ''}`);
  if (!Number.isFinite(v)) return null;
  if (neg) v = -v;
  const d = frac.length;
  if (pct) return { v: v / 100, fmt: `0${d ? '.' + '0'.repeat(d) : ''}%` };
  if (hasSep) return { v, fmt: `#,##0${d ? '.' + '0'.repeat(d) : ''}` };
  if (d) return { v, fmt: `0.${'0'.repeat(d)}` };
  return { v, fmt: null }; // bilangan bulat polos (mis. tahun 2024) → format Umum, tidak diberi pemisah ribuan
}

/** Menebak konvensi angka dari seluruh isi sel. Seri → Indonesia. */
export function detectNumberMode(texts) {
  let id = 0; let en = 0;
  for (const t of texts) {
    const s = String(t).replace(/^[(\-−–]\s*|\)$/g, '').replace(/^(Rp\.?|IDR|USD|US\$|\$|€|£)\s*/i, '').replace(/%$/, '').trim();
    if (/^\d{1,3}(\.\d{3})+,\d+$/.test(s) || /^\d+,\d{1,2}$/.test(s)) id++;
    else if (/^\d{1,3}(,\d{3})+\.\d+$/.test(s) || /^\d+\.\d{1,2}$/.test(s)) en++;
    else if (/^\d{1,3}(\.\d{3}){2,}$/.test(s)) id++;
    else if (/^\d{1,3}(,\d{3}){2,}$/.test(s)) en++;
  }
  return en > id ? 'en' : 'id';
}

/* ====================================================== teks → baris/sel */
/**
 * items: [{str, x, y, w, size}] pada koordinat tampilan (y menurun ke bawah, y = garis dasar, satuan pt).
 * Mengembalikan baris berurutan atas→bawah.
 */
export function groupLines(items) {
  const its = items.filter((i) => i.str.trim() !== '').sort((a, b) => a.y - b.y || a.x - b.x);
  const lines = [];
  for (const it of its) {
    const last = lines[lines.length - 1];
    if (last && Math.abs(it.y - last.y) <= Math.max(1.5, 0.45 * Math.min(it.size, last.size))) {
      last.items.push(it);
      last.y = (last.y * (last.items.length - 1) + it.y) / last.items.length;
    } else lines.push({ y: it.y, items: [it], size: 0 });
  }
  for (const l of lines) {
    l.items.sort((a, b) => a.x - b.x);
    l.size = mostCommon(l.items.map((i) => [r05(i.size), i.str.trim().length]));
    l.x0 = l.items[0].x;
    l.x1 = Math.max(...l.items.map((i) => i.x + i.w));
  }
  return lines;
}

/** Memecah baris menjadi sel: jarak antar-item > gapFactor × ukuran font = pindah sel. */
export function cellsOf(line, gapFactor) {
  const cells = [];
  let cur = null;
  const thr = Math.max(5, gapFactor * line.size);
  for (const it of line.items) {
    const gap = cur ? it.x - cur.x1 : 0;
    if (!cur || gap > thr) {
      cur = { text: it.str, x0: it.x, x1: it.x + it.w };
      cells.push(cur);
    } else {
      const space = gap > 0.15 * line.size && !/\s$/.test(cur.text) && !/^\s/.test(it.str);
      cur.text += (space ? ' ' : '') + it.str;
      cur.x1 = it.x + it.w;
    }
  }
  for (const c of cells) c.text = c.text.replace(/\s+/g, ' ').trim();
  return cells.filter((c) => c.text);
}

/* ============================================================ Word: paragraf */
const NUMERIC = /^[(\-−–]?\s*(Rp\.?\s?|IDR\s?|\$\s?)?[\d.,]+\s*\)?\s*%?$/;
const LIST_START = /^(\u2022|[-–•·▪◦]|\(?[0-9a-zA-Z]{1,3}[.)])\s/;

/**
 * Baris → paragraf. Baris yang punya ≥2 sel berjarak lebar dianggap berbentuk tabel dan dipertahankan per baris (dipisah tab).
 * Mengembalikan [{text, size, heading, align, tabbed}].
 */
export function buildParagraphs(lines, { width } = {}) {
  const L = lines.map((l) => {
    const cells = cellsOf(l, 1.5);
    return { ...l, cells, tabbed: cells.length >= 2, text: '' };
  }).filter((l) => l.cells.length);
  for (const l of L) l.text = l.cells.map((c) => c.text).join(l.tabbed ? '\t' : ' ');
  const prose = L.filter((l) => !l.tabbed);
  const base = prose.length ? prose : L;
  const body = mostCommon(base.map((l) => [r05(l.size), l.text.length])) ?? 11;
  const long = base.filter((l) => l.text.length >= 15);
  const ref = long.length ? long : base;
  const left = ref.length ? Math.min(...ref.map((l) => l.x0)) : 0;
  const right = ref.length ? Math.max(...ref.map((l) => l.x1)) : width || 0;
  const textW = Math.max(1, right - left);
  const paras = [];
  let prev = null;
  for (const l of L) {
    const cur = paras[paras.length - 1];
    let brk = !cur || l.tabbed || cur.tabbed;
    if (!brk) {
      const gap = l.y - prev.y;
      const short = prev.x1 < right - 0.25 * textW;
      const shortish = prev.x1 < right - 0.12 * textW && /[.!?:;]$/.test(prev.text);
      brk = gap > prev.size * 1.75
        || Math.abs(l.size - prev.size) > 1
        || l.x0 > prev.x0 + 0.8 * l.size
        || LIST_START.test(l.text)
        || short || shortish;
    }
    if (brk) {
      paras.push({ text: l.text, size: l.size, tabbed: l.tabbed, cells: l.tabbed ? l.cells : null, x0: l.x0, x1: l.x1, lines: 1, gapBefore: prev ? l.y - prev.y : 0 });
    } else {
      const t = cur.text;
      cur.text = t.endsWith('-') && /^[a-zà-ÿ]/.test(l.text) ? t.slice(0, -1) + l.text : `${t} ${l.text}`;
      cur.x0 = Math.min(cur.x0, l.x0); cur.x1 = Math.max(cur.x1, l.x1); cur.lines++;
    }
    prev = l;
  }
  // Blok baris bertab berurutan = tabel: tentukan kolom, lalu beri tab stop yang sama agar kolom sejajar
  // (sel kosong tetap menghasilkan tab sehingga kolom tidak bergeser).
  for (let i = 0; i < paras.length;) {
    if (!paras[i].tabbed) { i++; continue; }
    let j = i;
    while (j < paras.length && paras[j].tabbed) j++;
    const block = paras.slice(i, j);
    const bands = [];
    for (const [a, b] of block.flatMap((p) => p.cells.map((c) => [c.x0, c.x1])).sort((x, y) => x[0] - y[0])) {
      const last = bands[bands.length - 1];
      if (last && a <= last[1] + 1.5) last[1] = Math.max(last[1], b); else bands.push([a, b]);
    }
    const colOf = (c) => {
      const m = (c.x0 + c.x1) / 2;
      let best = 0; let bd = Infinity;
      bands.forEach((b, k) => { const d = m >= b[0] && m <= b[1] ? 0 : Math.min(Math.abs(m - b[0]), Math.abs(m - b[1])); if (d < bd) { bd = d; best = k; } });
      return best;
    };
    const numeric = bands.map(() => ({ n: 0, t: 0 }));
    for (const p of block) for (const c of p.cells) { const k = colOf(c); numeric[k].t++; if (NUMERIC.test(c.text)) numeric[k].n++; }
    const implicit0 = bands[0][0] - left < 6;
    const stops = [];
    bands.forEach((b, k) => {
      if (k === 0 && implicit0) return;
      const right = numeric[k].t > 0 && numeric[k].n / numeric[k].t >= 0.6;
      stops.push({ type: right ? 'right' : 'left', pos: Math.max(0, Math.round(((right ? b[1] : b[0]) - left) * 20)) });
    });
    for (const p of block) {
      let prevCol = implicit0 ? 0 : -1;
      let text = '';
      p.cells.forEach((cell, n) => {
        const k = colOf(cell);
        let tabs = k - prevCol;
        if (n > 0 && tabs < 1) tabs = 1; // dua sel di kolom yang sama → satu tab
        text += '\t'.repeat(Math.max(0, tabs)) + cell.text;
        prevCol = k;
      });
      p.text = text;
      p.tabs = stops;
    }
    i = j;
  }
  const mid = (left + right) / 2;
  for (const p of paras) {
    p.heading = !p.tabbed && p.size >= body * 1.2;
    p.align = 'left';
    if (!p.tabbed && p.lines === 1) {
      const c = (p.x0 + p.x1) / 2;
      const lm = p.x0 - left; const rm = right - p.x1;
      if (Math.abs(lm - rm) < 0.03 * textW && lm > 0.02 * textW) p.align = 'center';
      else if (p.x1 > right - 0.01 * textW && p.x0 > left + 0.4 * textW) p.align = 'right';
    }
  }
  return paras;
}

/* ============================================================ Excel: tabel */
/**
 * Baris → grid sel. Kolom ditentukan dari irisan jarak horizontal sel pada baris-baris bersel ganda ("gutter").
 * Mengembalikan {rows: string[][], cols}.
 */
export function buildGrid(lines) {
  const rows = lines.map((l) => ({ y: l.y, size: l.size, cells: cellsOf(l, 0.9) })).filter((r) => r.cells.length);
  if (!rows.length) return { rows: [], cols: 0 };
  const multi = rows.filter((r) => r.cells.length >= 2);
  let bands = [];
  if (multi.length) {
    const iv = multi.flatMap((r) => r.cells.map((c) => [c.x0, c.x1])).sort((a, b) => a[0] - b[0]);
    for (const [a, b] of iv) {
      const last = bands[bands.length - 1];
      if (last && a <= last[1] + 1.5) last[1] = Math.max(last[1], b); else bands.push([a, b]);
    }
  } else bands = [[0, Infinity]];
  const colOf = (c, single) => {
    const probe = single ? c.x0 : (c.x0 + c.x1) / 2;
    let best = 0; let bd = Infinity;
    bands.forEach((b, i) => {
      const d = probe >= b[0] && probe <= b[1] ? 0 : Math.min(Math.abs(probe - b[0]), Math.abs(probe - b[1]));
      if (d < bd) { bd = d; best = i; }
    });
    return best;
  };
  const out = [];
  let prev = null;
  for (const r of rows) {
    if (prev && r.y - prev.y > Math.max(prev.size, r.size) * 2.2) out.push([]);
    const row = [];
    for (const c of r.cells) {
      const i = multi.length ? colOf(c, r.cells.length === 1) : 0;
      row[i] = row[i] ? `${row[i]} ${c.text}` : c.text;
    }
    out.push(row);
    prev = r;
  }
  return { rows: out, cols: bands.length };
}

/* ================================================================ DOCX */
const NS_W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const EMU = 12700;

function runXml(text, { size, bold, italic, color } = {}) {
  const pr = [bold ? '<w:b/>' : '', italic ? '<w:i/>' : '', color ? `<w:color w:val="${color}"/>` : '', size ? `<w:sz w:val="${Math.round(size * 2)}"/><w:szCs w:val="${Math.round(size * 2)}"/>` : ''].join('');
  const parts = String(text).split('\t');
  const body = parts.map((t, i) => `${i ? '<w:tab/>' : ''}<w:t xml:space="preserve">${xmlEsc(t)}</w:t>`).join('');
  return `<w:r>${pr ? `<w:rPr>${pr}</w:rPr>` : ''}${body}</w:r>`;
}
const clampSize = (s) => Math.min(72, Math.max(6, s));

/**
 * pages: [{w, h, paragraphs, image?: {bytes, wPx, hPx, mime}, note?: string}]  (w,h dalam pt)
 * Mengembalikan Uint8Array (.docx).
 */
export function buildDocx(pages) {
  const media = [];
  let body = '';
  let pid = 0;
  pages.forEach((pg, pi) => {
    let first = true;
    const pb = () => { if (pi > 0 && first) { first = false; return '<w:pageBreakBefore/>'; } first = false; return ''; };
    const margin = 72;
    const maxW = Math.max(100, (pages[0].w || 595) - 2 * margin);
    if (pg.image) {
      const n = media.length + 1;
      media.push({ name: `image${n}.${pg.image.mime === 'image/png' ? 'png' : 'jpeg'}`, rid: `rId${100 + n}`, data: pg.image.bytes, mime: pg.image.mime });
      const k = Math.min(1, maxW / pg.image.wPx, 640 / pg.image.hPx);
      const cx = Math.round(pg.image.wPx * k * EMU * 0.75); const cy = Math.round(pg.image.hPx * k * EMU * 0.75);
      const m = media[media.length - 1];
      pid++;
      body += `<w:p><w:pPr>${pb()}<w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${pid}" name="Halaman ${pi + 1}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="${pid}" name="${m.name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${m.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;
      return;
    }
    if (!pg.paragraphs?.length) {
      body += `<w:p><w:pPr>${pb()}</w:pPr>${runXml(pg.note || `[Halaman ${pi + 1} tidak berisi teks]`, { italic: true, color: '808080' })}</w:p>`;
      return;
    }
    for (const p of pg.paragraphs) {
      const jc = p.align && p.align !== 'left' ? `<w:jc w:val="${p.align}"/>` : '';
      const sp = `<w:spacing w:after="${p.tabbed ? 0 : p.heading ? 160 : 120}"/>`;
      const maxPos = Math.max(0, Math.round(((pages[0]?.w || 595) - 144) * 20));
      const tabs = p.tabs?.length ? `<w:tabs>${p.tabs.map((t) => `<w:tab w:val="${t.type}" w:pos="${Math.min(t.pos, maxPos)}"/>`).join('')}</w:tabs>` : '';
      body += `<w:p><w:pPr>${p.heading ? '<w:keepNext/>' : ''}${pb()}${tabs}${sp}${jc}</w:pPr>${runXml(p.text, { size: clampSize(p.size), bold: p.heading })}</w:p>`;
    }
  });
  const w0 = Math.round((pages[0]?.w || 595.28) * 20); const h0 = Math.round((pages[0]?.h || 841.89) * 20);
  const sect = `<w:sectPr><w:pgSz w:w="${w0}" w:h="${h0}"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>`;
  const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:document xmlns:w="${NS_W}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>${body}${sect}</w:body></w:document>`;
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:styles xmlns:w="${NS_W}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="id-ID"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="259" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style></w:styles>`;
  const types = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>`;
  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`;
  const docRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>${media.map((m) => `<Relationship Id="${m.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${m.name}"/>`).join('')}</Relationships>`;
  return makeZip([
    { name: '[Content_Types].xml', data: enc.encode(types) },
    { name: '_rels/.rels', data: enc.encode(rels) },
    { name: 'word/document.xml', data: enc.encode(doc) },
    { name: 'word/styles.xml', data: enc.encode(styles) },
    { name: 'word/_rels/document.xml.rels', data: enc.encode(docRels) },
    ...media.map((m) => ({ name: `word/media/${m.name}`, data: m.data })),
  ]);
}

/* ================================================================ XLSX */
const colName = (i) => { let s = ''; for (let n = i + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s; return s; };

/**
 * sheets: [{name, rows: string[][]}]; numMode: 'id' | 'en' | 'text'.
 * Sel yang terbaca sebagai angka disimpan sebagai angka sungguhan (bisa dijumlah di Excel).
 */
export function buildXlsx(sheets, numMode = 'id') {
  const fmts = new Map(); // format → indeks xf
  const xfOf = (fmt) => { if (!fmt) return 0; if (!fmts.has(fmt)) fmts.set(fmt, fmts.size + 1); return fmts.get(fmt); };
  let numCells = 0;
  const used = new Set();
  const names = sheets.map((s, i) => {
    let n = String(s.name || `Lembar${i + 1}`).replace(/[\\/?*[\]:]/g, ' ').trim().slice(0, 31) || `Lembar${i + 1}`;
    let k = 2; const base = n;
    while (used.has(n.toLowerCase())) n = `${base.slice(0, 28)} ${k++}`;
    used.add(n.toLowerCase());
    return n;
  });
  const sheetXml = sheets.map((s) => {
    const widths = [];
    const rowsXml = s.rows.map((row, ri) => {
      const cells = [];
      for (let ci = 0; ci < row.length; ci++) {
        const raw = row[ci];
        if (raw == null || raw === '') continue;
        const ref = `${colName(ci)}${ri + 1}`;
        const num = numMode === 'text' ? null : parseNumber(raw, numMode);
        widths[ci] = Math.max(widths[ci] || 0, Math.min(60, String(raw).length));
        if (num) {
          numCells++;
          const xf = xfOf(num.fmt);
          cells.push(`<c r="${ref}"${xf ? ` s="${xf}"` : ''}><v>${num.v}</v></c>`);
        } else {
          cells.push(`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEsc(String(raw).slice(0, 32000))}</t></is></c>`);
        }
      }
      return cells.length ? `<row r="${ri + 1}">${cells.join('')}</row>` : '';
    }).join('');
    const cols = widths.length ? `<cols>${widths.map((w, i) => (w ? `<col min="${i + 1}" max="${i + 1}" width="${Math.max(8, Math.round(w * 1.15 + 2))}" customWidth="1"/>` : '')).join('')}</cols>` : '';
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${cols}<sheetData>${rowsXml}</sheetData></worksheet>`;
  });
  const fmtList = [...fmts.keys()];
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${fmtList.length ? `<numFmts count="${fmtList.length}">${fmtList.map((f, i) => `<numFmt numFmtId="${164 + i}" formatCode="${xmlEsc(f)}"/>`).join('')}</numFmts>` : ''}<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${fmtList.length + 1}"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>${fmtList.map((f, i) => `<xf numFmtId="${164 + i}" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>`).join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const wb = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xmlEsc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`;
  const wbRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${names.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${names.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
  const types = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${names.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`;
  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const bytes = makeZip([
    { name: '[Content_Types].xml', data: enc.encode(types) },
    { name: '_rels/.rels', data: enc.encode(rels) },
    { name: 'xl/workbook.xml', data: enc.encode(wb) },
    { name: 'xl/_rels/workbook.xml.rels', data: enc.encode(wbRels) },
    { name: 'xl/styles.xml', data: enc.encode(styles) },
    ...sheetXml.map((x, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: enc.encode(x) })),
  ]);
  return { bytes, numCells };
}

/* ====================================================== UI & orkestrasi */
const MIME = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
};
const fmtSize = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(2)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

export function initConvert(ctx) {
  const { $, state, toast, busy, unbusy, raf, indexOfId, plural, sanitize, ops, itemOf, getLib, baseName, download, pdfjsLib, PDFJS_OPTS, composite } = ctx;
  const dlg = $('#dlg-convert');
  const form = $('#form-convert');
  const radios = (name) => [...document.getElementsByName(name)];
  const val = (name) => radios(name).find((r) => r.checked)?.value;

  const NOTES = {
    image: 'Setiap halaman jadi satu gambar, sesuai tampilan di layar (termasuk potongan, teks tambahan, dan watermark). Banyak halaman diunduh dalam satu berkas ZIP.',
    word: 'Teks diambil dari posisinya di halaman dan disusun menjadi paragraf. Tata letak tidak identik: tabel menjadi teks bertab, kolom ganda bisa tertukar, gambar dan garis tidak ikut. Halaman scan perlu OCR dulu.',
    excel: 'Kolom ditebak dari posisi teks, lalu isi yang berbentuk angka disimpan sebagai angka. Periksa hasilnya sebelum dipakai untuk angka penting; tabel tanpa jarak antarkolom bisa menyatu.',
  };
  const refresh = () => {
    const f = val('cv-fmt');
    for (const o of dlg.querySelectorAll('.cv-opts')) o.hidden = o.dataset.for !== f;
    $('#cv-note').textContent = NOTES[f];
  };
  form.addEventListener('change', refresh);

  function open() {
    if (!state.pages.length) return;
    const k = state.selected.size;
    const rs = radios('cv-scope').find((r) => r.value === 'selected');
    const ra = radios('cv-scope').find((r) => r.value === 'all');
    rs.disabled = k === 0;
    $('#cv-sel-lbl').textContent = k ? `Halaman terpilih (${k})` : 'Halaman terpilih';
    $('#cv-all-lbl').textContent = `Semua halaman (${state.pages.length})`;
    (k ? rs : ra).checked = true;
    refresh();
    dlg.showModal();
  }

  const rotateCanvas = (src, deg) => {
    const rot = ((deg % 360) + 360) % 360;
    if (!rot) return src;
    const swap = rot % 180 !== 0;
    const out = document.createElement('canvas');
    out.width = swap ? src.height : src.width; out.height = swap ? src.width : src.height;
    const g = out.getContext('2d');
    g.translate(out.width / 2, out.height / 2); g.rotate((rot * Math.PI) / 180); g.drawImage(src, -src.width / 2, -src.height / 2);
    src.width = src.height = 0;
    return out;
  };
  const toBlob = (cv, type, q) => new Promise((r) => cv.toBlob(r, type, q));

  /** Halaman → kanvas pada orientasi tampil. maxPx membatasi total piksel agar tidak kehabisan memori. */
  async function pageCanvas(p, dpi, { watermark = true, maxPx = 40e6, maxSide = Infinity } = {}) {
    const q = watermark ? p : { ...p, wm: undefined };
    const res = await composite(q, (w, h) => {
      let s = dpi / 72;
      const px = w * s * h * s;
      if (px > maxPx) s *= Math.sqrt(maxPx / px);
      if (Math.max(w, h) * s > maxSide) s *= maxSide / (Math.max(w, h) * s);
      return s;
    }, {});
    return rotateCanvas(res.canvas, p.rot || 0);
  }

  async function toImages(targets, cancelled) {
    const type = val('cv-imgtype') === 'jpg' ? 'image/jpeg' : 'image/png';
    const ext = type === 'image/png' ? 'png' : 'jpg';
    const dpi = Number($('#cv-dpi').value) || 150;
    const files = [];
    for (const [i, p] of targets.entries()) {
      if (cancelled()) return null;
      busy(`Merender halaman ${i + 1} dari ${targets.length}…`, i / targets.length, () => { cancelled.flag = true; });
      await raf();
      const cv = await pageCanvas(p, dpi);
      const blob = await toBlob(cv, type, 0.92);
      cv.width = cv.height = 0;
      if (!blob) throw new Error('Peramban gagal membuat gambar (halaman terlalu besar?).');
      files.push({ name: `${baseName()}-hal-${String(indexOfId(p.id) + 1).padStart(3, '0')}.${ext}`, blob });
    }
    if (files.length === 1) {
      download(files[0].blob, files[0].name);
      return `${files[0].name} (${fmtSize(files[0].blob.size)})`;
    }
    busy('Mengemas ZIP…', null);
    await raf();
    const data = [];
    for (const f of files) data.push({ name: f.name, data: new Uint8Array(await f.blob.arrayBuffer()) });
    const zip = new Blob([makeZip(data)], { type: 'application/zip' });
    const name = `${baseName()}-gambar.zip`;
    download(zip, name);
    return `${name}: ${plural(files.length, 'gambar')}, ${fmtSize(zip.size)}`;
  }

  /** Susunan saat ini (tanpa watermark) → PDF sementara → teks tiap halaman pada koordinat tampilan. */
  async function extractTexts(targets, cancelled) {
    busy('Menyusun dokumen…', null, () => { cancelled.flag = true; });
    await raf();
    const built = await ops.build(targets.map((p) => ({ ...itemOf(p), wm: null })), getLib);
    const doc = await pdfjsLib.getDocument({ data: built, ...PDFJS_OPTS }).promise;
    const pages = [];
    try {
      for (let i = 1; i <= doc.numPages; i++) {
        if (cancelled()) return null;
        busy(`Membaca teks halaman ${i} dari ${doc.numPages}…`, i / doc.numPages, () => { cancelled.flag = true; });
        await raf();
        const page = await doc.getPage(i);
        const vp = page.getViewport({ scale: 1 });
        const tc = await page.getTextContent();
        const items = [];
        for (const it of tc.items) {
          if (!it.str || !it.str.trim()) continue;
          const t = pdfjsLib.Util.transform(vp.transform, it.transform);
          const size = Math.hypot(t[2], t[3]);
          if (Math.abs(t[1]) > Math.abs(t[0]) * 0.5) continue; // teks vertikal/miring: dilewati
          if (t[4] < -2 || t[4] > vp.width + 2 || t[5] < -2 || t[5] > vp.height + 2) continue; // di luar area potong
          items.push({ str: it.str, x: t[4], y: t[5], w: it.width * vp.scale, size: size || 10 });
        }
        pages.push({ w: vp.width, h: vp.height, lines: groupLines(items), chars: items.reduce((a, b) => a + b.str.trim().length, 0) });
        page.cleanup();
      }
    } finally { doc.destroy?.(); }
    return pages;
  }

  async function toWord(targets, cancelled) {
    const texts = await extractTexts(targets, cancelled);
    if (!texts) return null;
    const useImg = $('#cv-wordimg').checked;
    let imgPages = 0; let empty = 0; let paraCount = 0;
    const pages = [];
    for (const [i, t] of texts.entries()) {
      if (cancelled()) return null;
      if (t.chars < 3) {
        if (useImg) {
          busy(`Menyisipkan gambar halaman ${i + 1}…`, i / texts.length, () => { cancelled.flag = true; });
          await raf();
          const cv = await pageCanvas(targets[i], 150, { watermark: false, maxSide: 2200 });
          const blob = await toBlob(cv, 'image/jpeg', 0.85);
          const img = { bytes: new Uint8Array(await blob.arrayBuffer()), wPx: cv.width, hPx: cv.height, mime: 'image/jpeg' };
          cv.width = cv.height = 0;
          pages.push({ w: t.w, h: t.h, image: img }); imgPages++;
        } else {
          pages.push({ w: t.w, h: t.h, paragraphs: [], note: `[Halaman ${indexOfId(targets[i].id) + 1} tidak berisi teks. Jalankan OCR dulu agar teksnya terbaca.]` }); empty++;
        }
        continue;
      }
      const paragraphs = buildParagraphs(t.lines, { width: t.w });
      paraCount += paragraphs.length;
      pages.push({ w: t.w, h: t.h, paragraphs });
    }
    if (!paraCount && !imgPages) { toast('PDF ini tidak berisi teks yang bisa dibaca (kemungkinan scan). Jalankan OCR dulu, lalu konversi lagi.', { error: true, ms: 9000 }); return ''; }
    const bytes = buildDocx(pages);
    const name = `${baseName()}.docx`;
    download(new Blob([bytes], { type: MIME.docx }), name);
    return `${name}: ${plural(pages.length, 'halaman')}, ${plural(paraCount, 'paragraf')}${imgPages ? `, ${imgPages} halaman scan disisipkan sebagai gambar` : ''}${empty ? `, ${empty} halaman tanpa teks` : ''}`;
  }

  async function toExcel(targets, cancelled) {
    const texts = await extractTexts(targets, cancelled);
    if (!texts) return null;
    const grids = texts.map((t) => buildGrid(t.lines));
    if (!grids.some((g) => g.rows.length)) { toast('PDF ini tidak berisi teks yang bisa dibaca (kemungkinan scan). Jalankan OCR dulu, lalu konversi lagi.', { error: true, ms: 9000 }); return ''; }
    let mode = val('cv-numfmt') || 'auto';
    const all = grids.flatMap((g) => g.rows.flat().filter(Boolean));
    const detected = mode === 'auto' ? detectNumberMode(all) : mode;
    mode = detected;
    let sheets;
    if (val('cv-sheets') === 'one') {
      const rows = [];
      grids.forEach((g, i) => { if (i && g.rows.length) rows.push([], [`— Halaman ${indexOfId(targets[i].id) + 1} —`]); rows.push(...g.rows); });
      sheets = [{ name: 'Data', rows }];
    } else {
      sheets = grids.map((g, i) => ({ name: `Hal ${indexOfId(targets[i].id) + 1}`, rows: g.rows }));
    }
    const { bytes, numCells } = buildXlsx(sheets, mode);
    const name = `${baseName()}.xlsx`;
    download(new Blob([bytes], { type: MIME.xlsx }), name);
    const nm = { id: 'format Indonesia 1.234,56', en: 'format internasional 1,234.56', text: 'semua sebagai teks' }[mode];
    return `${name}: ${plural(sheets.length, 'lembar')}, ${numCells} sel angka (${nm})`;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = val('cv-fmt');
    const scope = val('cv-scope');
    dlg.close();
    const targets = state.pages.filter((p) => (scope === 'selected' ? state.selected.has(p.id) : true));
    if (!targets.length) return;
    const cancelled = () => cancelled.flag === true;
    cancelled.flag = false;
    try {
      busy('Memulai konversi…', null, () => { cancelled.flag = true; });
      await raf();
      const msg = await (f === 'image' ? toImages : f === 'word' ? toWord : toExcel)(targets, cancelled);
      unbusy();
      if (msg === null) toast('Konversi dibatalkan.');
      else if (msg) toast(msg, { ms: 9000 });
    } catch (err) {
      console.error(err);
      toast('Konversi gagal: ' + (err?.message || err), { error: true, ms: 9000 });
    } finally { unbusy(); }
  });

  return { open };
}
