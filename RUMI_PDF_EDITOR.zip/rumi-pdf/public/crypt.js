// Proteksi PDF dengan kata sandi: Standard Security Handler V5/R6 (PDF 2.0), AES-256.
// Memakai WebCrypto bawaan browser/Node (tanpa dependensi). pdf-lib sendiri tidak bisa mengenkripsi,
// jadi modul ini menyandikan setiap string & stream pada dokumen pdf-lib lalu menambahkan kamus /Encrypt.
//
// Catatan jujur: kata sandi buka (user) benar-benar mengunci isi lewat enkripsi AES-256. Sedangkan izin
// (cetak/salin/ubah) hanya "permintaan" kepada aplikasi pembaca — pembaca yang patuh menghormatinya,
// tetapi tidak semua. Jangan mengandalkan izin untuk melindungi data sensitif; pakai kata sandi buka.

const te = new TextEncoder();
const subtle = () => globalThis.crypto.subtle;
const rand = (n) => globalThis.crypto.getRandomValues(new Uint8Array(n));
const EMPTY = new Uint8Array(0);
const ZERO_IV = new Uint8Array(16);

const concat = (...parts) => {
  const out = new Uint8Array(parts.reduce((a, p) => a + p.length, 0));
  let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
};
const toHex = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, '0')).join('');
const sha = async (bits, data) => new Uint8Array(await subtle().digest(`SHA-${bits}`, data));

/** AES-CBC tanpa padding (data harus kelipatan 16 byte). WebCrypto selalu menambah padding → blok terakhir dibuang. */
async function aesCbcRaw(key, iv, data) {
  const k = await subtle().importKey('raw', key, 'AES-CBC', false, ['encrypt']);
  const out = new Uint8Array(await subtle().encrypt({ name: 'AES-CBC', iv }, k, data));
  return out.subarray(0, data.length);
}

/** Kata sandi → UTF-8, maksimal 127 byte (ISO 32000-2, algoritma 2.A). */
export function passwordBytes(s) {
  const full = te.encode(String(s ?? '').normalize('NFC'));
  if (full.length <= 127) return full;
  let n = 127;
  while (n > 0 && (full[n] & 0xc0) === 0x80) n--; // potong di batas karakter, bukan di tengah
  return full.subarray(0, n);
}

/** Algoritma 2.B (ISO 32000-2): hash iteratif untuk revisi 6. */
export async function hash2B(pw, salt, udata = EMPTY) {
  let K = await sha(256, concat(pw, salt, udata));
  let E = null;
  let i = 0;
  while (i < 64 || E[E.length - 1] > i - 32) {
    const unit = concat(pw, K, udata);
    const K1 = new Uint8Array(unit.length * 64);
    for (let j = 0; j < 64; j++) K1.set(unit, j * unit.length);
    E = await aesCbcRaw(K.subarray(0, 16), K.subarray(16, 32), K1);
    let mod = 0;
    for (let j = 0; j < 16; j++) mod += E[j];
    K = await sha([256, 384, 512][mod % 3], E);
    i++;
  }
  return K.subarray(0, 32);
}

/**
 * Nilai /P dari pilihan izin. Aksesibilitas (pembaca layar) selalu diizinkan.
 * allow = { print, copy, modify, annotate } (boolean; default true).
 */
export function permissionValue(allow = {}) {
  const on = (k) => allow[k] !== false;
  let p = 0xfffff0c0 | 0x200; // bit 7–8 & 13–32 wajib 1; bit 10 = ekstraksi untuk aksesibilitas
  if (on('print')) p |= 0x4 | 0x800; // cetak + cetak kualitas tinggi
  if (on('modify')) p |= 0x8 | 0x400; // ubah isi + susun halaman
  if (on('copy')) p |= 0x10; // salin teks & gambar
  if (on('annotate')) p |= 0x20 | 0x100; // anotasi + isi formulir
  return p | 0; // int32 bertanda
}

/**
 * Membuat parameter enkripsi. Mengembalikan kamus /Encrypt (nilai mentah) dan fungsi penyandi.
 * opts = { userPassword, ownerPassword, permissions }
 */
export async function createEncryption(opts = {}) {
  const upw = passwordBytes(opts.userPassword);
  // Tanpa kata sandi pemilik, pakai yang acak: izin tidak bisa diubah siapa pun (tetap bisa dibuka dengan sandi buka).
  const opw = opts.ownerPassword ? passwordBytes(opts.ownerPassword) : rand(24);
  const P = permissionValue(opts.permissions);
  const fileKey = rand(32);

  const uVal = rand(8); const uKey = rand(8);
  const U = concat(await hash2B(upw, uVal), uVal, uKey);
  const UE = await aesCbcRaw(await hash2B(upw, uKey), ZERO_IV, fileKey);

  const oVal = rand(8); const oKey = rand(8);
  const O = concat(await hash2B(opw, oVal, U), oVal, oKey);
  const OE = await aesCbcRaw(await hash2B(opw, oKey, U), ZERO_IV, fileKey);

  const perms = new Uint8Array(16);
  const dv = new DataView(perms.buffer);
  dv.setInt32(0, P, true);
  dv.setUint32(4, 0xffffffff);
  perms[8] = 0x54; // 'T' = EncryptMetadata true
  perms[9] = 0x61; perms[10] = 0x64; perms[11] = 0x62; // 'adb'
  perms.set(rand(4), 12);
  const Perms = await aesCbcRaw(fileKey, ZERO_IV, perms); // AES-256-ECB satu blok

  const dataKey = await subtle().importKey('raw', fileKey, 'AES-CBC', false, ['encrypt']);
  /** String/stream → IV(16) + AES-256-CBC (padding PKCS#7). */
  const encrypt = async (data) => {
    const iv = rand(16);
    const ct = new Uint8Array(await subtle().encrypt({ name: 'AES-CBC', iv }, dataKey, data));
    return concat(iv, ct);
  };

  return { P, O, U, OE, UE, Perms, encrypt };
}

/**
 * Mengenkripsi dokumen pdf-lib di tempat (belum disimpan). Setelah itu simpan dengan { useObjectStreams: false }.
 * PDFLib = namespace pdf-lib; doc = PDFDocument.
 */
export async function encryptDocument(PDFLib, doc, opts) {
  const { PDFName, PDFNumber, PDFString, PDFHexString, PDFDict, PDFArray, PDFStream, PDFRawStream } = PDFLib;
  const N = (x) => PDFName.of(x);
  const ctx = doc.context;
  const enc = await createEncryption(opts);

  const isStr = (o) => o instanceof PDFString || o instanceof PDFHexString;
  const sealStr = async (o) => PDFHexString.of(toHex(await enc.encrypt(o.asBytes())));

  async function walk(o) {
    if (o instanceof PDFDict) {
      for (const [k, v] of o.entries()) {
        if (isStr(v)) o.set(k, await sealStr(v));
        else if (v instanceof PDFDict || v instanceof PDFArray) await walk(v);
      }
    } else if (o instanceof PDFArray) {
      for (let i = 0; i < o.size(); i++) {
        const v = o.get(i);
        if (isStr(v)) o.set(i, await sealStr(v));
        else if (v instanceof PDFDict || v instanceof PDFArray) await walk(v);
      }
    }
  }

  const objs = [...ctx.enumerateIndirectObjects()];
  for (const [ref, obj] of objs) {
    if (obj instanceof PDFStream) {
      const type = obj.dict.get(N('Type'));
      if (type === N('XRef') || type === N('ObjStm')) continue; // tidak ada karena disimpan tanpa object stream
      await walk(obj.dict);
      const sealed = await enc.encrypt(obj.getContents());
      const dict = obj.dict;
      dict.set(N('Length'), PDFNumber.of(sealed.length));
      ctx.assign(ref, PDFRawStream.of(dict, sealed));
    } else if (isStr(obj)) {
      ctx.assign(ref, await sealStr(obj));
    } else {
      await walk(obj);
    }
  }

  const id = () => PDFHexString.of(toHex(rand(16)));
  ctx.trailerInfo.ID = ctx.obj([id(), id()]);
  const hex = (u8) => PDFHexString.of(toHex(u8));
  ctx.trailerInfo.Encrypt = ctx.register(ctx.obj({
    Filter: N('Standard'),
    V: PDFNumber.of(5),
    R: PDFNumber.of(6),
    Length: PDFNumber.of(256),
    CF: { StdCF: { AuthEvent: N('DocOpen'), CFM: N('AESV3'), Length: PDFNumber.of(32) } },
    StmF: N('StdCF'),
    StrF: N('StdCF'),
    O: hex(enc.O), U: hex(enc.U), OE: hex(enc.OE), UE: hex(enc.UE),
    P: PDFNumber.of(enc.P),
    Perms: hex(enc.Perms),
  }));
}

/** Byte PDF → byte PDF terenkripsi. */
export async function protectPdf(PDFLib, bytes, opts) {
  const doc = await PDFLib.PDFDocument.load(bytes, { updateMetadata: false });
  await encryptDocument(PDFLib, doc, opts);
  return doc.save({ useObjectStreams: false });
}
