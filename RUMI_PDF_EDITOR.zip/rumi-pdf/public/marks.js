// Menggambar anotasi ke kanvas 2D (miniatur, pratinjau, editor). Aturan sama dengan ops.js → hasil PDF konsisten.
import { BASELINE, LINE_H, WM_BASE, normalizeWatermark, normalizeCrop, wmPlace } from './ops.js';

const bitmaps = new WeakMap(); // img → Promise<ImageBitmap>
export function markBitmap(img) {
  if (!bitmaps.has(img)) bitmaps.set(img, createImageBitmap(new Blob([img.bytes], { type: img.mime })));
  return bitmaps.get(img);
}

/** w,h = ukuran kanvas (px); k = piksel per pt. */
export async function paintMarks(ctx, marks, w, h, k) {
  for (const m of marks || []) {
    ctx.save();
    if (m.type === 'text') {
      ctx.fillStyle = m.color;
      ctx.font = `${m.bold ? 700 : 400} ${m.size * k}px Helvetica, Arial, sans-serif`;
      ctx.textBaseline = 'alphabetic';
      String(m.text ?? '').split('\n').forEach((line, i) => ctx.fillText(line, m.x * w, m.y * h + m.size * k * (BASELINE + LINE_H * i)));
    } else if (m.type === 'rect') {
      ctx.fillStyle = m.color;
      if (m.kind === 'hl') { ctx.globalAlpha = 0.55; ctx.globalCompositeOperation = 'multiply'; }
      ctx.fillRect(m.x * w, m.y * h, m.w * w, m.h * h);
    } else if (m.type === 'image' && m.img) {
      try { ctx.drawImage(await markBitmap(m.img), m.x * w, m.y * h, m.w * w, m.h * h); } catch { /* gambar rusak */ }
    }
    ctx.restore();
  }
}

/**
 * Watermark pada kanvas halaman (orientasi dasar, sebelum potongan). k = piksel per pt.
 * extraRot = rotasi pengguna halaman: sudut watermark dihitung agar tampil sama pada hasil akhir.
 */
export async function paintWatermark(ctx, wmIn, w, h, k, { crop, extraRot = 0 } = {}) {
  const wm = normalizeWatermark(wmIn);
  if (!wm) return;
  const c = normalizeCrop(crop) || { l: 0, t: 0, r: 0, b: 0 };
  // Tata letak dihitung dalam pt (sama dengan ops.js), lalu dikalikan k saat menggambar.
  const Wp = w / k; const Hp = h / k;
  const region = { x: c.l * Wp, y: c.t * Hp, w: Wp * (1 - c.l - c.r), h: Hp * (1 - c.t - c.b) };
  const theta = wm.angle + extraRot;
  ctx.save();
  ctx.globalAlpha = wm.opacity;
  let bmp = null; let iw; let ih;
  if (wm.type === 'text') {
    ctx.font = `${wm.bold ? 700 : 400} ${wm.size * k}px Helvetica, Arial, sans-serif`;
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = wm.color;
    iw = ctx.measureText(wm.text).width / k; ih = wm.size;
  } else {
    try { bmp = await markBitmap(wm.img); } catch { ctx.restore(); return; }
    iw = region.w * wm.scale; ih = (iw * wm.img.h) / wm.img.w;
  }
  for (const pt of wmPlace(region, iw, ih, theta, wm.layout)) {
    ctx.save();
    ctx.translate(pt.x * k, pt.y * k);
    ctx.rotate((-theta * Math.PI) / 180);
    if (bmp) ctx.drawImage(bmp, (-iw / 2) * k, (-ih / 2) * k, iw * k, ih * k);
    else ctx.fillText(wm.text, (-iw / 2) * k, wm.size * k * WM_BASE);
    ctx.restore();
  }
  ctx.restore();
}
