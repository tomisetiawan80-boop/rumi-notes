// Logika inti pengolahan PDF (tanpa DOM) — bisa dijalankan di browser maupun Node untuk pengujian.
// PDFLib disuntikkan dari luar: di browser berasal dari vendor/pdf-lib.min.js (window.PDFLib).

const A4 = [595.28, 841.89];

/**
 * Mengurai teks rentang halaman seperti "1-3, 5, 7-" menjadi [[1,3],[5,5],[7,n]] (1-based, inklusif).
 */
export function parseRanges(text, n) {
  const src = String(text ?? '')
    .replace(/[–—−]/g, '-')
    .replace(/\s*-\s*/g, '-')
    .replace(/[;\n]/g, ',')
    .trim();
  if (!src) return { ok: false, error: 'Masukkan rentang halaman, misalnya 1-3, 5, 8-10.' };

  const ranges = [];
  for (const raw of src.split(/[,\s]+/)) {
    const tok = raw.trim();
    if (!tok) continue;
    let m;
    let a;
    let b;
    if ((m = /^(\d+)$/.exec(tok))) {
      a = b = Number(m[1]);
    } else if ((m = /^(\d*)-(\d*)$/.exec(tok)) && (m[1] || m[2])) {
      a = m[1] ? Number(m[1]) : 1;
      b = m[2] ? Number(m[2]) : n;
    } else {
      return { ok: false, error: `Format tidak dikenali: "${tok}".` };
    }
    if (a < 1 || b < 1 || a > n || b > n) {
      return { ok: false, error: `Halaman di luar jangkauan pada "${tok}" (dokumen punya ${n} halaman).` };
    }
    if (a > b) return { ok: false, error: `Rentang terbalik: "${tok}".` };
    ranges.push([a, b]);
  }
  if (!ranges.length) return { ok: false, error: 'Masukkan rentang halaman, misalnya 1-3, 5, 8-10.' };
  return { ok: true, ranges };
}

const label = (a, b) => (a === b ? `${a}` : `${a}-${b}`);

/**
 * Menyusun rencana pemisahan. Setiap bagian = { label, positions: [indeks 0-based pada urutan halaman saat ini] }.
 * mode: 'ranges' | 'every' | 'each' | 'selected'
 */
export function planSplit(mode, n, opts = {}) {
  if (!n) return { ok: false, error: 'Belum ada halaman.' };
  const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a - 1 + i);

  if (mode === 'ranges') {
    const r = parseRanges(opts.text, n);
    if (!r.ok) return r;
    return { ok: true, parts: r.ranges.map(([a, b]) => ({ label: label(a, b), positions: range(a, b) })) };
  }
  if (mode === 'every') {
    const k = Math.floor(Number(opts.every));
    if (!Number.isFinite(k) || k < 1) return { ok: false, error: 'Jumlah halaman per berkas minimal 1.' };
    const parts = [];
    for (let a = 1; a <= n; a += k) {
      const b = Math.min(a + k - 1, n);
      parts.push({ label: label(a, b), positions: range(a, b) });
    }
    return { ok: true, parts };
  }
  if (mode === 'each') {
    return { ok: true, parts: range(1, n).map((i) => ({ label: `${i + 1}`, positions: [i] })) };
  }
  if (mode === 'selected') {
    const pos = [...(opts.positions || [])].sort((x, y) => x - y);
    if (!pos.length) return { ok: false, error: 'Pilih halaman terlebih dahulu di layar utama.' };
    return { ok: true, parts: [{ label: 'terpilih', positions: pos }] };
  }
  return { ok: false, error: 'Mode tidak dikenal.' };
}


/* ------------------------------------------------------------------ geometri, potong, anotasi */
// Posisi garis dasar & tinggi baris teks: dipakai sama persis oleh kanvas, DOM, dan PDF agar hasilnya konsisten.
export const BASELINE = 0.95;
export const LINE_H = 1.2;

// Karakter di luar WinAnsi tidak bisa ditulis dengan font standar PDF (Helvetica).
const BAD = /[^\u0020-\u007e\u00a0-\u00ff\u20ac\u201a\u0192\u201e\u2026\u2020\u2021\u02c6\u2030\u0160\u2039\u0152\u017d\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u02dc\u2122\u0161\u203a\u0153\u017e\u0178]/g;
export function unsupportedChars(text) {
  return [...new Set(String(text ?? '').replace(/[\t\r\n]/g, '').match(BAD) || [])];
}
export function hexRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return [0, 0, 0];
  const n = parseInt(m[1], 16);
  return [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

const norm360 = (a) => (((a % 360) + 360) % 360);

/** Ukuran halaman sebagaimana tampil (setelah rotasi bawaan R), dalam pt. */
export function displayFrame(box, R) {
  const swap = norm360(R) % 180 !== 0;
  return { Wd: swap ? box.height : box.width, Hd: swap ? box.width : box.height };
}
/** Titik tampilan (dx,dy dari kiri-atas, pt) → koordinat ruang pengguna PDF. */
export function toUser(box, R, dx, dy) {
  const { x: bx, y: by, width: w, height: h } = box;
  switch (norm360(R)) {
    case 90: return [bx + dy, by + dx];
    case 180: return [bx + w - dx, by + dy];
    case 270: return [bx + w - dy, by + h - dx];
    default: return [bx + dx, by + h - dy];
  }
}
/** Merapikan potongan {l,t,r,b} (pecahan 0–1 dari lebar/tinggi). null bila tidak berarti / tidak valid. */
export function normalizeCrop(c) {
  if (!c) return null;
  const f = (v) => Math.min(0.95, Math.max(0, Number(v) || 0));
  const r = { l: f(c.l), t: f(c.t), r: f(c.r), b: f(c.b) };
  if (r.l + r.r > 0.95 || r.t + r.b > 0.95) return null;
  if (r.l + r.t + r.r + r.b < 1e-4) return null;
  return r;
}
export function cropToBox(box, R, crop) {
  const { Wd, Hd } = displayFrame(box, R);
  const a = toUser(box, R, crop.l * Wd, crop.t * Hd);
  const b = toUser(box, R, (1 - crop.r) * Wd, (1 - crop.b) * Hd);
  return { x: Math.min(a[0], b[0]), y: Math.min(a[1], b[1]), width: Math.abs(a[0] - b[0]), height: Math.abs(a[1] - b[1]) };
}

/* ------------------------------------------------------------------ watermark */
// Sudut watermark = putaran berlawanan arah jarum jam pada tampilan akhir halaman (derajat).
// Garis dasar teks berada 0,36×ukuran di bawah titik tengah visualnya (dipakai sama oleh kanvas & PDF).
export const WM_BASE = 0.36;

/** Merapikan pengaturan watermark. null bila tidak valid / kosong. */
export function normalizeWatermark(w) {
  if (!w) return null;
  const clamp = (v, a, b, d) => { const n = Number(v); return Number.isFinite(n) ? Math.min(b, Math.max(a, n)) : d; };
  const out = {
    type: w.type === 'image' ? 'image' : 'text',
    layout: w.layout === 'tile' ? 'tile' : 'center',
    opacity: clamp(w.opacity, 0.03, 1, 0.25),
    angle: clamp(w.angle, -360, 360, 45),
  };
  if (out.type === 'image') {
    if (!w.img) return null;
    out.img = w.img;
    out.scale = clamp(w.scale, 0.05, 1, out.layout === 'tile' ? 0.25 : 0.5);
  } else {
    const text = String(w.text ?? '').replace(/\s+/g, ' ').trim();
    if (!text) return null;
    out.text = text;
    out.size = clamp(w.size, 6, 400, 64);
    out.color = /^#[0-9a-f]{6}$/i.test(w.color || '') ? w.color : '#888888';
    out.bold = !!w.bold;
  }
  return out;
}

/**
 * Titik tengah setiap salinan watermark pada area `region` {x,y,w,h} (pt, asal kiri-atas, sumbu y ke bawah).
 * item = ukuran satu salinan (itemW × itemH, sebelum diputar). layout 'center' → satu; 'tile' → pola bata miring.
 */
export function wmPlace(region, itemW, itemH, angle, layout) {
  const cx = region.x + region.w / 2;
  const cy = region.y + region.h / 2;
  if (layout !== 'tile') return [{ x: cx, y: cy }];
  const t = (angle * Math.PI) / 180;
  const c = Math.cos(t); const s = Math.sin(t);
  const dx = itemW + Math.max(itemW * 0.5, 30);
  const dy = itemH + Math.max(itemH * 2, 36);
  const reach = Math.hypot(region.w, region.h) / 2 + Math.max(itemW, itemH);
  const ni = Math.ceil(reach / dx); const nj = Math.ceil(reach / dy);
  const halfX = region.w / 2 + (Math.abs(c) * itemW + Math.abs(s) * itemH) / 2;
  const halfY = region.h / 2 + (Math.abs(s) * itemW + Math.abs(c) * itemH) / 2;
  const pts = [];
  for (let j = -nj; j <= nj; j++) {
    for (let i = -ni; i <= ni; i++) {
      const px = i * dx + (Math.abs(j) % 2 ? dx / 2 : 0);
      const py = j * dy;
      const x = cx + px * c + py * s;
      const y = cy - px * s + py * c;
      if (Math.abs(x - cx) <= halfX && Math.abs(y - cy) <= halfY) pts.push({ x, y });
    }
  }
  return pts.length > 800 ? pts.slice(0, 800) : pts;
}

export function createOps(PDFLib) {
  const { PDFDocument, degrees, rgb, StandardFonts, BlendMode, TextRenderingMode, pushGraphicsState, popGraphicsState, beginText, endText, setTextRenderingMode, setFontAndSize, setTextMatrix, showText, PDFName, PDFNumber, PDFArray, PDFBool, PDFRawStream, decodePDFRawStream } = PDFLib;
  const tick = () => new Promise((r) => setTimeout(r, 0));

  /** Memuat PDF ke pdf-lib. Melempar error berlabel jika terenkripsi. */
  async function load(bytes) {
    try {
      return await PDFDocument.load(bytes, { updateMetadata: false });
    } catch (e) {
      if (e && (e.name === 'EncryptedPDFError' || /encrypted/i.test(e.message || ''))) {
        const err = new Error('PDF terenkripsi atau dibatasi.');
        err.code = 'encrypted';
        throw err;
      }
      throw e;
    }
  }

  /**
   * Membangun PDF baru dari daftar item halaman (urutan = urutan akhir).
   * item: { fid, idx, rot } atau { blank:true, w, h, rot }
   * getLib(fid) → PDFDocument sumber.
   */
  async function build(items, getLib, { onProgress, signal } = {}) {
    const out = await PDFDocument.create();

    // Salin per berkas sumber sekali jalan (menjaga sumber daya bersama tetap efisien).
    const wanted = new Map(); // fid -> idx[] (unik, urutan kemunculan)
    for (const it of items) {
      if (it.blank) continue;
      if (!wanted.has(it.fid)) wanted.set(it.fid, []);
      const list = wanted.get(it.fid);
      if (!list.includes(it.idx)) list.push(it.idx);
    }
    const copied = new Map(); // "fid:idx" -> PDFPage
    let step = 0;
    const total = items.length * 2;
    for (const [fid, idxs] of wanted) {
      const pages = await out.copyPages(getLib(fid), idxs);
      idxs.forEach((idx, i) => copied.set(`${fid}:${idx}`, pages[i]));
      step += idxs.length;
      onProgress?.(step / total);
      await tick();
      if (signal?.aborted) throw new DOMException('Dibatalkan', 'AbortError');
    }

    const fonts = new Map();
    const getFont = async (bold) => {
      const k = bold ? 'b' : 'r';
      if (!fonts.has(k)) fonts.set(k, await out.embedFont(bold ? StandardFonts.HelveticaBold : StandardFonts.Helvetica));
      return fonts.get(k);
    };
    const images = new Map(); // objek img → gambar tertanam (satu kali per dokumen)
    const getImage = async (img) => {
      if (!images.has(img)) images.set(img, await (img.mime === 'image/png' ? out.embedPng(img.bytes) : out.embedJpg(img.bytes)));
      return images.get(img);
    };

    const used = new Set();
    for (const it of items) {
      let page;
      let base = 0;
      if (it.blank) {
        page = out.addPage([it.w || A4[0], it.h || A4[1]]);
      } else {
        const key = `${it.fid}:${it.idx}`;
        if (used.has(key)) {
          // Halaman yang sama dipakai dua kali: salin ulang agar objeknya terpisah.
          [page] = await out.copyPages(getLib(it.fid), [it.idx]);
        } else {
          page = copied.get(key);
          used.add(key);
        }
        base = page.getRotation().angle || 0;
        out.addPage(page);
      }
      const angle = (((base + (it.rot || 0)) % 360) + 360) % 360;
      page.setRotation(degrees(angle));
      if (it.ocr?.words?.length) await drawOcr(page, norm360(base + (it.ocr.rot || 0)), it.ocr.words, getFont);
      if (it.marks?.length) await drawMarks(page, norm360(base), it.marks, getFont, getImage);
      const crop = normalizeCrop(it.crop);
      const wm = normalizeWatermark(it.wm);
      if (wm) await drawWatermark(page, norm360(base), wm, it.rot || 0, crop, getFont, getImage);
      if (crop) {
        const b = cropToBox(page.getCropBox(), norm360(base), crop);
        page.setCropBox(b.x, b.y, b.width, b.height);
        page.setMediaBox(b.x, b.y, b.width, b.height);
      }
      step += 1;
      if (step % 10 === 0) {
        onProgress?.(step / total);
        await tick();
        if (signal?.aborted) throw new DOMException('Dibatalkan', 'AbortError');
      }
    }

    out.setProducer('RUMI - PDF EDITOR');
    out.setCreator('RUMI - PDF EDITOR');
    out.setModificationDate(new Date());
    onProgress?.(0.98);
    const bytes = await out.save({ useObjectStreams: true });
    onProgress?.(1);
    return bytes;
  }

  function safeText(font, text) {
    const s = text.replace(/\t/g, '    ').replace(/\r/g, '');
    try { font.encodeText(s); return s; } catch { /* lanjut per karakter */ }
    let o = '';
    for (const ch of s) { try { font.encodeText(ch); o += ch; } catch { o += '?'; } }
    return o;
  }

  const DIR = { 0: [1, 0], 90: [0, 1], 180: [-1, 0], 270: [0, -1] };

  /**
   * Lapisan teks OCR tak terlihat (render mode 3): PDF jadi bisa dicari & disalin, tampilan tidak berubah.
   * words = [{t, x, y, w, h}] pecahan 0–1 dari halaman pada orientasi R (rotasi total saat OCR dijalankan).
   */
  async function drawOcr(page, R, words, getFont) {
    const font = await getFont(false);
    page.setFont(font);
    const key = page.fontKey;
    const box = page.getCropBox();
    const { Wd, Hd } = displayFrame(box, R);
    const [c, s] = DIR[norm360(R)] || DIR[0];
    const ops = [pushGraphicsState(), beginText(), setTextRenderingMode(TextRenderingMode.Invisible)];
    // Satu garis dasar & satu ukuran font per baris OCR (nomor baris dari Tesseract). Kotak tiap kata berbeda
    // tinggi (huruf p, g, y turun ke bawah), jadi memakai kotak masing-masing membuat kata sebaris tampak tidak sejajar.
    const med = (a) => [...a].sort((p, q) => p - q)[Math.floor(a.length / 2)];
    const groups = new Map();
    words.forEach((w, i) => { const k = w.n ?? `w${i}`; (groups.get(k) || groups.set(k, []).get(k)).push(w); });
    const lineOf = new Map();
    for (const [k, g] of groups) lineOf.set(k, { bottom: med(g.map((w) => w.y + w.h)), h: med(g.map((w) => w.h)) });
    for (const [i, w] of words.entries()) {
      const txt = safeText(font, String(w.t ?? '')).trim();
      if (!txt || !/[^?\s]/.test(txt)) continue;
      const ln = lineOf.get(w.n ?? `w${i}`);
      const wpt = w.w * Wd; const hpt = ln.h * Hd;
      if (!(wpt > 0 && hpt > 0)) continue;
      const size = Math.min(200, Math.max(1, hpt * 0.8));
      const natural = font.widthOfTextAtSize(txt, size);
      const sx = natural > 0 ? Math.min(5, Math.max(0.2, wpt / natural)) : 1;
      const [x, y] = toUser(box, R, w.x * Wd, ln.bottom * Hd); // garis dasar ≈ sisi bawah kebanyakan kata di baris itu
      ops.push(setFontAndSize(key, size), setTextMatrix(sx * c, sx * s, -s, c, x, y), showText(font.encodeText(txt)));
    }
    ops.push(endText(), popGraphicsState());
    page.pushOperators(...ops);
  }

  /** Menggambar anotasi (teks / kotak / sorot / gambar) pada halaman. Koordinat anotasi = pecahan 0–1 dari tampilan asli. */
  async function drawMarks(page, R, marks, getFont, getImage) {
    const box = page.getCropBox();
    const { Wd, Hd } = displayFrame(box, R);
    const rotate = degrees(R);
    const at = (dx, dy) => toUser(box, R, dx, dy);
    for (const m of marks) {
      if (m.type === 'text') {
        const font = await getFont(!!m.bold);
        const [cr, cg, cb] = hexRgb(m.color);
        String(m.text ?? '').split('\n').forEach((line, i) => {
          const txt = safeText(font, line);
          if (!txt.trim()) return;
          const [x, y] = at(m.x * Wd, m.y * Hd + m.size * (BASELINE + LINE_H * i));
          page.drawText(txt, { x, y, size: m.size, font, color: rgb(cr, cg, cb), rotate });
        });
      } else if (m.type === 'rect') {
        const [x, y] = at(m.x * Wd, (m.y + m.h) * Hd);
        const [cr, cg, cb] = hexRgb(m.color);
        const hl = m.kind === 'hl';
        page.drawRectangle({
          x, y, width: m.w * Wd, height: m.h * Hd, rotate, color: rgb(cr, cg, cb), borderWidth: 0,
          ...(hl ? { opacity: 0.55, blendMode: BlendMode.Multiply } : {}),
        });
      } else if (m.type === 'image' && m.img) {
        const img = await getImage(m.img);
        const [x, y] = at(m.x * Wd, (m.y + m.h) * Hd);
        page.drawImage(img, { x, y, width: m.w * Wd, height: m.h * Hd, rotate });
      }
    }
  }

  /**
   * Watermark teks/gambar di atas isi halaman, di dalam area yang akan terlihat (setelah potongan).
   * Sudut mengikuti tampilan akhir: halaman yang diputar pengguna (extraRot) tetap menampilkan watermark dengan sudut yang sama.
   */
  async function drawWatermark(page, R, wm, extraRot, crop, getFont, getImage) {
    const box = page.getCropBox();
    const { Wd, Hd } = displayFrame(box, R);
    const c = crop || { l: 0, t: 0, r: 0, b: 0 };
    const region = { x: c.l * Wd, y: c.t * Hd, w: Wd * (1 - c.l - c.r), h: Hd * (1 - c.t - c.b) };
    const theta = wm.angle + extraRot; // sudut pada orientasi dasar halaman
    const deg = theta + R; // sudut pada ruang pengguna PDF
    const cos = Math.cos((deg * Math.PI) / 180); const sin = Math.sin((deg * Math.PI) / 180);
    // titik asal objek = titik tengah − putaran(setengah lebar, offset vertikal)
    const originAt = (x, y, ax, ay) => {
      const [ux, uy] = toUser(box, R, x, y);
      return [ux - (ax * cos - ay * sin), uy - (ax * sin + ay * cos)];
    };
    if (wm.type === 'text') {
      const font = await getFont(wm.bold);
      const txt = safeText(font, wm.text);
      if (!txt.trim()) return;
      const [cr, cg, cb] = hexRgb(wm.color);
      const w = font.widthOfTextAtSize(txt, wm.size);
      for (const pt of wmPlace(region, w, wm.size, theta, wm.layout)) {
        const [x, y] = originAt(pt.x, pt.y, w / 2, wm.size * WM_BASE);
        page.drawText(txt, { x, y, size: wm.size, font, color: rgb(cr, cg, cb), opacity: wm.opacity, rotate: degrees(deg) });
      }
    } else {
      const img = await getImage(wm.img);
      const w = region.w * wm.scale;
      const h = (w * wm.img.h) / wm.img.w;
      for (const pt of wmPlace(region, w, h, theta, wm.layout)) {
        const [x, y] = originAt(pt.x, pt.y, w / 2, h / 2);
        page.drawImage(img, { x, y, width: w, height: h, opacity: wm.opacity, rotate: degrees(deg) });
      }
    }
  }

  /**
   * Mengecilkan ukuran dengan menyusun ulang gambar (JPEG) di dalam PDF. Teks & vektor tidak disentuh.
   * codec.recode(src, {maxDim, quality}) → {width,height,jpeg} atau null; src = {kind:'jpeg',bytes} | {kind:'raw',width,height,n,data}.
   */
  async function compressImages(bytes, { quality = 0.7, maxDim = 1600, codec, onProgress } = {}) {
    const doc = await PDFDocument.load(bytes, { updateMetadata: false });
    const N = (x) => PDFName.of(x);
    const imgs = [...doc.context.enumerateIndirectObjects()]
      .filter(([, o]) => o instanceof PDFRawStream && o.dict.get(N('Subtype')) === N('Image'));
    let replaced = 0;
    for (const [i, [ref, obj]] of imgs.entries()) {
      onProgress?.(i / Math.max(1, imgs.length));
      await tick();
      try {
        if (await recodeOne(doc, ref, obj, { quality, maxDim, codec })) replaced++;
      } catch (e) { if (globalThis.__RUMI_DEBUG) console.warn("compress", e); }
    }
    const out = await doc.save({ useObjectStreams: true });
    onProgress?.(1);
    return { bytes: out, images: imgs.length, replaced };
  }

  async function recodeOne(doc, ref, obj, { quality, maxDim, codec }) {
    const N = (x) => PDFName.of(x);
    const d = obj.dict;
    const num = (k) => { const v = d.lookup(N(k)); return v instanceof PDFNumber ? v.asNumber() : undefined; };
    const w = num('Width'); const h = num('Height');
    if (!w || !h || num('BitsPerComponent') !== 8) return false;
    if (d.has(N('Mask')) || d.has(N('Decode'))) return false;
    const mask = d.lookup(N('ImageMask'));
    if (mask instanceof PDFBool && mask.asBoolean()) return false;
    if (obj.contents.length < 20_000 || w * h > 40e6) return false;

    const cs = d.lookup(N('ColorSpace'));
    let n = 0;
    if (cs === N('DeviceRGB')) n = 3;
    else if (cs === N('DeviceGray')) n = 1;
    else if (cs instanceof PDFArray && cs.lookup(0) === N('ICCBased')) {
      const prof = cs.lookup(1);
      const v = prof?.dict?.lookup(N('N'));
      n = v instanceof PDFNumber ? v.asNumber() : 0;
    }
    if (n !== 1 && n !== 3) return false;

    // Rantai filter, mis. [ASCII85Decode FlateDecode] atau [ASCII85Decode DCTDecode].
    const f = d.lookup(N('Filter'));
    const names = f instanceof PDFArray ? f.asArray().map((x) => doc.context.lookup(x)) : (f ? [f] : []);
    const isDct = names[names.length - 1] === N('DCTDecode');
    const pre = isDct ? names.slice(0, -1) : names;
    const decodable = new Set(['FlateDecode', 'LZWDecode', 'ASCII85Decode', 'ASCIIHexDecode', 'RunLengthDecode'].map(N));
    if (!pre.every((x) => decodable.has(x))) return false; // JPX, CCITT, JBIG2, dst. dilewati

    let plain = obj.contents;
    if (pre.length) {
      const tmp = d.clone();
      tmp.set(N('Filter'), pre.length === 1 ? pre[0] : doc.context.obj(pre));
      const parms = d.lookup(N('DecodeParms'));
      if (parms instanceof PDFArray) tmp.set(N('DecodeParms'), doc.context.obj(parms.asArray().slice(0, pre.length)));
      plain = decodePDFRawStream(PDFRawStream.of(tmp, obj.contents)).decode();
    }
    let src;
    if (isDct) {
      src = { kind: 'jpeg', bytes: plain };
    } else {
      if (plain.length !== w * h * n) return false;
      src = { kind: 'raw', width: w, height: h, n, data: plain };
    }

    const res = await codec.recode(src, { maxDim, quality });
    if (!res || res.jpeg.length >= obj.contents.length * 0.92) return false;

    const nd = d.clone();
    nd.delete(N('DecodeParms'));
    nd.set(N('Filter'), N('DCTDecode'));
    nd.set(N('Width'), PDFNumber.of(res.width));
    nd.set(N('Height'), PDFNumber.of(res.height));
    nd.set(N('BitsPerComponent'), PDFNumber.of(8));
    nd.set(N('Length'), PDFNumber.of(res.jpeg.length));
    if (n === 1) nd.set(N('ColorSpace'), N('DeviceRGB')); // keluaran JPEG selalu RGB
    doc.context.assign(ref, PDFRawStream.of(nd, res.jpeg));
    return true;
  }

  return { load, build, compressImages };
}
