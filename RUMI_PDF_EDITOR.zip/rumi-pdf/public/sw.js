// Service worker RUMI - PDF EDITOR — membuat aplikasi bisa dipakai offline.
// Strategi:
//  • Cangkang aplikasi (HTML/JS/CSS): jaringan dulu (maks 3 dtk), cadangan dari cache → selalu segar saat online.
//  • /vendor/ dan /icons/: cache dulu, diisi saat pertama dipakai (cmaps & font hanya diunduh bila dibutuhkan).
// Naikkan CACHE_VERSION jika Anda mengganti berkas di /vendor/.

const CACHE_VERSION = 'v6';
const CACHE = `rumi-pdf-${CACHE_VERSION}`;

const SHELL = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './ops.js',
  './zip.js',
  './marks.js',
  './tools.js',
  './crypt.js',
  './convert.js',
  './manifest.webmanifest',
  './icons/logo.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './vendor/pdf-lib.min.js',
  './vendor/pdf.min.mjs',
  './vendor/pdf.worker.min.mjs',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL.map((u) => new Request(u, { cache: 'reload' })))),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k.startsWith('rumi-pdf-') && k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

const timeout = (ms) => new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms));

async function networkFirst(req) {
  const cache = await caches.open(CACHE);
  try {
    const res = await Promise.race([fetch(req), timeout(3000)]);
    if (res && res.ok) cache.put(req, res.clone());
    return res;
  } catch (err) {
    const hit = await cache.match(req, { ignoreSearch: true });
    if (hit) return hit;
    throw err;
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && res.ok) cache.put(req, res.clone());
  return res;
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  if (req.mode === 'navigate') {
    event.respondWith(
      networkFirst(req).catch(() => caches.match('./index.html')),
    );
    return;
  }
  if (/\/(vendor|icons)\//.test(url.pathname)) {
    event.respondWith(cacheFirst(req));
    return;
  }
  event.respondWith(networkFirst(req));
});
