// Antarmuka fitur Potong, Edit isi, dan Kompres. Dipasang oleh app.js lewat initTools(ctx).
import { normalizeCrop, normalizeWatermark, unsupportedChars } from './ops.js';
import { paintWatermark } from './marks.js';
import { protectPdf } from './crypt.js';

const MIN_CROP = 0.05;
const LEVELS = {
  light: { quality: 0.8, maxDim: 2400 },
  medium: { quality: 0.65, maxDim: 1600 },
  strong: { quality: 0.5, maxDim: 1100 },
};
const FLAT = { dpi: 110, quality: 0.6 };

const fmtSize = (n) => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(n >= 1e7 ? 1 : 2)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

export function initTools(ctx) {
  const {
    $, state, mutate, toast, busy, unbusy, raf, pageById, indexOfId, clamp, plural, sanitize,
    ops, itemOf, getLib, baseName, download, pageSize, drawRaw, pageHasText, pdfjsLib, PDFJS_OPTS, PDFLib, composite,
  } = ctx;
  const dpr = () => Math.min(window.devicePixelRatio || 1, 2);

  /** Menampilkan halaman apa adanya pada panggung (stage) yang muat di body. Mengembalikan skala css px/pt. */
  function fitStage(d, body, stage) {
    const maxW = Math.max(160, body.clientWidth - 24);
    const maxH = Math.max(160, body.clientHeight - 24);
    const s = Math.min(maxW / d.w, maxH / d.h);
    const cssW = Math.round(d.w * s); const cssH = Math.round(d.h * s);
    stage.style.width = cssW + 'px'; stage.style.height = cssH + 'px';
    return { s, cssW, cssH };
  }
  async function showRaw(p, body, stage, cv, holder) {
    const d = await pageSize(p);
    const v = fitStage(d, body, stage);
    cv.style.width = '100%'; cv.style.height = '100%';
    holder.task?.cancel();
    await drawRaw(p, cv, v.s * dpr(), (t) => { holder.task = t; });
    return { d, ...v };
  }
  const isRenderCancel = (e) => e?.name === 'RenderingCancelledException';

  /* ================================================================ POTONG */
  const cr = {
    dlg: $('#dlg-crop'), body: $('#crop-body'), stage: $('#crop-stage'), cv: $('#crop-canvas'), box: $('#crop-box'),
    holder: {}, token: 0, ids: [], i: 0, rect: { l: 0, t: 0, r: 0, b: 0 }, drag: null,
  };
  const scopeRadios = () => [...document.getElementsByName('crop-scope')];
  const cropScope = () => scopeRadios().find((r) => r.checked)?.value || 'all';
  const scopeIds = () => (cropScope() === 'selected'
    ? state.pages.filter((p) => state.selected.has(p.id)).map((p) => p.id)
    : state.pages.map((p) => p.id));

  function openCrop() {
    if (!state.pages.length) return;
    const k = state.selected.size;
    const [rs, ra] = [scopeRadios().find((r) => r.value === 'selected'), scopeRadios().find((r) => r.value === 'all')];
    rs.disabled = k === 0;
    $('#crop-sel-lbl').textContent = k ? `Halaman terpilih (${k})` : 'Halaman terpilih';
    $('#crop-all-lbl').textContent = `Semua halaman (${state.pages.length})`;
    (k ? rs : ra).checked = true;
    cr.ids = scopeIds(); cr.i = 0;
    const first = pageById(cr.ids[0]);
    cr.rect = { l: 0, t: 0, r: 0, b: 0, ...(first?.crop || {}) };
    cr.dlg.showModal();
    requestAnimationFrame(loadCropPage);
  }

  async function loadCropPage() {
    const token = ++cr.token;
    const p = pageById(cr.ids[cr.i]);
    if (!p) return;
    $('#crop-title').textContent = `Potong · halaman ${indexOfId(p.id) + 1}`;
    $('#crop-prev').disabled = cr.i === 0;
    $('#crop-next').disabled = cr.i >= cr.ids.length - 1;
    $('#crop-prev').hidden = $('#crop-next').hidden = cr.ids.length < 2;
    $('#crop-hint').textContent = cr.ids.length > 1
      ? `Seret tepi atau sudut kotak. Potongan yang sama dipakai untuk ${cr.ids.length} halaman.`
      : 'Seret tepi atau sudut kotak untuk menentukan area yang dipertahankan.';
    try {
      const v = await showRaw(p, cr.body, cr.stage, cr.cv, cr.holder);
      if (token !== cr.token) return;
      cr.d = v.d;
      layoutCrop();
    } catch (e) { if (!isRenderCancel(e)) console.warn(e); }
  }

  function layoutCrop() {
    const { l, t, r, b } = cr.rect;
    const s = cr.box.style;
    s.left = l * 100 + '%'; s.top = t * 100 + '%';
    s.width = (1 - l - r) * 100 + '%'; s.height = (1 - t - b) * 100 + '%';
  }

  cr.box.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    const h = e.target.dataset?.h || 'move';
    const rc = cr.stage.getBoundingClientRect();
    cr.drag = { h, x: e.clientX, y: e.clientY, w: rc.width, hh: rc.height, r0: { ...cr.rect }, pid: e.pointerId };
    cr.box.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  cr.box.addEventListener('pointermove', (e) => {
    const d = cr.drag;
    if (!d || e.pointerId !== d.pid) return;
    const dx = (e.clientX - d.x) / d.w; const dy = (e.clientY - d.y) / d.hh;
    const r = { ...d.r0 };
    if (d.h === 'move') {
      const w = 1 - r.l - r.r; const h = 1 - r.t - r.b;
      r.l = clamp(d.r0.l + dx, 0, 1 - w); r.r = 1 - w - r.l;
      r.t = clamp(d.r0.t + dy, 0, 1 - h); r.b = 1 - h - r.t;
    } else {
      if (d.h.includes('w')) r.l = clamp(d.r0.l + dx, 0, 1 - d.r0.r - MIN_CROP);
      if (d.h.includes('e')) r.r = clamp(d.r0.r - dx, 0, 1 - d.r0.l - MIN_CROP);
      if (d.h.includes('n')) r.t = clamp(d.r0.t + dy, 0, 1 - d.r0.b - MIN_CROP);
      if (d.h.includes('s')) r.b = clamp(d.r0.b - dy, 0, 1 - d.r0.t - MIN_CROP);
    }
    cr.rect = r;
    layoutCrop();
  });
  const endCropDrag = () => { cr.drag = null; };
  cr.box.addEventListener('pointerup', endCropDrag);
  cr.box.addEventListener('pointercancel', endCropDrag);

  $('#crop-reset').onclick = () => { cr.rect = { l: 0, t: 0, r: 0, b: 0 }; layoutCrop(); };
  $('#crop-auto').onclick = () => {
    const { width: W, height: H } = cr.cv;
    if (!W || !H) return;
    const data = cr.cv.getContext('2d').getImageData(0, 0, W, H).data;
    let x0 = W; let y0 = H; let x1 = -1; let y1 = -1;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = (y * W + x) * 4;
        if (data[i + 3] > 10 && (data[i] < 245 || data[i + 1] < 245 || data[i + 2] < 245)) {
          if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        }
      }
    }
    if (x1 < 0) { toast('Tidak ada isi yang terdeteksi di halaman ini.', { error: true }); return; }
    const pad = 0.015;
    cr.rect = {
      l: clamp(x0 / W - pad, 0, 0.9), t: clamp(y0 / H - pad, 0, 0.9),
      r: clamp(1 - (x1 + 1) / W - pad, 0, 0.9), b: clamp(1 - (y1 + 1) / H - pad, 0, 0.9),
    };
    layoutCrop();
    toast('Margin kosong dipangkas. Sesuaikan bila perlu.');
  };
  $('#crop-prev').onclick = () => { cr.i = Math.max(0, cr.i - 1); loadCropPage(); };
  $('#crop-next').onclick = () => { cr.i = Math.min(cr.ids.length - 1, cr.i + 1); loadCropPage(); };
  for (const r of scopeRadios()) r.addEventListener('change', () => { cr.ids = scopeIds(); cr.i = 0; loadCropPage(); });
  $('#crop-cancel').onclick = () => cr.dlg.close();
  $('#crop-apply').onclick = () => {
    const ids = new Set(scopeIds());
    const next = normalizeCrop(cr.rect);
    cr.dlg.close();
    const targets = state.pages.filter((p) => ids.has(p.id));
    if (!targets.length) return;
    if (!next && !targets.some((p) => p.crop)) return;
    mutate(() => targets.forEach((p) => { p.crop = next ? { ...next } : undefined; }));
    toast(next ? `Potongan diterapkan ke ${plural(targets.length, 'halaman')}.` : 'Potongan dihapus.', { action: 'Urungkan', onAction: () => document.getElementById('btn-undo').click() });
  };
  cr.dlg.addEventListener('close', () => { cr.token++; cr.holder.task?.cancel(); cr.cv.width = cr.cv.height = 0; cr.drag = null; cr.d = null; });
  new ResizeObserver(() => { if (cr.dlg.open && cr.d) fitStage(cr.d, cr.body, cr.stage); }).observe(cr.body);

  /* ============================================================= EDIT ISI */
  const ed = {
    dlg: $('#dlg-edit'), body: $('#ed-body'), stage: $('#ed-stage'), cv: $('#ed-canvas'), layer: $('#ed-layer'),
    holder: {}, token: 0, i: 0, p: null, draft: [], sel: null, tool: 'select', els: new Map(), drag: null,
    cssW: 1, cssH: 1, s: 1,
  };
  let seq = 0; // id objek & gambar (menaik terus)
  const HINTS = {
    select: 'Klik objek untuk memilih, seret untuk memindahkan. Pilih alat di atas untuk menambah.',
    text: 'Klik di halaman untuk menaruh teks.',
    cover: 'Seret untuk membuat kotak penutup. Ini hanya menutupi tampilan: teks di bawahnya masih ada di berkas. Gunakan Kompres → Maksimal untuk benar-benar menghapusnya.',
    hl: 'Seret untuk menyorot.',
    image: '',
  };

  function openEdit() {
    if (!state.pages.length) return;
    const first = state.pages.find((p) => state.selected.has(p.id)) || pageById(state.focusId) || state.pages[0];
    ed.dlg.showModal();
    requestAnimationFrame(() => loadEditPage(indexOfId(first.id)));
  }

  async function loadEditPage(i) {
    i = clamp(i, 0, state.pages.length - 1);
    const token = ++ed.token;
    ed.i = i; ed.p = state.pages[i];
    ed.draft = (ed.p.marks || []).map((m) => ({ ...m }));
    ed.sel = null;
    $('#ed-title').textContent = `Edit · halaman ${i + 1} dari ${state.pages.length}`;
    $('#ed-prev').disabled = i === 0;
    $('#ed-next').disabled = i === state.pages.length - 1;
    try {
      const v = await showRaw(ed.p, ed.body, ed.stage, ed.cv, ed.holder);
      if (token !== ed.token) return;
      ed.d = v.d; ed.cssW = v.cssW; ed.cssH = v.cssH; ed.s = v.s;
      layoutDim();
      buildLayer();
      setTool('select');
      updatePanel();
    } catch (e) { if (!isRenderCancel(e)) console.warn(e); }
  }

  function commitEdit() {
    const p = ed.p;
    if (!p || !pageById(p.id)) return;
    const sig = (a) => JSON.stringify(a, (k, v) => (k === 'img' ? v?.id : v));
    if (sig(ed.draft) === sig(p.marks || [])) return;
    const next = ed.draft.map((m) => ({ ...m }));
    mutate(() => { p.marks = next.length ? next : undefined; });
  }

  // Area di luar potongan diredupkan, supaya jelas bagian mana yang akan terlihat di hasil akhir.
  function layoutDim() {
    const c = normalizeCrop(ed.p?.crop);
    const dim = $('#ed-dim');
    dim.hidden = !c;
    if (!c) return;
    dim.style.left = c.l * 100 + '%'; dim.style.top = c.t * 100 + '%';
    dim.style.width = (1 - c.l - c.r) * 100 + '%'; dim.style.height = (1 - c.t - c.b) * 100 + '%';
  }

  function buildLayer() {
    ed.layer.replaceChildren();
    ed.els.clear();
    for (const m of ed.draft) addEl(m);
  }
  function addEl(m) {
    const e = document.createElement('div');
    e.className = 'mk mk-' + m.type;
    e.dataset.id = m.id;
    if (m.type === 'image') {
      const img = new Image(); img.src = m.img.url; img.alt = ''; img.draggable = false;
      e.append(img);
    }
    if (m.type !== 'text') { const h = document.createElement('i'); h.className = 'hnd'; e.append(h); }
    ed.layer.append(e);
    ed.els.set(m.id, e);
    syncEl(m);
    return e;
  }
  function syncEl(m) {
    const e = ed.els.get(m.id);
    if (!e) return;
    const s = e.style;
    s.left = m.x * 100 + '%'; s.top = m.y * 100 + '%';
    if (m.type === 'text') {
      s.fontSize = m.size * ed.s + 'px';
      s.color = m.color;
      s.fontWeight = m.bold ? '700' : '400';
      s.fontFamily = 'Helvetica, Arial, sans-serif';
      let n = e.firstChild;
      if (!n || n.nodeType !== 3) { n = document.createTextNode(''); e.prepend(n); }
      n.nodeValue = m.text || ' ';
    } else {
      s.width = m.w * 100 + '%'; s.height = m.h * 100 + '%';
      if (m.type === 'rect') {
        s.background = m.color;
        s.opacity = m.kind === 'hl' ? '0.55' : '1';
        s.mixBlendMode = m.kind === 'hl' ? 'multiply' : 'normal';
      }
    }
    e.classList.toggle('sel', m === ed.sel);
  }

  function select(m) {
    const prev = ed.sel;
    ed.sel = m;
    if (prev) syncEl(prev);
    if (m) syncEl(m);
    updatePanel();
  }

  const P = { box: $('#ed-props'), text: $('#ed-text'), size: $('#ed-size'), color: $('#ed-color'), bold: $('#ed-bold') };
  function updatePanel() {
    const m = ed.sel;
    $('#ed-del').disabled = !m;
    const showProps = m && (m.type === 'text' || m.type === 'rect');
    P.box.hidden = !showProps;
    if (!showProps) { refreshHint(); return; }
    const isText = m.type === 'text';
    P.text.hidden = P.size.parentElement.hidden = P.bold.parentElement.hidden = !isText;
    P.color.value = m.color;
    if (isText) { P.text.value = m.text; P.size.value = m.size; P.bold.checked = !!m.bold; }
    refreshHint();
  }
  function refreshHint() {
    const h = $('#ed-hint');
    const bad = ed.sel?.type === 'text' ? unsupportedChars(ed.sel.text) : [];
    h.classList.toggle('warn', bad.length > 0);
    h.textContent = bad.length
      ? `Karakter ${bad.slice(0, 6).join(' ')} tidak didukung font PDF dan akan diganti "?". Teks Latin (termasuk aksen) aman.`
      : HINTS[ed.tool] || HINTS.select;
  }

  P.text.addEventListener('input', () => { if (ed.sel?.type !== 'text') return; ed.sel.text = P.text.value; syncEl(ed.sel); refreshHint(); });
  P.size.addEventListener('input', () => { if (ed.sel?.type !== 'text') return; const v = Number(P.size.value); if (v >= 6) { ed.sel.size = Math.min(200, v); syncEl(ed.sel); } });
  P.color.addEventListener('input', () => { if (!ed.sel) return; ed.sel.color = P.color.value; syncEl(ed.sel); });
  P.bold.addEventListener('change', () => { if (ed.sel?.type !== 'text') return; ed.sel.bold = P.bold.checked; syncEl(ed.sel); });

  function setTool(t) {
    ed.tool = t;
    for (const b of ed.dlg.querySelectorAll('[data-tool]')) b.setAttribute('aria-pressed', String(b.dataset.tool === t));
    ed.layer.className = 'layer tool-' + t;
    refreshHint();
  }
  for (const b of ed.dlg.querySelectorAll('[data-tool]')) {
    b.addEventListener('click', () => {
      const t = b.dataset.tool;
      if (t === 'image') { setTool('select'); $('#ed-file').click(); return; }
      setTool(t);
      if (t !== 'select') select(null);
    });
  }

  function removeSel() {
    const m = ed.sel;
    if (!m) return;
    ed.draft = ed.draft.filter((x) => x !== m);
    ed.els.get(m.id)?.remove(); ed.els.delete(m.id);
    ed.sel = null;
    updatePanel();
  }
  $('#ed-del').onclick = removeSel;
  ed.dlg.addEventListener('keydown', (e) => {
    if (e.target.closest?.('input, textarea')) return;
    if ((e.key === 'Delete' || e.key === 'Backspace') && ed.sel) { e.preventDefault(); removeSel(); }
  });

  const frac = (e) => {
    const r = ed.layer.getBoundingClientRect();
    return { x: clamp((e.clientX - r.left) / r.width, 0, 1), y: clamp((e.clientY - r.top) / r.height, 0, 1) };
  };
  const markOf = (el) => ed.draft.find((m) => String(m.id) === el?.dataset?.id);

  ed.layer.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    const pos = frac(e);
    const el = e.target.closest('.mk');
    const m = markOf(el);
    if (m) {
      select(m);
      ed.drag = e.target.classList.contains('hnd')
        ? { mode: 'resize', m, pid: e.pointerId }
        : { mode: 'move', m, ox: pos.x - m.x, oy: pos.y - m.y, pid: e.pointerId };
    } else if (ed.tool === 'text') {
      const t = { id: ++seq, type: 'text', x: Math.min(pos.x, 0.9), y: Math.min(pos.y, 0.95), size: 14, color: '#000000', bold: false, text: 'Teks' };
      ed.draft.push(t); addEl(t); select(t); setTool('select');
      P.text.focus(); P.text.select();
      e.preventDefault();
      return;
    } else if (ed.tool === 'cover' || ed.tool === 'hl') {
      const r = { id: ++seq, type: 'rect', kind: ed.tool, color: ed.tool === 'hl' ? '#ffe600' : '#ffffff', x: pos.x, y: pos.y, w: 0, h: 0 };
      ed.draft.push(r); addEl(r); select(r);
      ed.drag = { mode: 'draw', m: r, x0: pos.x, y0: pos.y, pid: e.pointerId };
    } else {
      select(null);
      return;
    }
    ed.layer.setPointerCapture(e.pointerId);
    e.preventDefault();
  });

  ed.layer.addEventListener('pointermove', (e) => {
    const d = ed.drag;
    if (!d || e.pointerId !== d.pid) return;
    const pos = frac(e);
    const m = d.m;
    if (d.mode === 'move') {
      m.x = clamp(pos.x - d.ox, 0, m.type === 'text' ? 0.97 : 1 - m.w);
      m.y = clamp(pos.y - d.oy, 0, m.type === 'text' ? 0.97 : 1 - m.h);
    } else if (d.mode === 'draw') {
      m.x = Math.min(d.x0, pos.x); m.y = Math.min(d.y0, pos.y);
      m.w = Math.abs(pos.x - d.x0); m.h = Math.abs(pos.y - d.y0);
    } else if (d.mode === 'resize') {
      if (m.type === 'image') {
        const ratio = m.img.w / m.img.h;
        let w = clamp(pos.x - m.x, 0.03, 1 - m.x);
        let h = (w * ed.cssW) / (ratio * ed.cssH);
        if (m.y + h > 1) { h = 1 - m.y; w = (h * ratio * ed.cssH) / ed.cssW; }
        m.w = w; m.h = h;
      } else {
        m.w = clamp(pos.x - m.x, 0.02, 1 - m.x);
        m.h = clamp(pos.y - m.y, 0.01, 1 - m.y);
      }
    }
    syncEl(m);
  });
  const endEditDrag = (e) => {
    const d = ed.drag;
    if (!d || e.pointerId !== d.pid) return;
    ed.drag = null;
    if (d.mode === 'draw') {
      if (d.m.w < 0.01 || d.m.h < 0.005) {
        ed.draft = ed.draft.filter((x) => x !== d.m);
        ed.els.get(d.m.id)?.remove(); ed.els.delete(d.m.id);
        ed.sel = null; updatePanel();
      } else if (ed.tool === 'cover') {
        setTool('select');
      }
    }
  };
  ed.layer.addEventListener('pointerup', endEditDrag);
  ed.layer.addEventListener('pointercancel', endEditDrag);

  // Gambar: pilih berkas → (kecilkan bila besar) → taruh di tengah halaman.
  async function loadImageFile(f) {
    let bytes = new Uint8Array(await f.arrayBuffer());
    let mime = f.type;
    const bmp = await createImageBitmap(new Blob([bytes], { type: mime }));
    let { width: w, height: h } = bmp;
    const long = Math.max(w, h);
    const needsConvert = mime !== 'image/png' && mime !== 'image/jpeg';
    if (needsConvert || long > 1600) {
      const k = Math.min(1, 1600 / long);
      const cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(w * k)); cv.height = Math.max(1, Math.round(h * k));
      const g = cv.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(bmp, 0, 0, cv.width, cv.height);
      const outMime = mime === 'image/jpeg' ? 'image/jpeg' : 'image/png';
      const blob = await new Promise((r) => cv.toBlob(r, outMime, 0.88));
      bytes = new Uint8Array(await blob.arrayBuffer()); mime = outMime; w = cv.width; h = cv.height;
    }
    bmp.close?.();
    const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
    return { id: ++seq, bytes, mime, url, w, h };
  }
  $('#ed-file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    e.target.value = '';
    if (!f || !ed.p) return;
    try {
      const img = await loadImageFile(f);
      const ratio = img.w / img.h;
      let w = 0.3; let h = (w * ed.cssW) / (ratio * ed.cssH);
      if (h > 0.6) { h = 0.6; w = (h * ratio * ed.cssH) / ed.cssW; }
      const m = { id: ++seq, type: 'image', x: (1 - w) / 2, y: (1 - h) / 2, w, h, img };
      ed.draft.push(m); addEl(m); select(m);
    } catch (err) {
      console.warn(err);
      toast('Gambar tidak bisa dibaca. Gunakan PNG atau JPEG.', { error: true });
    }
  });

  $('#ed-prev').onclick = () => { commitEdit(); loadEditPage(ed.i - 1); };
  $('#ed-next').onclick = () => { commitEdit(); loadEditPage(ed.i + 1); };
  $('#ed-done').onclick = () => ed.dlg.close();
  ed.dlg.addEventListener('close', () => {
    commitEdit();
    ed.token++; ed.holder.task?.cancel();
    ed.cv.width = ed.cv.height = 0;
    ed.layer.replaceChildren(); ed.els.clear(); ed.draft = []; ed.sel = null; ed.p = null; ed.drag = null; ed.d = null;
  });
  // Panel properti muncul/hilang dan ukuran jendela berubah → panggung menyesuaikan tanpa menggambar ulang.
  new ResizeObserver(() => {
    if (!ed.dlg.open || !ed.p || !ed.d) return;
    const v = fitStage(ed.d, ed.body, ed.stage);
    ed.cssW = v.cssW; ed.cssH = v.cssH; ed.s = v.s;
    for (const m of ed.draft) syncEl(m);
  }).observe(ed.body);

  /* ================================================================ KOMPRES */
  const cmp = { dlg: $('#dlg-compress'), form: $('#form-compress') };
  const NOTES = {
    light: 'Mengecilkan gambar di dalam PDF. Teks, vektor, dan tautan tidak diubah. PDF yang hampir tanpa gambar tidak akan banyak mengecil.',
    medium: 'Mengecilkan gambar di dalam PDF. Teks, vektor, dan tautan tidak diubah.',
    strong: 'Gambar jadi lebih kasar. Teks, vektor, dan tautan tidak diubah.',
    flat: 'Setiap halaman diubah jadi gambar JPEG (≈110 dpi). Teks tidak bisa dipilih atau dicari, tautan dan formulir hilang.',
  };
  const level = () => cmp.form.elements.level.value;
  const refreshNote = () => { $('#cmp-note').textContent = NOTES[level()]; };
  cmp.form.addEventListener('change', refreshNote);

  function openCompress() {
    if (!state.pages.length) return;
    const fids = new Set(state.pages.filter((p) => !p.blank).map((p) => p.fid));
    const src = [...fids].reduce((a, f) => a + (state.files.get(f)?.size || 0), 0);
    $('#cmp-info').textContent = `${plural(state.pages.length, 'halaman')}${src ? ` · ukuran berkas sumber ${fmtSize(src)}` : ''}. Hasil dihitung dari susunan yang ada di layar.`;
    refreshNote();
    cmp.dlg.showModal();
  }

  // Pengolah gambar berbasis kanvas browser (disuntikkan ke ops.compressImages).
  const codec = {
    async recode(src, { maxDim, quality }) {
      let bmp = null; let w; let h;
      if (src.kind === 'jpeg') {
        bmp = await createImageBitmap(new Blob([src.bytes], { type: 'image/jpeg' }), { imageOrientation: 'none', colorSpaceConversion: 'none' });
        w = bmp.width; h = bmp.height;
      } else { w = src.width; h = src.height; }
      const k = Math.min(1, maxDim / Math.max(w, h));
      const tw = Math.max(1, Math.round(w * k)); const th = Math.max(1, Math.round(h * k));
      const cv = document.createElement('canvas');
      cv.width = tw; cv.height = th;
      const g = cv.getContext('2d');
      g.fillStyle = '#fff'; g.fillRect(0, 0, tw, th);
      g.imageSmoothingQuality = 'high';
      if (bmp) {
        g.drawImage(bmp, 0, 0, tw, th);
        bmp.close?.();
      } else {
        const rgba = new Uint8ClampedArray(w * h * 4);
        const d = src.data; const n = src.n;
        for (let i = 0, j = 0, q = 0; i < w * h; i++, q += n, j += 4) {
          if (n === 3) { rgba[j] = d[q]; rgba[j + 1] = d[q + 1]; rgba[j + 2] = d[q + 2]; } else { rgba[j] = rgba[j + 1] = rgba[j + 2] = d[q]; }
          rgba[j + 3] = 255;
        }
        const tmp = document.createElement('canvas');
        tmp.width = w; tmp.height = h;
        tmp.getContext('2d').putImageData(new ImageData(rgba, w, h), 0, 0);
        g.drawImage(tmp, 0, 0, tw, th);
        tmp.width = tmp.height = 0;
      }
      const blob = await new Promise((r) => cv.toBlob(r, 'image/jpeg', quality));
      cv.width = cv.height = 0;
      if (!blob) return null;
      return { width: tw, height: th, jpeg: new Uint8Array(await blob.arrayBuffer()) };
    },
  };

  /** Setiap halaman → JPEG → PDF baru (ukuran halaman sama). */
  async function flatten(bytes, { dpi, quality, onProgress }) {
    const src = await pdfjsLib.getDocument({ data: bytes.slice(), ...PDFJS_OPTS }).promise;
    const out = await PDFLib.PDFDocument.create();
    try {
      for (let i = 1; i <= src.numPages; i++) {
        onProgress?.((i - 1) / src.numPages);
        await raf();
        const page = await src.getPage(i);
        const v1 = page.getViewport({ scale: 1 });
        let scale = dpi / 72;
        const px = v1.width * scale * v1.height * scale;
        if (px > 24e6) scale *= Math.sqrt(24e6 / px);
        const vp = page.getViewport({ scale });
        const cv = document.createElement('canvas');
        cv.width = Math.floor(vp.width); cv.height = Math.floor(vp.height);
        const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height);
        await page.render({ canvas: cv, viewport: vp }).promise;
        const blob = await new Promise((r) => cv.toBlob(r, 'image/jpeg', quality));
        cv.width = cv.height = 0;
        const img = await out.embedJpg(new Uint8Array(await blob.arrayBuffer()));
        out.addPage([v1.width, v1.height]).drawImage(img, { x: 0, y: 0, width: v1.width, height: v1.height });
        page.cleanup();
      }
    } finally { src.destroy?.(); }
    out.setProducer('RUMI - PDF EDITOR'); out.setCreator('RUMI - PDF EDITOR');
    return out.save({ useObjectStreams: true });
  }

  cmp.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const lv = level();
    cmp.dlg.close();
    try {
      busy('Menyusun dokumen…', 0);
      await raf();
      const built = await ops.build(state.pages.map(itemOf), getLib, { onProgress: (p) => busy('Menyusun dokumen…', p * 0.3) });
      let bytes; let note = '';
      if (lv === 'flat') {
        bytes = await flatten(built, { ...FLAT, onProgress: (p) => busy('Mengubah halaman jadi gambar…', 0.3 + p * 0.7) });
      } else {
        const r = await ops.compressImages(built, { ...LEVELS[lv], codec, onProgress: (p) => busy('Mengompres gambar…', 0.3 + p * 0.7) });
        bytes = r.bytes;
        if (!r.replaced) note = r.images ? ' Gambar di dalamnya sudah efisien.' : ' PDF ini tidak berisi gambar yang bisa dikecilkan.';
      }
      unbusy();
      if (bytes.length >= built.length * 0.97) {
        toast(`Tidak ada pengurangan berarti (${fmtSize(built.length)} → ${fmtSize(bytes.length)}), jadi tidak diunduh.${note}${lv !== 'flat' ? ' Coba tingkat lebih kuat.' : ''}`, { ms: 9000 });
        return;
      }
      const name = `${sanitize(baseName())}-kompres.pdf`;
      download(new Blob([bytes], { type: 'application/pdf' }), name);
      const pct = Math.round((1 - bytes.length / built.length) * 100);
      toast(`${name}: ${fmtSize(built.length)} → ${fmtSize(bytes.length)} (−${pct}%).`, { ms: 8000 });
    } catch (err) {
      console.error(err);
      toast('Gagal mengompres PDF: ' + (err?.message || err), { error: true });
    } finally { unbusy(); }
  });

  /* ==================================================================== OCR */
  const oc = { dlg: $('#dlg-ocr'), form: $('#form-ocr') };
  const ocrRadios = () => [...document.getElementsByName('ocr-scope')];
  const ocrScopeIds = () => {
    const sel = ocrRadios().find((r) => r.checked)?.value === 'selected';
    return new Set((sel ? state.pages.filter((p) => state.selected.has(p.id)) : state.pages).map((p) => p.id));
  };
  const TESS = new URL('./vendor/tesseract/', import.meta.url).href;
  let tessPromise = null;
  const loadTesseract = () => (tessPromise ||= import('./vendor/tesseract/tesseract.esm.min.js').then((m) => m.default));

  function openOcr() {
    if (!state.pages.length) return;
    const k = state.selected.size;
    const rs = ocrRadios().find((r) => r.value === 'selected');
    const ra = ocrRadios().find((r) => r.value === 'all');
    rs.disabled = k === 0;
    $('#ocr-sel-lbl').textContent = k ? `Halaman terpilih (${k})` : 'Halaman terpilih';
    $('#ocr-all-lbl').textContent = `Semua halaman (${state.pages.length})`;
    (k ? rs : ra).checked = true;
    oc.dlg.showModal();
  }

  /** Halaman → kanvas ±200 dpi pada orientasi yang tampil (rotasi pengguna ikut diterapkan). */
  async function ocrCanvas(p) {
    const d = await pageSize(p);
    let scale = 200 / 72;
    const long = Math.max(d.w, d.h) * scale;
    if (long > 3200) scale *= 3200 / long;
    const cv = document.createElement('canvas');
    await drawRaw(p, cv, scale);
    const rot = ((p.rot % 360) + 360) % 360;
    if (!rot) return { cv, rot };
    const swap = rot % 180 !== 0;
    const out = document.createElement('canvas');
    out.width = swap ? cv.height : cv.width; out.height = swap ? cv.width : cv.height;
    const g = out.getContext('2d');
    g.translate(out.width / 2, out.height / 2); g.rotate((rot * Math.PI) / 180); g.drawImage(cv, -cv.width / 2, -cv.height / 2);
    cv.width = cv.height = 0;
    return { cv: out, rot };
  }

  const r4 = (v) => Math.round(v * 10000) / 10000;
  function extractWords(data, W, H) {
    const out = [];
    const push = (w, n) => {
      const text = String(w?.text ?? '').trim();
      if (!text || !w.bbox || (w.confidence ?? 100) < 25) return;
      const { x0, y0, x1, y1 } = w.bbox;
      if (!(x1 > x0 && y1 > y0)) return;
      out.push({ t: text, x: r4(x0 / W), y: r4(y0 / H), w: r4((x1 - x0) / W), h: r4((y1 - y0) / H), n });
    };
    if (data.blocks?.length) {
      let line = 0;
      for (const b of data.blocks) for (const par of b.paragraphs || []) for (const l of par.lines || []) { for (const w of l.words || []) push(w, line); line++; }
    } else {
      for (const w of data.words || []) push(w, w.line?.id ?? 0);
    }
    return out;
  }
  const ocrText = (words) => {
    const lines = new Map();
    for (const w of words) lines.set(w.n, [...(lines.get(w.n) || []), w.t]);
    return [...lines.values()].map((l) => l.join(' ')).join('\n');
  };

  oc.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const langs = $('#ocr-lang').value;
    const skip = $('#ocr-skip').checked;
    const ids = ocrScopeIds();
    oc.dlg.close();
    let targets = state.pages.filter((p) => ids.has(p.id) && !p.blank);
    let cancelled = false; let worker = null; let skipped = 0;
    const cancel = () => { cancelled = true; worker?.terminate?.(); };
    try {
      busy('Memeriksa halaman…', null, cancel);
      await raf();
      if (skip) {
        const keep = [];
        for (const p of targets) { if (cancelled) break; if (await pageHasText(p)) skipped++; else keep.push(p); }
        targets = keep;
      }
      if (!targets.length) {
        unbusy();
        toast(skipped ? `${plural(skipped, 'halaman')} sudah punya teks, jadi dilewati. Hilangkan centang "Lewati…" untuk memaksa OCR.` : 'Tidak ada halaman untuk diproses.');
        return;
      }
      busy('Memuat mesin OCR…', null, cancel);
      const T = await loadTesseract();
      let cur = 0;
      worker = await T.createWorker(langs, 1, {
        workerPath: TESS + 'worker.min.js', corePath: TESS + 'core', langPath: TESS + 'lang',
        workerBlobURL: false, cacheMethod: 'none',
        logger: (m) => { if (m.status === 'recognizing text' && !cancelled) busy(`OCR halaman ${cur + 1} dari ${targets.length}…`, (cur + m.progress) / targets.length, cancel); },
      });
      const results = new Map();
      for (const [i, p] of targets.entries()) {
        if (cancelled) break;
        cur = i;
        busy(`OCR halaman ${i + 1} dari ${targets.length}…`, i / targets.length, cancel);
        await raf();
        try {
          const { cv, rot } = await ocrCanvas(p);
          const { data } = await worker.recognize(cv, {}, { blocks: true });
          results.set(p.id, { rot, words: extractWords(data, cv.width, cv.height) });
          cv.width = cv.height = 0;
        } catch (err) { if (!cancelled) throw err; }
      }
      unbusy();
      const found = [...results.values()].reduce((a, r) => a + r.words.length, 0);
      if (results.size) {
        mutate(() => { for (const [id, r] of results) { const pg = pageById(id); if (pg) pg.ocr = r.words.length ? r : undefined; } });
      }
      if (!results.size) { toast(cancelled ? 'OCR dibatalkan.' : 'OCR tidak menghasilkan apa pun.', { error: !cancelled }); return; }
      const head = cancelled ? `OCR dibatalkan; ${plural(results.size, 'halaman')} yang sudah selesai disimpan.` : `OCR selesai: ${plural(results.size, 'halaman')}, ${found} kata.`;
      if (!found) { toast(`${head} Tidak ada teks terdeteksi. Periksa bahasa dan kualitas scan.`, { error: true, ms: 9000 }); return; }
      toast(head, {
        ms: 10000, action: 'Unduh .txt',
        onAction: () => {
          const body = state.pages.filter((p) => results.get(p.id)?.words.length).map((p) => `--- Halaman ${indexOfId(p.id) + 1} ---\n${ocrText(results.get(p.id).words)}`).join('\n\n');
          download(new Blob([body + '\n'], { type: 'text/plain;charset=utf-8' }), `${sanitize(baseName())}-ocr.txt`);
        },
      });
    } catch (err) {
      console.error(err);
      toast('OCR gagal: ' + (err?.message || err) + '. Pastikan perangkat online saat pertama kali memuat model bahasa.', { error: true, ms: 9000 });
    } finally {
      unbusy();
      try { await worker?.terminate(); } catch { /* sudah berhenti */ }
    }
  });


  /* ============================================================= WATERMARK */
  const wm = {
    dlg: $('#dlg-wm'), form: $('#form-wm'), cv: $('#wm-canvas'), base: null, token: 0, seq: 0, img: null, page: null,
  };
  const wmRadios = (name) => [...document.getElementsByName(name)];
  const wmVal = (name) => wmRadios(name).find((r) => r.checked)?.value;
  const wmScopePages = () => (wmVal('wm-scope') === 'selected' ? state.pages.filter((p) => state.selected.has(p.id)) : state.pages);

  /** Pengaturan dari formulir. Bisa null bila belum lengkap. */
  function wmFromForm() {
    const type = wmVal('wm-type');
    return normalizeWatermark({
      type,
      text: $('#wm-text').value,
      size: $('#wm-size').value,
      color: $('#wm-color').value,
      bold: $('#wm-bold').checked,
      img: wm.img,
      scale: Number($('#wm-scale').value) / 100,
      opacity: Number($('#wm-opacity').value) / 100,
      angle: $('#wm-angle').value,
      layout: wmVal('wm-layout'),
    });
  }

  function openWatermark() {
    if (!state.pages.length) return;
    const k = state.selected.size;
    const rs = wmRadios('wm-scope').find((r) => r.value === 'selected');
    const ra = wmRadios('wm-scope').find((r) => r.value === 'all');
    rs.disabled = k === 0;
    $('#wm-sel-lbl').textContent = k ? `Halaman terpilih (${k})` : 'Halaman terpilih';
    $('#wm-all-lbl').textContent = `Semua halaman (${state.pages.length})`;
    (k ? rs : ra).checked = true;
    // Isi formulir dari watermark yang sudah ada pada halaman pertama cakupan (bila ada).
    const cur = wmScopePages().find((p) => p.wm)?.wm;
    if (cur) {
      wmRadios('wm-type').find((r) => r.value === cur.type).checked = true;
      wmRadios('wm-layout').find((r) => r.value === cur.layout).checked = true;
      $('#wm-opacity').value = Math.round(cur.opacity * 100);
      $('#wm-angle').value = cur.angle;
      if (cur.type === 'text') {
        $('#wm-text').value = cur.text; $('#wm-size').value = cur.size; $('#wm-color').value = cur.color; $('#wm-bold').checked = !!cur.bold;
      } else {
        wm.img = cur.img; $('#wm-scale').value = Math.round(cur.scale * 100);
        $('#wm-img-name').textContent = 'Gambar terpasang';
      }
    }
    $('#wm-remove').hidden = !state.pages.some((p) => p.wm);
    wmSync();
    wm.dlg.showModal();
    requestAnimationFrame(() => wmLoadBase());
  }

  function wmSync() {
    const isImg = wmVal('wm-type') === 'image';
    $('#wm-text-opts').hidden = isImg;
    $('#wm-img-opts').hidden = !isImg;
    $('#wm-opacity-out').textContent = $('#wm-opacity').value + '%';
    const ok = !!wmFromForm();
    $('#wm-go').disabled = !ok;
    $('#wm-note').classList.toggle('err', false);
    return ok;
  }

  // Pratinjau: halaman pertama dalam cakupan (lengkap dengan potongan & anotasi, tanpa watermark lamanya).
  async function wmLoadBase() {
    const token = ++wm.token;
    const p = wmScopePages()[0] || state.pages[0];
    wm.page = p;
    if (!p) return;
    try {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const res = await composite({ ...p, wm: undefined }, (w, h) => (200 * dpr) / Math.max(w, h), { alive: () => token === wm.token });
      if (!res || token !== wm.token) return;
      if (wm.base) wm.base.width = wm.base.height = 0;
      wm.base = res.canvas;
      wmDraw();
    } catch (e) { console.warn(e); }
  }

  async function wmDraw() {
    const src = wm.base; const p = wm.page;
    if (!src || !src.width || !p) return;
    const token = wm.token; const seq = ++wm.seq;
    const rot = ((p.rot % 360) + 360) % 360;
    const swap = rot % 180 !== 0;
    // Gambar halaman + watermark pada orientasi dasar, lalu putar sesuai tampilan akhir.
    const tmp = document.createElement('canvas');
    tmp.width = src.width; tmp.height = src.height;
    const g = tmp.getContext('2d');
    g.drawImage(src, 0, 0);
    const spec = wmFromForm();
    if (spec) {
      const d = await pageSize(p);
      const crop = normalizeCrop(p.crop);
      const visW = crop ? d.w * (1 - crop.l - crop.r) : d.w;
      // Kanvas pratinjau sudah terpotong: area watermark = seluruh kanvas.
      await paintWatermark(g, spec, tmp.width, tmp.height, tmp.width / visW, { extraRot: rot });
    }
    if (token !== wm.token || seq !== wm.seq) { tmp.width = tmp.height = 0; return; }
    const cv = wm.cv;
    cv.width = swap ? tmp.height : tmp.width; cv.height = swap ? tmp.width : tmp.height;
    const out = cv.getContext('2d');
    out.save(); out.translate(cv.width / 2, cv.height / 2); out.rotate((rot * Math.PI) / 180);
    out.drawImage(tmp, -tmp.width / 2, -tmp.height / 2); out.restore();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    cv.style.width = Math.round(cv.width / dpr) + 'px'; cv.style.height = Math.round(cv.height / dpr) + 'px';
    tmp.width = tmp.height = 0;
  }

  wm.form.addEventListener('input', () => { wmSync(); wmDraw(); });
  wm.form.addEventListener('change', (e) => {
    wmSync();
    if (e.target.name === 'wm-scope') wmLoadBase(); else wmDraw();
  });

  $('#wm-pick').onclick = () => $('#wm-file').click();
  $('#wm-file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    e.target.value = '';
    if (!f) return;
    try {
      let bytes = new Uint8Array(await f.arrayBuffer());
      let mime = f.type;
      const bmp = await createImageBitmap(new Blob([bytes], { type: mime }));
      let { width: w, height: h } = bmp;
      if ((mime !== 'image/png' && mime !== 'image/jpeg') || Math.max(w, h) > 1600) {
        const k = Math.min(1, 1600 / Math.max(w, h));
        const cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(w * k)); cv.height = Math.max(1, Math.round(h * k));
        const g = cv.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(bmp, 0, 0, cv.width, cv.height);
        mime = mime === 'image/jpeg' ? 'image/jpeg' : 'image/png'; // PNG menjaga transparansi logo
        const blob = await new Promise((r) => cv.toBlob(r, mime, 0.9));
        bytes = new Uint8Array(await blob.arrayBuffer()); w = cv.width; h = cv.height;
      }
      bmp.close?.();
      wm.img = { id: 'wm' + Date.now(), bytes, mime, w, h };
      $('#wm-img-name').textContent = f.name;
      wmSync(); wmDraw();
    } catch (err) {
      console.warn(err);
      toast('Gambar tidak bisa dibaca. Gunakan PNG atau JPEG.', { error: true });
    }
  });

  const wmApply = (value, targets, msg) => {
    mutate(() => targets.forEach((p) => { p.wm = value ? { ...value } : undefined; }));
    toast(msg, { action: 'Urungkan', onAction: () => document.getElementById('btn-undo').click() });
  };
  wm.form.addEventListener('submit', (e) => {
    e.preventDefault();
    const spec = wmFromForm();
    const targets = wmScopePages();
    if (!spec || !targets.length) return;
    wm.dlg.close();
    wmApply(spec, targets, `Watermark diterapkan ke ${plural(targets.length, 'halaman')}.`);
  });
  $('#wm-remove').onclick = () => {
    const targets = wmScopePages().filter((p) => p.wm);
    wm.dlg.close();
    if (!targets.length) { toast('Halaman pada cakupan ini tidak punya watermark.'); return; }
    wmApply(null, targets, `Watermark dihapus dari ${plural(targets.length, 'halaman')}.`);
  };
  wm.dlg.addEventListener('close', () => {
    wm.token++;
    if (wm.base) wm.base.width = wm.base.height = 0;
    wm.base = null; wm.page = null; wm.cv.width = wm.cv.height = 0;
  });

  /* =============================================================== PROTEKSI */
  const pr = { dlg: $('#dlg-protect'), form: $('#form-protect') };
  const perm = () => ({
    print: $('#pr-print').checked, copy: $('#pr-copy').checked,
    modify: $('#pr-modify').checked, annotate: $('#pr-annotate').checked,
  });
  const NOTE_PR = 'Izin dihormati Acrobat, Chrome, Preview, dan pembaca umum lainnya, tetapi tidak semua aplikasi mematuhinya. Perlindungan sejatinya ada pada kata sandi buka.';
  const prNote = (msg, err = false) => { $('#pr-note').textContent = msg || NOTE_PR; $('#pr-note').classList.toggle('err', err); };

  function openProtect() {
    if (!state.pages.length) return;
    for (const id of ['pr-user', 'pr-user2', 'pr-owner']) { $('#' + id).value = ''; $('#' + id).type = 'password'; }
    $('#pr-show').checked = false;
    for (const id of ['pr-print', 'pr-copy', 'pr-modify', 'pr-annotate']) $('#' + id).checked = true;
    prNote();
    pr.dlg.showModal();
    $('#pr-user').focus();
  }
  $('#pr-show').addEventListener('change', () => {
    for (const id of ['pr-user', 'pr-user2', 'pr-owner']) $('#' + id).type = $('#pr-show').checked ? 'text' : 'password';
  });
  pr.form.addEventListener('input', () => prNote());

  pr.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const userPassword = $('#pr-user').value;
    const ownerPassword = $('#pr-owner').value;
    const permissions = perm();
    const restricted = Object.values(permissions).some((v) => !v);
    if (!userPassword && !restricted) { prNote('Isi kata sandi buka, atau batasi minimal satu izin.', true); $('#pr-user').focus(); return; }
    if (userPassword && userPassword !== $('#pr-user2').value) { prNote('Kata sandi dan pengulangannya tidak sama.', true); $('#pr-user2').focus(); return; }
    if (!userPassword && restricted && !ownerPassword) { prNote('Tanpa kata sandi buka, isi kata sandi pemilik agar izin bisa diubah nanti.', true); $('#pr-owner').focus(); return; }
    pr.dlg.close();
    try {
      busy('Menyusun dokumen…', 0);
      await raf();
      const built = await ops.build(state.pages.map(itemOf), getLib, { onProgress: (p) => busy('Menyusun dokumen…', p * 0.7) });
      busy('Mengenkripsi (AES-256)…', 0.8);
      await raf();
      const bytes = await protectPdf(PDFLib, built, { userPassword, ownerPassword, permissions });
      const name = `${sanitize(baseName())}-terkunci.pdf`;
      download(new Blob([bytes], { type: 'application/pdf' }), name);
      toast(userPassword
        ? `${name} diunduh. Simpan kata sandinya: tidak ada cara memulihkannya.`
        : `${name} diunduh. Bisa dibuka tanpa kata sandi, dengan izin yang dibatasi.`, { ms: 9000 });
    } catch (err) {
      console.error(err);
      toast('Gagal memproteksi PDF: ' + (err?.message || err), { error: true });
    } finally {
      unbusy();
      for (const id of ['pr-user', 'pr-user2', 'pr-owner']) $('#' + id).value = '';
    }
  });

  // Konversi (gambar/Word/Excel) dimuat saat pertama dipakai agar pemuatan awal tetap ringan.
  let convert = null;
  async function openConvert() {
    try {
      convert ||= (await import('./convert.js')).initConvert(ctx);
      convert.open();
    } catch (err) {
      console.error(err);
      toast('Gagal memuat fitur konversi. Periksa koneksi lalu coba lagi.', { error: true });
    }
  }

  return { openCrop, openEdit, openCompress, openOcr, openWatermark, openProtect, openConvert };
}
