// Server statis lokal untuk pengembangan. Menerapkan header dari vercel.json
// (termasuk CSP) agar perilaku lokal sama dengan di Vercel.
//   npm run dev            → http://localhost:5173
//   PORT=8080 npm run dev
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('../public/', import.meta.url)));
const cfg = JSON.parse(await readFile(new URL('../vercel.json', import.meta.url), 'utf8'));
const port = Number(process.env.PORT) || 5173;

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.wasm': 'application/wasm', '.bcmap': 'application/octet-stream',
  '.pfb': 'application/octet-stream', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown',
};

// Pola "source" Vercel yang dipakai di sini: "/(.*)", "/nama", "/dir/(.*)"
const toRegex = (src) => new RegExp('^' + src.replace(/\(\.\*\)/g, '.*') + '$');
const rules = cfg.headers.map((h) => ({ re: toRegex(h.source), headers: h.headers }));

createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    let path = decodeURIComponent(url.pathname);
    if (path.endsWith('/')) path += 'index.html';
    const file = normalize(join(root, path));
    if (!file.startsWith(root)) { res.writeHead(403).end('Forbidden'); return; }
    const info = await stat(file).catch(() => null);
    if (!info?.isFile()) { res.writeHead(404, { 'content-type': 'text/plain' }).end('Tidak ditemukan'); return; }

    const headers = { 'content-type': TYPES[extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' };
    for (const r of rules) if (r.re.test(url.pathname)) for (const { key, value } of r.headers) headers[key.toLowerCase()] = value;
    res.writeHead(200, headers);
    res.end(await readFile(file));
  } catch (e) {
    res.writeHead(500).end(String(e));
  }
}).listen(port, () => console.log(`RUMI - PDF EDITOR → http://localhost:${port}`));
