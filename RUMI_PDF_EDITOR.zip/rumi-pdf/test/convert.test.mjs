import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { parseNumber, detectNumberMode, groupLines, cellsOf, buildParagraphs, buildGrid, buildDocx, buildXlsx } from '../public/convert.js';

const OUT = new URL('./out/', import.meta.url).pathname;
mkdirSync(OUT, { recursive: true });
const W = (s, size) => s.length * size * 0.5;
const it = (x, y, str, size = 11) => ({ str, x, y, w: W(str, size), size });

test('parseNumber: format Indonesia', () => {
  const id = (s) => parseNumber(s, 'id');
  assert.deepEqual(id('1.234.567,89'), { v: 1234567.89, fmt: '#,##0.00' });
  assert.deepEqual(id('1.234'), { v: 1234, fmt: '#,##0' });
  assert.deepEqual(id('(1.500.000)'), { v: -1500000, fmt: '#,##0' });
  assert.deepEqual(id('-2.500,5'), { v: -2500.5, fmt: '#,##0.0' });
  assert.deepEqual(id('Rp 10.000'), { v: 10000, fmt: '#,##0' });
  assert.deepEqual(id('12,5%'), { v: 0.125, fmt: '0.0%' });
  assert.deepEqual(id('2024'), { v: 2024, fmt: null });   // tahun: tanpa pemisah ribuan
  assert.deepEqual(id('3,5'), { v: 3.5, fmt: '0.0' });
  for (const s of ['00123', '1234567890', '081234567890', '12.5', '01/02/2024', 'abc', '1.23.456', '', '1,234.56', '12-3456']) assert.equal(id(s), null, s);
});
test('parseNumber: format internasional & deteksi', () => {
  assert.deepEqual(parseNumber('1,234.56', 'en'), { v: 1234.56, fmt: '#,##0.00' });
  assert.deepEqual(parseNumber('1.234', 'en'), { v: 1.234, fmt: '0.000' });
  assert.equal(parseNumber('1.234,56', 'en'), null);
  assert.equal(detectNumberMode(['1.234.567,00', '250,50', 'Kas']), 'id');
  assert.equal(detectNumberMode(['1,234,567.00', '250.50']), 'en');
  assert.equal(detectNumberMode(['abc', '1.234']), 'id'); // seri → Indonesia
});

test('groupLines & cellsOf: kata dalam satu baris, sel dipisah oleh jarak lebar', () => {
  const lines = groupLines([it(100, 200.3, 'Total'), it(130, 200, 'Aset'), it(300, 200.2, '1.000'), it(50, 100, 'Judul')]);
  assert.equal(lines.length, 2);
  assert.equal(lines[0].items[0].str, 'Judul'); // atas dulu
  const cells = cellsOf(lines[1], 1.5);
  assert.deepEqual(cells.map((c) => c.text), ['Total Aset', '1.000']);
});

test('buildParagraphs: paragraf, judul, rata tengah, baris bertab', () => {
  const x0 = 72; const wide = 460;
  const L = [
    [it(228, 80, 'LAPORAN TAHUNAN', 20)],
    [it(x0, 130, 'Ini adalah kalimat pertama dari paragraf yang cukup panjang untuk membungkus', 11)],
    [it(x0, 144, 'ke baris kedua dan masih berlanjut sampai kita tiba di akhir paragraf ini.', 11)],
    [it(x0, 180, 'Paragraf kedua dimulai setelah jarak vertikal yang lebih besar dari biasanya.', 11)],
    [it(x0, 230, 'Kas', 11), it(300, 230, '1.000', 11), it(420, 230, '2.000', 11)],
    [it(x0, 244, 'Bank', 11), it(300, 244, '3.000', 11), it(420, 244, '4.000', 11)],
  ];
  // buat baris pertama & panjang agar right edge ≈ x0+wide
  L[1][0].w = wide; L[2][0].w = wide - 40; L[3][0].w = wide - 30;
  const paras = buildParagraphs(groupLines(L.flat()), { width: 595 });
  assert.equal(paras.length, 5);
  assert.equal(paras[0].heading, true);
  assert.equal(paras[0].align, 'center');
  assert.match(paras[1].text, /pertama .* kedua dan masih berlanjut/);
  assert.match(paras[2].text, /^Paragraf kedua/);
  assert.equal(paras[3].text, 'Kas\t1.000\t2.000');
  assert.equal(paras[3].tabbed, true);
});

test('buildGrid: kolom dari posisi, baris judul tidak merusak kolom, jarak vertikal besar → baris kosong', () => {
  const rows = [
    [it(50, 80, 'NERACA PER 31 DESEMBER 2025', 14)],
    [it(50, 100, 'Akun'), it(300, 100, 'Catatan'), it(400, 100, '2025'), it(480, 100, '2024')],
    [it(50, 114, 'Kas dan setara kas'), it(300, 114, '4'), it(380, 114, '1.250.000'), it(460, 114, '980.000')],
    [it(50, 128, 'Piutang usaha'), it(300, 128, '5'), it(380, 128, '(300.000)'), it(460, 128, '2.750.500')],
    [it(50, 200, 'Jumlah'), it(380, 200, '950.000'), it(460, 200, '3.730.500')],
  ];
  // sejajarkan kanan untuk kolom angka
  for (const r of rows) for (const i of r) if (/^[\d(]/.test(i.str) && i.x > 370) i.x = i.x + (80 - i.w) - 0;
  const g = buildGrid(groupLines(rows.flat()));
  assert.equal(g.cols, 4);
  assert.equal(g.rows[0][0], 'NERACA PER 31 DESEMBER 2025');
  assert.deepEqual(g.rows[1].slice(0, 4).map((x) => x || ''), ['Akun', 'Catatan', '2025', '2024']);
  assert.equal(g.rows[2][0], 'Kas dan setara kas');
  assert.equal(g.rows[2][2], '1.250.000');
  assert.equal(g.rows[3][3], '2.750.500');
  assert.deepEqual(g.rows[4], []);             // baris kosong
  assert.equal(g.rows[5][0], 'Jumlah');
  assert.equal(g.rows[5][2], '950.000');
});

test('buildDocx & buildXlsx: berkas valid & terbaca python-docx / openpyxl', () => {
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const docx = buildDocx([
    { w: 595, h: 842, paragraphs: [{ text: 'Judul & <Penting>', size: 18, heading: true, align: 'center' }, { text: 'Isi paragraf pertama.', size: 11 }, { text: 'Kas\t1.000', size: 11, tabbed: true }] },
    { w: 595, h: 842, image: { bytes: new Uint8Array(png), wPx: 1, hPx: 1, mime: 'image/png' } },
    { w: 595, h: 842, paragraphs: [], note: '[kosong]' },
  ]);
  writeFileSync(OUT + 'conv.docx', docx);
  const { bytes, numCells } = buildXlsx([
    { name: 'Hal 1', rows: [['Akun', '2025'], ['Kas', '1.250.000'], ['Piutang', '(300.000)'], ['Rasio', '12,5%'], ['NPWP', '012345678901234'], ['Tahun', '2024']] },
    { name: 'Hal 1', rows: [['x', '3,5']] },
  ], 'id');
  assert.equal(numCells, 6);
  writeFileSync(OUT + 'conv.xlsx', bytes);
  const py = `
import docx, openpyxl
d = docx.Document('${OUT}conv.docx')
t = [p.text for p in d.paragraphs]
assert t[0] == 'Judul & <Penting>', t
assert t[2] == 'Kas\\t1.000', t
assert len(d.inline_shapes) == 1
assert any('kosong' in x for x in t)
wb = openpyxl.load_workbook('${OUT}conv.xlsx')
assert wb.sheetnames == ['Hal 1', 'Hal 1 2'], wb.sheetnames
ws = wb['Hal 1']
assert ws['B2'].value == 1250000 and ws['B2'].number_format == '#,##0', (ws['B2'].value, ws['B2'].number_format)
assert ws['B3'].value == -300000
assert abs(ws['B4'].value - 0.125) < 1e-9 and '%' in ws['B4'].number_format
assert ws['B5'].value == '012345678901234'
assert ws['B6'].value == 2024 and ws['B6'].number_format == 'General'
assert wb['Hal 1 2']['B1'].value == 3.5
print('ok')`;
  assert.equal(execFileSync('python3', ['-c', py]).toString().trim(), 'ok');
});
