import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, readFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { parseRanges, planSplit, createOps } from '../public/ops.js';
import { makeZip, crc32 } from '../public/zip.js';

// Muat pdf-lib UMD yang sama persis dengan yang dipakai browser (tanpa perlu npm install).
const PDFLib = (() => {
  const mod = { exports: {} };
  const src = readFileSync(new URL('../public/vendor/pdf-lib.min.js', import.meta.url), 'utf8');
  new Function('module', 'exports', src).call(globalThis, mod, mod.exports);
  return mod.exports;
})();
const { PDFDocument, StandardFonts, degrees } = PDFLib;
const ops = createOps(PDFLib);
const OUT = new URL('./out/', import.meta.url).pathname;
mkdirSync(OUT, { recursive: true });

async function sample(label, sizes, rotations = []) {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  sizes.forEach(([w, h], i) => {
    const p = doc.addPage([w, h]);
    p.drawText(`${label}${i + 1}`, { x: 40, y: h - 80, size: 48, font });
    if (rotations[i]) p.setRotation(degrees(rotations[i]));
  });
  return new Uint8Array(await doc.save());
}

const rotOf = (p) => p.getRotation().angle;

test('parseRanges: format valid', () => {
  assert.deepEqual(parseRanges('1-3, 5, 7-', 9).ranges, [[1, 3], [5, 5], [7, 9]]);
  assert.deepEqual(parseRanges('-2 4;6 – 7', 9).ranges, [[1, 2], [4, 4], [6, 7]]);
  assert.deepEqual(parseRanges(' 3 ', 3).ranges, [[3, 3]]);
});

test('parseRanges: error', () => {
  for (const bad of ['', '  ', 'abc', '0', '10', '5-3', '1-', '--', '1--3']) {
    const r = parseRanges(bad, bad === '1-' ? 0 : 9);
    assert.equal(r.ok, false, `harus gagal: "${bad}"`);
    assert.ok(r.error);
  }
});

test('planSplit: semua mode', () => {
  assert.deepEqual(planSplit('each', 3).parts.map((p) => p.positions), [[0], [1], [2]]);
  assert.deepEqual(planSplit('every', 5, { every: 2 }).parts.map((p) => p.label), ['1-2', '3-4', '5']);
  assert.equal(planSplit('every', 5, { every: 0 }).ok, false);
  assert.deepEqual(planSplit('selected', 5, { positions: [3, 1] }).parts[0].positions, [1, 3]);
  assert.equal(planSplit('selected', 5, { positions: [] }).ok, false);
  assert.deepEqual(planSplit('ranges', 6, { text: '2-3,6' }).parts.map((p) => p.positions), [[1, 2], [5]]);
  assert.equal(planSplit('each', 0).ok, false);
});

test('gabung dua PDF, ukuran halaman tetap, urutan benar', async () => {
  const a = await sample('A', [[300, 400], [300, 400]]);
  const b = await sample('B', [[500, 300]]);
  const libs = new Map([[1, await ops.load(a)], [2, await ops.load(b)]]);
  const out = await ops.build(
    [{ fid: 1, idx: 0 }, { fid: 2, idx: 0 }, { fid: 1, idx: 1 }],
    (f) => libs.get(f),
  );
  const doc = await PDFDocument.load(out);
  assert.equal(doc.getPageCount(), 3);
  assert.deepEqual(doc.getPages().map((p) => [Math.round(p.getWidth()), Math.round(p.getHeight())]), [[300, 400], [500, 300], [300, 400]]);
  writeFileSync(OUT + 'merge.pdf', out);
});

test('putar: tambahan rotasi dijumlahkan dengan rotasi asli', async () => {
  const a = await sample('R', [[300, 400], [300, 400], [300, 400]], [0, 90, 270]);
  const lib = await ops.load(a);
  const out = await ops.build(
    [{ fid: 1, idx: 0, rot: 90 }, { fid: 1, idx: 1, rot: 90 }, { fid: 1, idx: 2, rot: 180 }],
    () => lib,
  );
  const doc = await PDFDocument.load(out);
  assert.deepEqual(doc.getPages().map(rotOf), [90, 180, 90]);
  const neg = await ops.build([{ fid: 1, idx: 0, rot: -90 }], () => lib);
  assert.equal(rotOf((await PDFDocument.load(neg)).getPage(0)), 270);
});

test('hapus & urut ulang: hanya halaman yang tersisa, dalam urutan baru', async () => {
  const a = await sample('X', [[200, 300], [210, 300], [220, 300], [230, 300]]);
  const lib = await ops.load(a);
  const out = await ops.build([{ fid: 1, idx: 3 }, { fid: 1, idx: 1 }], () => lib);
  const doc = await PDFDocument.load(out);
  assert.deepEqual(doc.getPages().map((p) => Math.round(p.getWidth())), [230, 210]);
});

test('halaman yang sama dipakai dua kali tidak merusak berkas', async () => {
  const a = await sample('D', [[200, 300], [210, 300]]);
  const lib = await ops.load(a);
  const out = await ops.build([{ fid: 1, idx: 0 }, { fid: 1, idx: 0, rot: 90 }, { fid: 1, idx: 1 }], () => lib);
  const doc = await PDFDocument.load(out);
  assert.equal(doc.getPageCount(), 3);
  assert.deepEqual(doc.getPages().map(rotOf), [0, 90, 0]);
});

test('halaman kosong: ukuran & rotasi', async () => {
  const a = await sample('K', [[200, 300]]);
  const lib = await ops.load(a);
  const out = await ops.build([{ fid: 1, idx: 0 }, { blank: true, w: 400, h: 250, rot: 90 }], () => lib);
  const doc = await PDFDocument.load(out);
  const p = doc.getPage(1);
  assert.equal(Math.round(p.getWidth()), 400);
  assert.equal(Math.round(p.getHeight()), 250);
  assert.equal(rotOf(p), 90);
});

test('split: rentang menjadi berkas terpisah dan ZIP valid', async () => {
  const a = await sample('S', Array.from({ length: 7 }, (_, i) => [200 + i, 300]));
  const lib = await ops.load(a);
  const all = Array.from({ length: 7 }, (_, i) => ({ fid: 1, idx: i }));
  const plan = planSplit('ranges', 7, { text: '1-3, 5, 7' });
  assert.ok(plan.ok);
  const files = [];
  for (const part of plan.parts) {
    const bytes = await ops.build(part.positions.map((i) => all[i]), () => lib);
    const n = (await PDFDocument.load(bytes)).getPageCount();
    assert.equal(n, part.positions.length);
    files.push({ name: `bagian-${part.label}.pdf`, data: bytes });
  }
  assert.deepEqual(files.map((f) => f.name), ['bagian-1-3.pdf', 'bagian-5.pdf', 'bagian-7.pdf']);
  const zip = makeZip(files);
  writeFileSync(OUT + 'split.zip', zip);
});

test('crc32 sesuai nilai referensi', () => {
  assert.equal(crc32(new TextEncoder().encode('123456789')), 0xcbf43926);
});

test('PDF terenkripsi ditolak dengan kode "encrypted"', async (t) => {
  const plain = OUT + 'plain.pdf';
  const enc = OUT + 'enc.pdf';
  writeFileSync(plain, await sample('E', [[200, 300]]));
  try {
    execFileSync('qpdf', ['--encrypt', 'user', 'owner', '256', '--', plain, enc]);
  } catch {
    t.skip('qpdf tidak tersedia');
    return;
  }
  await assert.rejects(() => ops.load(new Uint8Array(readFileSync(enc))), (e) => e.code === 'encrypted');
});

/* ---------------------------------------------------------------- potong, anotasi, kompres */
import { cropToBox, normalizeCrop, unsupportedChars, displayFrame } from '../public/ops.js';
import { deflateSync } from 'node:zlib';
import { randomBytes } from 'node:crypto';

function pngRGB(w, h, noise = true) {
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b) => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => {
    const t = Buffer.from(type); const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const cc = Buffer.alloc(4); cc.writeUInt32BE(crc(Buffer.concat([t, data])));
    return Buffer.concat([len, t, data, cc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const raw = Buffer.alloc((w * 3 + 1) * h);
  const rnd = randomBytes(w * 3 * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w * 3; x++) raw[y * (w * 3 + 1) + 1 + x] = noise ? rnd[y * w * 3 + x] : 200;
  return new Uint8Array(Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}
const near = (a, b, eps = 0.01) => assert.ok(Math.abs(a - b) < eps, `${a} ≈ ${b}`);

test('normalizeCrop & unsupportedChars', () => {
  assert.equal(normalizeCrop(null), null);
  assert.equal(normalizeCrop({ l: 0, t: 0, r: 0, b: 0 }), null);
  assert.equal(normalizeCrop({ l: 0.6, t: 0, r: 0.5, b: 0 }), null);
  assert.deepEqual(normalizeCrop({ l: 0.1, t: 0.2, r: 0.3, b: 0.1 }), { l: 0.1, t: 0.2, r: 0.3, b: 0.1 });
  assert.deepEqual(unsupportedChars('Café – “ok” €'), []);
  assert.deepEqual(unsupportedChars('漢字 ok'), ['漢', '字']);
});

test('cropToBox: rotasi 0 dan 90', () => {
  const box = { x: 0, y: 0, width: 300, height: 400 };
  const c = { l: 0.1, t: 0.2, r: 0.3, b: 0.1 };
  const r0 = cropToBox(box, 0, c);
  near(r0.x, 30); near(r0.y, 40); near(r0.width, 180); near(r0.height, 280);
  const r90 = cropToBox(box, 90, c);
  near(r90.x, 60); near(r90.y, 40); near(r90.width, 210); near(r90.height, 240);
  assert.deepEqual(displayFrame(box, 90), { Wd: 400, Hd: 300 });
});

test('build: potong mengatur CropBox & MediaBox (juga pada halaman berotasi bawaan)', async () => {
  const src = await sample('C', [[300, 400], [300, 400]], [0, 90]);
  const libs = new Map([[1, await ops.load(src)]]);
  const crop = { l: 0.1, t: 0.2, r: 0.3, b: 0.1 };
  const out = await PDFDocument.load(await ops.build([{ fid: 1, idx: 0, rot: 0, crop }, { fid: 1, idx: 1, rot: 90, crop }], (f) => libs.get(f)));
  const [p0, p1] = out.getPages();
  const b0 = p0.getCropBox(); near(b0.x, 30); near(b0.y, 40); near(b0.width, 180); near(b0.height, 280);
  const b1 = p1.getCropBox(); near(b1.x, 60); near(b1.y, 40); near(b1.width, 210); near(b1.height, 240);
  const m1 = p1.getMediaBox(); near(m1.width, 210);
  assert.equal(rotOf(p1), 180); // 90 bawaan + 90 pengguna
});

test('build: anotasi teks/kotak/sorot/gambar; karakter non-WinAnsi tidak membuat gagal', async () => {
  const src = await sample('M', [[300, 400]]);
  const libs = new Map([[1, await ops.load(src)]]);
  const png = { bytes: pngRGB(16, 16), mime: 'image/png' };
  const marks = [
    { id: 1, type: 'text', x: 0.1, y: 0.1, size: 20, color: '#ff0000', bold: true, text: 'Halo Dunia\nBaris 2 漢字 café' },
    { id: 2, type: 'rect', kind: 'cover', x: 0.1, y: 0.3, w: 0.3, h: 0.1, color: '#ffffff' },
    { id: 3, type: 'rect', kind: 'hl', x: 0.1, y: 0.5, w: 0.3, h: 0.05, color: '#ffe600' },
    { id: 4, type: 'image', x: 0.5, y: 0.5, w: 0.2, h: 0.2, img: png },
  ];
  const bytes = await ops.build([{ fid: 1, idx: 0, rot: 0, marks }, { blank: true, w: 200, h: 200, rot: 0, marks: [marks[0]] }], (f) => libs.get(f));
  writeFileSync(OUT + 'marks.pdf', bytes);
  const txt = execFileSync('pdftotext', [OUT + 'marks.pdf', '-']).toString();
  assert.match(txt, /Halo Dunia/);
  assert.match(txt, /Baris 2 \?\? café/);
  assert.equal((await PDFDocument.load(bytes)).getPageCount(), 2);
});

test('build: anotasi pada halaman berotasi tetap berada di pojok kiri-atas tampilan', async () => {
  for (const rot of [0, 90, 180, 270]) {
    const doc = await PDFDocument.create();
    doc.addPage([300, 400]).setRotation(degrees(rot));
    const libs = new Map([[1, await ops.load(new Uint8Array(await doc.save()))]]);
    const marks = [{ id: 1, type: 'rect', kind: 'cover', x: 0, y: 0, w: 0.25, h: 0.25, color: '#ff0000' }];
    const bytes = await ops.build([{ fid: 1, idx: 0, rot: 0, marks }], (f) => libs.get(f));
    writeFileSync(OUT + `rot${rot}.pdf`, bytes);
    execFileSync('pdftoppm', ['-r', '20', '-png', '-singlefile', OUT + `rot${rot}.pdf`, OUT + `rot${rot}`]);
    const py = `from PIL import Image
im=Image.open('${OUT}rot${rot}.png').convert('RGB'); w,h=im.size
print(im.getpixel((2,2))[0]>200 and im.getpixel((2,2))[1]<60, im.getpixel((w-3,h-3))==(255,255,255))`;
    assert.equal(execFileSync('python3', ['-c', py]).toString().trim(), 'True True', `rotasi ${rot}`);
  }
});

test('compressImages: PNG (Flate+prediktor) diubah jadi JPEG lebih kecil; gambar kecil dibiarkan', async () => {
  const doc = await PDFDocument.create();
  const big = await doc.embedPng(pngRGB(300, 300));
  const small = await doc.embedPng(pngRGB(8, 8));
  const p = doc.addPage([300, 300]);
  p.drawImage(big, { x: 0, y: 0, width: 300, height: 300 });
  p.drawImage(small, { x: 0, y: 0, width: 10, height: 10 });
  const bytes = new Uint8Array(await doc.save());
  const seen = [];
  const codec = { async recode(src, o) { seen.push(src); return { width: 150, height: 150, jpeg: new Uint8Array(4000).fill(1) }; } };
  const r = await ops.compressImages(bytes, { codec, maxDim: 150, quality: 0.5 });
  assert.equal(r.images, 2);
  assert.equal(r.replaced, 1);
  assert.equal(seen.length, 1);
  assert.equal(seen[0].kind, 'raw');
  assert.equal(seen[0].data.length, 300 * 300 * 3); // prediktor PNG berhasil didekode
  assert.ok(r.bytes.length < bytes.length / 4, `${r.bytes.length} < ${bytes.length}`);
  const re = await PDFDocument.load(r.bytes);
  assert.equal(re.getPageCount(), 1);
});

function ascii85(buf) {
  let out = '';
  for (let i = 0; i < buf.length; i += 4) {
    const n = Math.min(4, buf.length - i);
    let v = 0;
    for (let k = 0; k < 4; k++) v = v * 256 + (k < n ? buf[i + k] : 0);
    if (n === 4 && v === 0) { out += 'z'; continue; }
    const c = [];
    for (let k = 0; k < 5; k++) { c.unshift(String.fromCharCode((v % 85) + 33)); v = Math.floor(v / 85); }
    out += c.slice(0, n + 1).join('');
  }
  return out + '~>';
}

test('compressImages: rantai filter [ASCII85 Flate] dan [ASCII85 DCT] (gaya reportlab)', async () => {
  const { PDFName, PDFRawStream } = PDFLib;
  const doc = await PDFDocument.create();
  const page = doc.addPage([300, 300]);
  const raw = randomBytes(200 * 200 * 3);
  const mk = (contents, filters, extra = {}) => {
    const dict = doc.context.obj({ Type: 'XObject', Subtype: 'Image', Width: 200, Height: 200, ColorSpace: 'DeviceRGB', BitsPerComponent: 8, Filter: filters, ...extra });
    return doc.context.register(PDFRawStream.of(dict, contents));
  };
  const a = mk(Buffer.from(ascii85(deflateSync(raw))), ['ASCII85Decode', 'FlateDecode']);
  const fakeJpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff]), randomBytes(40000), Buffer.from([0xff, 0xd9])]);
  const b = mk(Buffer.from(ascii85(fakeJpeg)), ['ASCII85Decode', 'DCTDecode']);
  page.node.set(PDFName.of('Resources'), doc.context.obj({ XObject: { A: a, B: b } }));
  page.node.set(PDFName.of('Contents'), doc.context.register(doc.context.stream('q 100 0 0 100 0 0 cm /A Do Q q 100 0 0 100 100 100 cm /B Do Q')));
  const bytes = new Uint8Array(await doc.save());
  const seen = [];
  const codec = { async recode(src) { seen.push(src); return { width: 100, height: 100, jpeg: new Uint8Array(3000) }; } };
  const r = await ops.compressImages(bytes, { codec });
  assert.equal(r.replaced, 2);
  assert.deepEqual(seen.map((s) => s.kind), ['raw', 'jpeg']);
  assert.equal(seen[0].data.length, 200 * 200 * 3);
  assert.equal(Buffer.compare(Buffer.from(seen[1].bytes), fakeJpeg), 0); // JPEG asli utuh setelah ASCII85 dibuka
  assert.ok(r.bytes.length < bytes.length / 4);
});

test('build: lapisan teks OCR tak terlihat — bisa diekstrak & posisinya mengikuti tampilan (rotasi 0/90, rotasi pengguna)', async () => {
  const words = [{ t: 'HALO', x: 0.1, y: 0.2, w: 0.3, h: 0.05, n: 0 }, { t: 'dunia', x: 0.5, y: 0.2, w: 0.3, h: 0.05, n: 0 }, { t: '漢字', x: 0.1, y: 0.5, w: 0.1, h: 0.05, n: 1 }];
  const cases = [{ base: 0, rot: 0, ocrRot: 0, Wd: 300, Hd: 400 }, { base: 90, rot: 0, ocrRot: 0, Wd: 400, Hd: 300 }, { base: 0, rot: 90, ocrRot: 90, Wd: 400, Hd: 300 }];
  for (const [i, k] of cases.entries()) {
    const doc = await PDFDocument.create();
    doc.addPage([300, 400]).setRotation(degrees(k.base));
    const libs = new Map([[1, await ops.load(new Uint8Array(await doc.save()))]]);
    const bytes = await ops.build([{ fid: 1, idx: 0, rot: k.rot, ocr: { rot: k.ocrRot, words } }], (f) => libs.get(f));
    writeFileSync(OUT + `ocr${i}.pdf`, bytes);
    const txt = execFileSync('pdftotext', [OUT + `ocr${i}.pdf`, '-']).toString();
    assert.match(txt, /HALO/); assert.match(txt, /dunia/);
    const bb = execFileSync('pdftotext', ['-bbox', OUT + `ocr${i}.pdf`, '-']).toString();
    const m = /<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">HALO/.exec(bb);
    assert.ok(m, 'bbox HALO');
    near(Number(m[1]), 0.1 * k.Wd, 3); near(Number(m[3]) - Number(m[1]), 0.3 * k.Wd, 3);
    assert.ok(Number(m[2]) >= 0.2 * k.Hd - 6 && Number(m[4]) <= 0.25 * k.Hd + 6, `y ${m[2]}-${m[4]}`);
  }
});

/* ---------------------------------------------------------------- watermark & proteksi */
import { normalizeWatermark, wmPlace } from '../public/ops.js';
import { protectPdf, permissionValue, passwordBytes, hash2B } from '../public/crypt.js';

test('normalizeWatermark: validasi & batas nilai', () => {
  assert.equal(normalizeWatermark(null), null);
  assert.equal(normalizeWatermark({ type: 'text', text: '   ' }), null);
  assert.equal(normalizeWatermark({ type: 'image' }), null);
  const w = normalizeWatermark({ type: 'text', text: ' A\n B ', size: 9999, opacity: 5, color: 'merah', angle: 'x' });
  assert.equal(w.text, 'A B'); assert.equal(w.size, 400); assert.equal(w.opacity, 1); assert.equal(w.color, '#888888'); assert.equal(w.angle, 45);
});

test('wmPlace: satu titik di tengah; ubin memenuhi area dan tidak meledak', () => {
  const region = { x: 10, y: 20, w: 300, h: 400 };
  assert.deepEqual(wmPlace(region, 100, 20, 45, 'center'), [{ x: 160, y: 220 }]);
  const tile = wmPlace(region, 100, 20, 30, 'tile');
  assert.ok(tile.length > 10 && tile.length <= 800);
  assert.ok(tile.every((p) => Math.abs(p.x - 160) < 300 && Math.abs(p.y - 220) < 350));
});

test('build: watermark teks — terbaca & berpusat di area terlihat (rotasi dasar, rotasi pengguna, potongan)', async () => {
  const wm = { type: 'text', text: 'RAHASIA', size: 30, color: '#ff0000', opacity: 0.4, angle: 0, layout: 'center' };
  const cases = [
    { base: 0, rot: 0, crop: null, W: 300, H: 400, cx: 150, cy: 200 },
    { base: 90, rot: 0, crop: null, W: 400, H: 300, cx: 200, cy: 150 },
    { base: 0, rot: 90, crop: null, W: 400, H: 300, cx: 200, cy: 150 },
    { base: 0, rot: 0, crop: { l: 0.5, t: 0, r: 0, b: 0 }, W: 150, H: 400, cx: 75, cy: 200 },
  ];
  for (const [i, k] of cases.entries()) {
    const doc = await PDFDocument.create();
    doc.addPage([300, 400]).setRotation(degrees(k.base));
    const libs = new Map([[1, await ops.load(new Uint8Array(await doc.save()))]]);
    const bytes = await ops.build([{ fid: 1, idx: 0, rot: k.rot, crop: k.crop, wm }], (f) => libs.get(f));
    writeFileSync(OUT + `wm${i}.pdf`, bytes);
    const bb = execFileSync('pdftotext', ['-bbox', OUT + `wm${i}.pdf`, '-']).toString();
    const m = /<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">RAHASIA/.exec(bb);
    assert.ok(m, `kasus ${i}: teks watermark harus terbaca`);
    near((Number(m[1]) + Number(m[3])) / 2, k.cx, 4);
    near((Number(m[2]) + Number(m[4])) / 2, k.cy, 6);
  }
});

test('build: watermark gambar & ubin menghasilkan PDF valid', async () => {
  const doc = await PDFDocument.create();
  doc.addPage([300, 400]);
  const lib = await ops.load(new Uint8Array(await doc.save()));
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const img = { bytes: new Uint8Array(png), mime: 'image/png', w: 1, h: 1 };
  const bytes = await ops.build([
    { fid: 1, idx: 0, wm: { type: 'image', img, scale: 0.3, opacity: 0.5, angle: 30, layout: 'tile' } },
    { fid: 1, idx: 0, wm: { type: 'text', text: 'X', size: 12, layout: 'tile', angle: -20 } },
  ], () => lib);
  assert.equal((await PDFDocument.load(bytes)).getPageCount(), 2);
  writeFileSync(OUT + 'wm-img.pdf', bytes);
  execFileSync('qpdf', ['--check', OUT + 'wm-img.pdf']);
});

test('crypt: permissionValue & password UTF-8', () => {
  assert.equal(permissionValue({}), -4); // semua diizinkan
  const none = permissionValue({ print: false, copy: false, modify: false, annotate: false });
  assert.equal(none & 0x4, 0); assert.equal(none & 0x10, 0); assert.equal(none & 0x8, 0); assert.equal(none & 0x20, 0);
  assert.notEqual(none & 0x200, 0); // aksesibilitas tetap diizinkan
  assert.equal(passwordBytes('é').length, 2);
  assert.equal(passwordBytes('é'.repeat(100)).length, 126); // dipotong di batas karakter, bukan di tengah
});

test('crypt: hash 2.B deterministik & berpanjang 32 byte', async () => {
  const a = await hash2B(new TextEncoder().encode('pw'), new Uint8Array(8));
  const b = await hash2B(new TextEncoder().encode('pw'), new Uint8Array(8));
  assert.equal(a.length, 32); assert.deepEqual(a, b);
  assert.notDeepEqual(a, await hash2B(new TextEncoder().encode('pw2'), new Uint8Array(8)));
});

test('proteksi: hasil dibuka qpdf/poppler dengan sandi yang benar, ditolak bila salah, izin terbaca', async (t) => {
  try { execFileSync('qpdf', ['--version']); } catch { t.skip('qpdf tidak tersedia'); return; }
  const doc = await PDFDocument.create();
  doc.setTitle('Judul Rahasia');
  const font = await doc.embedFont(StandardFonts.Helvetica);
  doc.addPage([300, 400]).drawText('isi dokumen rahasia', { x: 20, y: 300, size: 18, font });
  const plain = new Uint8Array(await doc.save());
  const bytes = await protectPdf(PDFLib, plain, {
    userPassword: 'sandi-Ü1', ownerPassword: 'pemilik', permissions: { print: true, copy: false, modify: false, annotate: true },
  });
  const file = OUT + 'locked.pdf';
  writeFileSync(file, bytes);
  const info = execFileSync('qpdf', ['--show-encryption', '--password=sandi-Ü1', file]).toString();
  assert.match(info, /R = 6/); assert.match(info, /stream encryption method: AESv3/);
  assert.match(info, /extract for any purpose: not allowed/); assert.match(info, /print high resolution: allowed/);
  assert.match(execFileSync('pdftotext', ['-upw', 'sandi-Ü1', file, '-']).toString(), /isi dokumen rahasia/);
  assert.match(execFileSync('qpdf', ['--check', '--password=pemilik', file]).toString(), /No syntax or stream encoding errors/);
  assert.throws(() => execFileSync('pdftotext', ['-upw', 'salah', file, '-'], { stdio: 'pipe' }));
  assert.throws(() => execFileSync('pdftotext', [file, '-'], { stdio: 'pipe' }));
  // isi tidak tersimpan sebagai teks polos di berkas
  assert.ok(!Buffer.from(bytes).includes('isi dokumen rahasia'));
  assert.ok(!Buffer.from(bytes).includes('Judul Rahasia'));
  await assert.rejects(() => ops.load(bytes), (e) => e.code === 'encrypted');
});

test('proteksi: tanpa sandi buka tetap bisa dibuka, izin cetak ditolak', async (t) => {
  try { execFileSync('qpdf', ['--version']); } catch { t.skip('qpdf tidak tersedia'); return; }
  const doc = await PDFDocument.create();
  doc.addPage([200, 200]);
  const bytes = await protectPdf(PDFLib, new Uint8Array(await doc.save()), { userPassword: '', ownerPassword: 'own', permissions: { print: false } });
  writeFileSync(OUT + 'locked-nouser.pdf', bytes);
  const info = execFileSync('qpdf', ['--show-encryption', OUT + 'locked-nouser.pdf']).toString();
  assert.match(info, /User password = \n/); assert.match(info, /print high resolution: not allowed/);
});
